using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CastleInteractable : MonoBehaviour, IInteractable
{
    [SerializeField]
    private InteractMenuAnimManager _interactMenuAnimManager;

    InteractMenuAnimManager IInteractable.interactMenuAnimManager
    {
        get => _interactMenuAnimManager;
        set => _interactMenuAnimManager = value;
    }

    public void Interact()
    {
        GameObject dest = GameObject.Find("DungeonEntryPoint");
        if (dest == null)
        {
            Debug.LogError("[CastleInteractable] DungeonEntryPoint not found in the scene!");
            return;
        }

        GameObject player = GameObject.Find("PL");
        if (player == null)
        {
            Debug.LogError("[CastleInteractable] Player 'PL' GameObject not found in the scene!");
            return;
        }

        Rigidbody rb = player.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Clear active interaction state to prevent double-triggering across space
        ActionPLController actionController = player.GetComponent<ActionPLController>();
        if (actionController != null && actionController.ActiveInteractObject != null)
        {
            actionController.LostObject(actionController.ActiveInteractObject);
            actionController.ActiveInteractObject = null;
        }

        // Start tracking dungeon escape objective and clean up old portals BEFORE teleporting
        DungeonEscapeController.OnEnterDungeon();

        // Save the player's safe surface position before teleporting
        DungeonEscapeController.LastSurfacePosition = player.transform.position;

        // Teleport slightly elevated above the destination to land cleanly
        Debug.Log($"[CastleInteractable] Teleporting player to DungeonEntryPoint at: {dest.transform.position}");
        player.transform.position = dest.transform.position + Vector3.up * 3f;
        player.transform.rotation = dest.transform.rotation;

        // Turn off fog and Day-Night cycle inside the dungeon
        MagicUniverse.World.DayNightCycleController.IsInDungeon = true;

        Debug.Log("[CastleInteractable] Seamlessly teleported player to Dungeon!");
    }
}
