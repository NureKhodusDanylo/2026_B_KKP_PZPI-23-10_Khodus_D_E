using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DungeonExitInteractable : MonoBehaviour, IInteractable
{
    private InteractMenuAnimManager _interactMenuAnimManager;

    InteractMenuAnimManager IInteractable.interactMenuAnimManager
    {
        get => _interactMenuAnimManager;
        set => _interactMenuAnimManager = value;
    }

    private void Awake()
    {
        _interactMenuAnimManager = GetComponentInChildren<InteractMenuAnimManager>();
    }

    public void SetAnimManager(InteractMenuAnimManager anim)
    {
        _interactMenuAnimManager = anim;
    }

    public void Interact()
    {
        // 1. Find player
        GameObject player = GameObject.Find("PL");
        if (player == null)
        {
            Debug.LogError("[DungeonExitInteractable] Player 'PL' not found in scene!");
            return;
        }

        // Stop all velocity before teleporting
        Rigidbody rb = player.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Clear active interaction state to prevent double-triggering across space
        ActionPLController actionController = player.GetComponent<ActionPLController>();
        if (actionController != null && actionController.ActiveInteractObject != null)
        {
            actionController.LostObject(actionController.ActiveInteractObject);
            actionController.ActiveInteractObject = null;
        }

        // 2. Teleport back to safe, pre-verified surface position
        Vector3 returnPos = DungeonEscapeController.LastSurfacePosition;
        if (returnPos == Vector3.zero)
        {
            // Fallback if somehow not recorded
            GameObject dest = GameObject.Find("CastleInteraction");
            if (dest == null) dest = GameObject.Find("Castle))");
            returnPos = dest != null ? dest.transform.position + Vector3.up * 2f : new Vector3(0f, 15f, 0f);
        }

        player.transform.position = returnPos + Vector3.up * 0.5f;
        player.transform.rotation = Quaternion.identity;

        // 3. Restore day-night cycle and environment settings
        MagicUniverse.World.DayNightCycleController.IsInDungeon = false;

        // 4. Notify controller to cleanup
        DungeonEscapeController.OnExitDungeon();

        Debug.Log("[DungeonExitInteractable] Player successfully escaped the dungeon and returned to Castle surface!");
    }
}
