using UnityEngine;

public class DungeonEscapeController : MonoBehaviour
{
    private static DungeonEscapeController _instance;
    public static DungeonEscapeController Instance
    {
        get
        {
            if (_instance == null)
            {
                GameObject go = new GameObject("DungeonEscapeController");
                _instance = go.AddComponent<DungeonEscapeController>();
                DontDestroyOnLoad(go);
            }
            return _instance;
        }
    }

    [Header("Objective Settings")]
    public int requiredKills = 15;
    public int currentKills = 0;
    public bool objectiveCompleted = false;
    private bool showHUD = false;

    // Track safe return position on the surface
    public static Vector3 LastSurfacePosition = Vector3.zero;

    [Header("Dynamic Portal Reference")]
    private GameObject activePortal;

    // GUI Textures
    private Texture2D boxBackgroundTexture;

    public static void OnEnterDungeon()
    {
        Instance.requiredKills = 15;
        Instance.currentKills = 0;
        Instance.objectiveCompleted = false;
        Instance.showHUD = true;

        Instance.CleanupPortal();
        
        Debug.Log("[DungeonEscapeController] Started dungeon run. Required kills: 15");
    }

    public static void RegisterKill()
    {
        if (Instance.objectiveCompleted) return;

        Instance.currentKills++;
        Debug.Log($"[DungeonEscapeController] Enemy killed! Progress: {Instance.currentKills} / {Instance.requiredKills}");

        if (Instance.currentKills >= Instance.requiredKills)
        {
            Instance.CompleteObjective();
        }
    }

    public static void OnExitDungeon()
    {
        Instance.showHUD = false;
        Instance.CleanupPortal();
        Instance.currentKills = 0;
        Instance.objectiveCompleted = false;
        
        Debug.Log("[DungeonEscapeController] Dungeon run cleared and cleaned up.");
    }

    private void CompleteObjective()
    {
        objectiveCompleted = true;
        SpawnExitPortal();
    }

    private void SpawnExitPortal()
    {
        CleanupPortal();

        Vector3 portalPos = new Vector3(-34f, -949.1f, -25f); // Flat on the Ziggurat top platform
        activePortal = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        activePortal.name = "DungeonExitPortal";
        activePortal.transform.position = portalPos;
        activePortal.transform.localScale = new Vector3(8f, 0.1f, 8f); // Wide circular portal pad

        // Set trigger
        Collider legacyCollider = activePortal.GetComponent<Collider>();
        if (legacyCollider != null) Destroy(legacyCollider); // Remove default mesh collider

        SphereCollider trigger = activePortal.AddComponent<SphereCollider>();
        trigger.isTrigger = true;
        trigger.center = Vector3.zero;
        trigger.radius = 1f; // Since scale is (8, 0.1, 8), sphere radius of 1 means world radius of 8m!

        // Inject interactable exit
        activePortal.AddComponent<DungeonExitInteractable>();

        // Set a gorgeous transparent emissive cyan material
        Renderer rend = activePortal.GetComponent<Renderer>();
        if (rend != null)
        {
            Material portalMat = new Material(Shader.Find("Standard"));
            portalMat.color = new Color(0f, 0.8f, 1f, 0.6f);
            
            // Set material rendering mode to Transparent
            portalMat.SetFloat("_Mode", 3f);
            portalMat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            portalMat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            portalMat.SetInt("_ZWrite", 0);
            portalMat.DisableKeyword("_ALPHATEST_ON");
            portalMat.EnableKeyword("_ALPHABLEND_ON");
            portalMat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            portalMat.renderQueue = 3000;
            
            // Set emissive glow
            portalMat.EnableKeyword("_EMISSION");
            portalMat.SetColor("_EmissionColor", new Color(0f, 0.6f, 0.8f) * 3f);
            rend.material = portalMat;
        }

        // Add a beautiful glowing cyan point light
        GameObject lightObj = new GameObject("PortalGlowLight");
        lightObj.transform.SetParent(activePortal.transform, false);
        lightObj.transform.localPosition = new Vector3(0f, 10f, 0f); // Float slightly above the pad

        Light glow = lightObj.AddComponent<Light>();
        glow.type = LightType.Point;
        glow.color = Color.cyan;
        glow.range = 25f;
        glow.intensity = 15f;
        glow.shadows = LightShadows.Soft;

        // Duplicate the IntecactMenu child from CastleInteraction to satisfy player ActionPLController
        GameObject surfaceInteraction = GameObject.Find("CastleInteraction");
        if (surfaceInteraction != null)
        {
            Transform menuSource = surfaceInteraction.transform.Find("IntecactMenu");
            if (menuSource != null)
            {
                GameObject menuCopy = Instantiate(menuSource.gameObject, activePortal.transform);
                menuCopy.name = "IntecactMenu";
                menuCopy.transform.localPosition = new Vector3(0f, 15f, 0f); // Relative Y is 15f (so 1.5m above the pad in world space)
                menuCopy.transform.localRotation = Quaternion.identity;
                menuCopy.transform.localScale = new Vector3(1.875f, 150f, 1.875f); // Counter-scales parent's (8, 0.1, 8) to get clean 15x world scale!
                
                DungeonExitInteractable exitInteractable = activePortal.GetComponent<DungeonExitInteractable>();
                if (exitInteractable != null)
                {
                    exitInteractable.SetAnimManager(menuCopy.GetComponent<InteractMenuAnimManager>());
                }
            }
        }

        Debug.Log("[DungeonEscapeController] Glowing 3D Exit Portal successfully spawned at Ziggurat center-top!");
    }

    private void CleanupPortal()
    {
        if (activePortal != null)
        {
            activePortal.SetActive(false);
            Destroy(activePortal);
            activePortal = null;
        }
        
        GameObject existing = GameObject.Find("DungeonExitPortal");
        if (existing != null)
        {
            existing.SetActive(false);
            Destroy(existing);
        }
    }

    private void OnGUI()
    {
        if (showHUD)
        {
            float width = 380f;
            float height = 80f;
            float x = (Screen.width - width) / 2f;
            float y = 20f;

            // Background container style (Glassmorphic Dark Slate)
            GUIStyle boxStyle = new GUIStyle(GUI.skin.box);
            if (boxBackgroundTexture == null)
            {
                boxBackgroundTexture = MakeTex(2, 2, new Color(0.08f, 0.09f, 0.12f, 0.85f));
            }
            boxStyle.normal.background = boxBackgroundTexture;
            boxStyle.border = new RectOffset(0, 0, 0, 0);

            // Container Box
            GUI.Box(new Rect(x, y, width, height), "", boxStyle);

            // Header Label Style
            GUIStyle headerStyle = new GUIStyle(GUI.skin.label);
            headerStyle.alignment = TextAnchor.MiddleCenter;
            headerStyle.fontStyle = FontStyle.Bold;
            headerStyle.fontSize = 14;

            if (objectiveCompleted)
            {
                headerStyle.normal.textColor = new Color(0.2f, 1.0f, 0.6f); // Emerald Green
                GUI.Label(new Rect(x, y + 12f, width, 25f), "✨ PORTAL UNLOCKED! ✨", headerStyle);
            }
            else
            {
                headerStyle.normal.textColor = new Color(1.0f, 0.75f, 0.0f); // Golden amber
                GUI.Label(new Rect(x, y + 12f, width, 25f), "👹 DUNGEON OBJECTIVE", headerStyle);
            }

            // Progress/Objective Label Style
            GUIStyle progressStyle = new GUIStyle(GUI.skin.label);
            progressStyle.alignment = TextAnchor.MiddleCenter;
            progressStyle.fontSize = 15;
            progressStyle.normal.textColor = Color.white;

            if (objectiveCompleted)
            {
                progressStyle.fontStyle = FontStyle.Bold;
                GUI.Label(new Rect(x, y + 42f, width, 30f), "Return to top of Ziggurat to Escape!", progressStyle);
            }
            else
            {
                progressStyle.fontStyle = FontStyle.Normal;
                GUI.Label(new Rect(x, y + 42f, width, 30f), $"Kill 15 Enemies: {currentKills} / {requiredKills}", progressStyle);
            }
        }
    }

    private Texture2D MakeTex(int width, int height, Color col)
    {
        Color[] pix = new Color[width * height];
        for (int i = 0; i < pix.Length; ++i)
        {
            pix[i] = col;
        }
        Texture2D result = new Texture2D(width, height);
        result.SetPixels(pix);
        result.Apply();
        return result;
    }

    private void OnDestroy()
    {
        CleanupPortal();
        if (boxBackgroundTexture != null)
        {
            Destroy(boxBackgroundTexture);
        }
    }
}
