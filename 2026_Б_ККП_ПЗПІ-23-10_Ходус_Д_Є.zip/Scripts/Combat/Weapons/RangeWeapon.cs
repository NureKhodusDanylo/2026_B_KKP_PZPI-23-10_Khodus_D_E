using UnityEngine;
public class RangeWeapon : Weapon
{
    [SerializeField] public GameObject Projectile;
    [SerializeField] protected Transform ShootPoint;

    public override void Attack(Transform target)
    {
        if (Projectile == null || ShootPoint == null) return;
        
        GameObject projInstance = PoolManager.Instanse.CreateObject(Projectile, ShootPoint.position, ShootPoint.rotation);
        
        if (projInstance.TryGetComponent(out Projectile projectile))
        {
            projectile.Owner = gameObject;
            projectile.SetUp(projectileSpeed, Damage, projectileScale);
        }
    }

    public void Subscribe()
    {

    }

    public void UnSubscribe()
    {

    }

    public override void Dispose()
    {
    }
}