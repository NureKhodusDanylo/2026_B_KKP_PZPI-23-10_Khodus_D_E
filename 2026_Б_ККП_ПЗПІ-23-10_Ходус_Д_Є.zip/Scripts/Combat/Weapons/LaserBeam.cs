using UnityEngine;
using System.Collections.Generic;

public class LaserBeam : MonoBehaviour
{
    [Header("Visuals")]
    [SerializeField] private Transform visual;
    [SerializeField] private float telegraphWidth = 0.1f;
    [SerializeField] private float mainWidth = 0.5f;

    [Header("Settings")]
    [SerializeField] private LayerMask obstacleMask;
    [SerializeField] private float maxDistance = 100f;

    private float damage;
    private float lifeTime;
    private float telegraphDuration;
    private bool useTickDamage;
    
    private float timer;
    private float nextTickTime;
    private bool isTelegraphing;
    private float currentDistance;
    private Vector3 shootPoint;
    private Vector3 direction;
    private Transform sourceTransform;

    private GameObject hitEffectPrefab;
    private GameObject currentHitEffect;
    private Vector3 hitPoint;
    private Vector3 hitNormal;
    private bool hasHit;

    private void Awake()
    {
        if (visual == null) visual = transform.Find("LaserVisual");
    }

    public void SetUp(float damage, float duration, float telegraphDur, LayerMask mask, GameObject effectPrefab, Vector3 dir, Transform source, bool dpsMode = true)
    {
        this.damage = damage;
        this.lifeTime = duration;
        this.telegraphDuration = telegraphDur;
        this.obstacleMask = mask;
        this.hitEffectPrefab = effectPrefab;
        this.useTickDamage = !dpsMode;
        
        timer = 0;
        isTelegraphing = true;
        
        shootPoint = transform.position;
        direction = dir.normalized;
        sourceTransform = source;

        Debug.Log($"[LaserBeam] SetUp with direction: {direction} (ShootPoint: {shootPoint})");

        CalculateDistance();
        UpdateVisuals();
    }

    private void CalculateDistance()
    {
        if (Physics.Raycast(shootPoint, direction, out var hit, maxDistance, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            currentDistance = hit.distance;
            hitPoint = hit.point;
            hitNormal = hit.normal;
            hasHit = true;
        }
        else
        {
            currentDistance = maxDistance;
            hasHit = false;
        }
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if (isTelegraphing)
        {
            // Recalculate distance only during telegraph to handle moving obstacles
            CalculateDistance();

            if (sourceTransform != null)
            {
                shootPoint = sourceTransform.position;
                direction = sourceTransform.forward;
            }

            if (timer >= telegraphDuration)
            {
                isTelegraphing = false;
                timer = 0; // Reset for main duration
                nextTickTime = Time.time;
            }
        }
        else
        {
            if (timer >= lifeTime)
            {
                ReturnToPool();
                return;
            }
            ApplyDamage();
            UpdateHitEffect();
        }

        UpdateVisuals();
    }

    private void UpdateVisuals()
    {
        if (visual == null) return;

        float width = isTelegraphing ? telegraphWidth : mainWidth;
        
        visual.position = shootPoint + direction * (currentDistance / 2f);
        
        // Cylinder height is Y. Align Y with direction.
        visual.rotation = Quaternion.FromToRotation(Vector3.up, direction);
        
        Vector3 scale = visual.localScale;
        scale.y = currentDistance / 2f;
        scale.x = width;
        scale.z = width;
        visual.localScale = scale;
    }

    private void UpdateHitEffect()
    {
        if (hitEffectPrefab == null || !hasHit) 
        {
            if (currentHitEffect != null) currentHitEffect.SetActive(false);
            return;
        }

        if (currentHitEffect == null)
        {
            currentHitEffect = PoolManager.Instanse.CreateObject(hitEffectPrefab, hitPoint, Quaternion.LookRotation(hitNormal));
        }
        else
        {
            currentHitEffect.SetActive(true);
            currentHitEffect.transform.position = hitPoint;
            currentHitEffect.transform.rotation = Quaternion.LookRotation(hitNormal);
        }
    }

    private void ApplyDamage()
    {
        // Use SphereCastAll to hit everyone in the path
        RaycastHit[] hits = Physics.SphereCastAll(shootPoint, mainWidth / 2f, direction, currentDistance);
        
        HashSet<IDamageable> damagedInFrame = new HashSet<IDamageable>();
        bool ticked = false;

        foreach (var hit in hits)
        {
            if (hit.collider.TryGetComponent(out IDamageable damageable))
            {
                if (!damagedInFrame.Contains(damageable))
                {
                    if (useTickDamage)
                    {
                        if (Time.time >= nextTickTime)
                        {
                            damageable.TakeDamage(damage);
                            ticked = true;
                        }
                    }
                    else
                    {
                        damageable.TakeDamage(damage * Time.deltaTime);
                    }
                    damagedInFrame.Add(damageable);
                }
            }
        }
        
        if (ticked)
        {
            nextTickTime = Time.time + 0.5f; 
        }
    }

    public void DetachFromSource()
    {
        sourceTransform = null;
    }

    public void Cancel()
    {
        ReturnToPool();
    }

    private void ReturnToPool()
    {
        if (currentHitEffect != null)
        {
            if (PoolManager.Instanse != null)
                PoolManager.Instanse.ReturnObject(currentHitEffect);
            else
                Destroy(currentHitEffect);
            currentHitEffect = null;
        }

        if (PoolManager.Instanse != null)
            PoolManager.Instanse.ReturnObject(gameObject);
        else
            Destroy(gameObject);
    }
}
