using UnityEngine;
using System.Collections.Generic;

public class SpellBookWeapon : Weapon
{
    [Header("Spell Settings")]
    [SerializeField] private GameObject spellAreaPrefab;
    [SerializeField] private float telegraphDuration = 1.5f;
    [SerializeField] private float activeDuration = 1.0f;
    [SerializeField] private float followSpeed = 5.0f;
    [SerializeField] private List<string> targetTags = new List<string> { "Player" };

    public override void Attack(Transform target)
    {
        if (spellAreaPrefab == null || target == null) return;

        // Spawn at player's position
        GameObject spellObj = PoolManager.Instanse.CreateObject(spellAreaPrefab, target.position, Quaternion.identity);
        
        if (spellObj.TryGetComponent(out SpellArea area))
        {
            area.SetUp(Damage, telegraphDuration, activeDuration, followSpeed, target, targetTags);
        }
    }

    public override void EndAttack()
    {
        // Spell book attacks are self-contained once spawned, 
        // no need to reset barrels like the laser.
    }
}
