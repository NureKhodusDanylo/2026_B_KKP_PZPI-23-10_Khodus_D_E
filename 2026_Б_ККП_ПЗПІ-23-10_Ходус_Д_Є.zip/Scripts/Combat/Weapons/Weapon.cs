using System;
using UnityEngine;


 public class Weapon : MonoBehaviour, IDisposable, IInitializable
{
    [SerializeField] public float Damage = 1f;
    
    [SerializeField] public float Cooldown = 1f;
    [SerializeField] public float Delay = 0.2f;
    [SerializeField] public float Duration = 1f;

    [Header("Projectile Settings")]
    [SerializeField] protected float projectileSpeed = 10f;
    [SerializeField] protected float projectileScale = 1f;

    public Weapon() { }

    public Weapon(float damage)
    {
        Damage = damage;
    }

    public virtual void Attack()
    {
    }

    public virtual void Attack(IDamageable damageable)
    {
    }

    public virtual void Attack(Transform target)
    {
    }

    public virtual void Dispose()
    {
    }

    public virtual void Init()
    {
        throw new NotImplementedException();
    }

    public virtual void EndAttack()
    {
    }
}