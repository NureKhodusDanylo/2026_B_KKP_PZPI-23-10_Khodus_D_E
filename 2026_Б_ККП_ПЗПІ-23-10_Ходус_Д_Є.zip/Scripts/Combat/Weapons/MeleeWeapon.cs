
using UnityEngine;
using System.Collections.Generic;


public class MeleeWeapon : Weapon
{
    [SerializeField] private GameObject BladeHitBox;
    [SerializeField] private ColliderCheker BlabeChekerScript;

    [SerializeField] private float AttackDamage;

    public override void Init()
    {
        if (BlabeChekerScript == null)
        {
            BlabeChekerScript = GetComponentInChildren<ColliderCheker>(true);
        }

        if (BlabeChekerScript != null)
        {
            BlabeChekerScript.SetUp(new List<string> { "Player" });
            Subscribe();
        }
        else
        {
            Debug.LogError($"[MeleeWeapon] BlabeChekerScript is null and could not be resolved on {gameObject.name}!", this);
        }
    }

    public void Subscribe()
    {
        BlabeChekerScript.TriggerEnter += ActivateAttack;
    }
    public void UnSubscribe()
    {
        BlabeChekerScript.TriggerEnter -= ActivateAttack;
    }

    public override void Dispose()
    {
        UnSubscribe();
    }


    public void ActivateAttack(Collider other)
    {
        IDamageable damageable = other.GetComponent<IDamageable>();

        if (damageable != null)
        {
            damageable.TakeDamage(AttackDamage);
        }
    }

    public override void Attack()
    {
        ActivateBlade();
    }

    public void ActivateBlade()
    {
        BladeHitBox.SetActive(true);
    }

    public void DeactivateBlade()
    {
        BladeHitBox.SetActive(false);
    }
}