using UnityEngine;
using System.Collections.Generic;

public class SpellArea : Projectile
{
    [Header("Spell Visuals")]
    [SerializeField] private GameObject telegraphVisual;
    [SerializeField] private GameObject activeVisual;
    [SerializeField] private ColliderCheker damageChecker;

    private float telegraphDuration;
    private float activeDuration;
    private float followSpeed;
    private Transform target;
    private List<string> targetTags;

    private float timer;
    private bool isTelegraphing;
    private bool hasExploded;
    private Collider areaCollider;

    private HashSet<IDamageable> damagedTargets = new HashSet<IDamageable>();

    private void Awake()
    {
        areaCollider = GetComponent<Collider>();
        if (areaCollider == null) areaCollider = GetComponentInChildren<Collider>();
        
        if (areaCollider != null) areaCollider.enabled = false;

        if (damageChecker != null)
        {
            damageChecker.TriggerEnter += HandleTriggerEnter;
        }
    }

    private void OnDestroy()
    {
        if (damageChecker != null)
        {
            damageChecker.TriggerEnter -= HandleTriggerEnter;
        }
    }

    public void SetUp(float damage, float telegraphDur, float activeDur, float followSpeed, Transform target, List<string> targetTags)
    {
        base.SetUp(0, damage, 1f, telegraphDur + activeDur);
        
        this.telegraphDuration = telegraphDur;
        this.activeDuration = activeDur;
        this.followSpeed = followSpeed;
        this.target = target;
        this.targetTags = targetTags;

        if (damageChecker != null)
        {
            damageChecker.SetUp(targetTags);
        }

        timer = 0;
        isTelegraphing = true;
        hasExploded = false;
        damagedTargets.Clear();

        if (telegraphVisual) telegraphVisual.SetActive(true);
        if (activeVisual) activeVisual.SetActive(false);
        if (areaCollider != null) areaCollider.enabled = false;
    }

    protected override void Movement()
    {
        if (isTelegraphing)
        {
            timer += Time.fixedDeltaTime;

            if (target != null)
            {
                transform.position = Vector3.Lerp(transform.position, target.position, Time.fixedDeltaTime * followSpeed);
            }

            if (timer >= telegraphDuration)
            {
                isTelegraphing = false;
                timer = 0;
                TriggerExplosion();
            }
        }
    }

    private void TriggerExplosion()
    {
        if (hasExploded) return;
        hasExploded = true;

        if (telegraphVisual) telegraphVisual.SetActive(false);
        if (activeVisual) activeVisual.SetActive(true);

        if (areaCollider != null)
        {
            areaCollider.enabled = true;
            
            // Manual burst check for objects already inside
            if (areaCollider is SphereCollider sphere)
            {
                Collider[] hits = Physics.OverlapSphere(transform.TransformPoint(sphere.center), sphere.radius * transform.lossyScale.x);
                foreach (var hit in hits)
                {
                    HandleTriggerEnter(hit);
                }
            }
            else if (areaCollider is BoxCollider box)
            {
                Collider[] hits = Physics.OverlapBox(transform.TransformPoint(box.center), box.size * 0.5f, transform.rotation);
                foreach (var hit in hits)
                {
                    HandleTriggerEnter(hit);
                }
            }
        }
    }

    private void HandleTriggerEnter(Collider other)
    {
        if (!hasExploded) return;

        // Use GetComponentInParent because IDamageable is often on the root Character object
        IDamageable damageable = other.GetComponentInParent<IDamageable>();
        
        if (damageable != null && !damagedTargets.Contains(damageable))
        {
            // Check tags
            string otherTag = other.tag;
            bool tagMatch = targetTags != null && targetTags.Contains(otherTag);
            
            if (tagMatch)
            {
                damagedTargets.Add(damageable);
                damageable.TakeDamage(damage);
                Debug.Log($"[SpellArea] Damaged: {other.name} (Tag: {otherTag}). Damage: {damage}");
            }
        }
    }

    protected override void OnTriggerEnter(Collider other)
    {
        // Handled via ColliderCheker or Manual Override
    }
}
