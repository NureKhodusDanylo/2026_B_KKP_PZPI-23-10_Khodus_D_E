using UnityEngine;

public class ArtilleristWeapon : Weapon
{
    [SerializeField] private GameObject projectilePrefab;
    [SerializeField] private Transform shootPoint;
    [SerializeField] private float arcHeight = 5f;

    public override void Attack(Transform target)
    {
        FireAt(target);
    }

    public void FireAt(Transform target)
    {
        if (projectilePrefab == null || shootPoint == null) return;

        // Spawn artillery projectile from pool
        GameObject projInstance = PoolManager.Instanse.CreateObject(projectilePrefab, shootPoint.position, shootPoint.rotation);
        
        if (projInstance.TryGetComponent(out ArtilleryProjectile artilleryProjectile))
        {
            // Determine target position - default forward if no target
            Vector3 targetPosition = target != null ? target.position : shootPoint.position + shootPoint.forward * 10f;

            // Set specialized artillery parameters before calling SetUp
            artilleryProjectile.TargetPosition = targetPosition;
            artilleryProjectile.ArcHeight = arcHeight;

            // Set base projectile parameters (triggers the trajectory calculation in the override)
            artilleryProjectile.Owner = gameObject;
            artilleryProjectile.SetUp(projectileSpeed, Damage, projectileScale, 10f);
        }
    }
}
