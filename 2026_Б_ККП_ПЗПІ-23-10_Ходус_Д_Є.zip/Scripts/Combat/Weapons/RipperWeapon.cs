using UnityEngine;
using System.Collections.Generic;

public class RipperWeapon : Weapon
{
    [SerializeField] private GameObject explosionHitBox;
    [SerializeField] private ColliderCheker explosionCheker;

    [SerializeField] private float attackDamage;

    public override void Init()
    {
        explosionCheker.SetUp(new List<string> { "Player" });
        Subscribe();
    }

    public void Subscribe()
    {
        explosionCheker.TriggerEnter += ActivateAttack;
    }

    public void UnSubscribe()
    {
        explosionCheker.TriggerEnter -= ActivateAttack;
    }

    public override void Dispose()
    {
        UnSubscribe();
    }

    public void ActivateAttack(Collider other)
    {
        IDamageable damageable = other.GetComponent<IDamageable>();

        if (damageable != null && other.transform.root != transform.root)
        {
            damageable.TakeDamage(attackDamage);
        }
    }

    public override void Attack()
    {
        ActivateExplosion();
    }

    public void ActivateExplosion()
    {
        explosionHitBox.SetActive(true);
    }

    public void DeactivateExplosion()
    {
        explosionHitBox.SetActive(false);
        // We destroy the Ripper after the explosion has occurred and the Attack Duration finishes
        PoolManager.Instanse.ReturnObject(transform.root.gameObject);
    }
}
