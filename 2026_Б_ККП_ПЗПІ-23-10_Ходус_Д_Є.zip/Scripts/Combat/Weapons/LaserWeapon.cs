using UnityEngine;
using System.Collections.Generic;

public class LaserWeapon : Weapon
{
    [Header("Laser Prefab")]
    [SerializeField] private GameObject laserBeamPrefab;
    [SerializeField] private Transform shootPoint;
    [SerializeField] private GameObject hitEffectPrefab;
    
    [Header("Laser Settings")]
    [SerializeField] private LayerMask obstacleMask;
    [SerializeField] private float telegraphDuration = 1.0f;
    [SerializeField] public float aimSpeed = 10f;
    
    [Header("Damage Settings")]
    [SerializeField] private bool useTickDamage = false;

    private LaserBeam activeBeam;

    public override void Attack(Transform target)
    {
        if (laserBeamPrefab == null || shootPoint == null) return;

        Vector3 targetPos = target != null ? target.position + Vector3.up : shootPoint.position + shootPoint.forward * 10f;
        Vector3 direction = (targetPos - shootPoint.position).normalized;
        Quaternion rotation = Quaternion.LookRotation(direction);

        // Snap shootPoint to target immediately at the start of attack
        shootPoint.rotation = rotation;

        GameObject beamObj = PoolManager.Instanse.CreateObject(laserBeamPrefab, shootPoint.position, rotation);
        
        if (beamObj.TryGetComponent(out LaserBeam beam))
        {
            activeBeam = beam;
            // Note: Duration in Weapon base class is used here for the main beam life
            beam.SetUp(Damage, Duration, telegraphDuration, obstacleMask, hitEffectPrefab, direction, shootPoint, !useTickDamage);
        }
    }

    public void AimAt(Vector3 targetPos)
    {
        if (shootPoint == null || shootPoint.parent == null) return;
        
        // 1. Find the direction to the target
        Vector3 targetDir = (targetPos - shootPoint.position).normalized;
        
        // 2. Find the total rotation required in world space
        Quaternion worldLookRot = Quaternion.LookRotation(targetDir);
        
        // 3. Convert that to a local rotation relative to the enemy's body (parent)
        // This isolates the vertical tilt from the body's horizontal turn.
        Quaternion localLookRot = Quaternion.Inverse(shootPoint.parent.rotation) * worldLookRot;
        
        // 4. We only want the Pitch (vertical tilt) on the X axis. 
        // We zero out Y (Yaw) and Z (Roll) because the body handles horizontal turning.
        Vector3 euler = localLookRot.eulerAngles;
        // Euler angles can wrap (e.g., 350 instead of -10), so we normalize them for proper Slerp
        if (euler.x > 180) euler.x -= 360; 
        
        Quaternion targetLocalRotation = Quaternion.Euler(euler.x, 0, 0);
        
        // 5. Apply smooth rotation on the vertical axis ONLY
        shootPoint.localRotation = Quaternion.Slerp(shootPoint.localRotation, targetLocalRotation, Time.deltaTime * aimSpeed);
    }

    public void OnDisable()
    {
    }

    public override void EndAttack()
    {
        // Stop tracking the weapon, but let the beam finish its lifecycle
        if (activeBeam != null)
        {
            activeBeam.DetachFromSource();
            activeBeam = null;
        }

        // Reset rotation to default when attack sequence ends
        if (shootPoint != null)
        {
            shootPoint.localRotation = Quaternion.identity;
        }
    }
}
