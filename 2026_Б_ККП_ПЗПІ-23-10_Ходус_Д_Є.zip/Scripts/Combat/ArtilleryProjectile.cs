using UnityEngine;

public class ArtilleryProjectile : Projectile
{
    [HideInInspector] public Vector3 TargetPosition;
    [HideInInspector] public float ArcHeight;
    
    private Vector3 startPosition;
    private float elapsedTime;
    private float totalTime;

    public override void SetUp(float speed, float damage, float scaleFactor = 1f, float lifeTime = 5f)
    {
        base.SetUp(speed, damage, scaleFactor, lifeTime);
        
        startPosition = transform.position;
        elapsedTime = 0f;
        
        float distance = Vector3.Distance(new Vector3(startPosition.x, 0, startPosition.z), 
                                          new Vector3(TargetPosition.x, 0, TargetPosition.z));
        
        // Speed determines total duration
        totalTime = distance / (speed > 0 ? speed : 10f);
    }

    protected override void Movement()
    {
        if (totalTime <= 0) return;

        elapsedTime += Time.fixedDeltaTime;
        float t = Mathf.Clamp01(elapsedTime / totalTime);

        Vector3 nextPos = CalculateInterpolatedPosition(t);
        
        // Calculate velocity for rotation alignment
        Vector3 direction = (nextPos - transform.position).normalized;
        if (direction != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(direction);
        }

        transform.position = nextPos;

        // If we reached the end, return to pool (or let standard lifetime handle it)
        if (t >= 1.0f)
        {
            // Optional: return immediately on arrival
            // ReturnToPool();
        }
    }

    private Vector3 CalculateInterpolatedPosition(float t)
    {
        // Linear interpolation from start to target
        Vector3 linearPos = Vector3.Lerp(startPosition, TargetPosition, t);
        
        // Calculate distance-relative height to keep speed and launch angle constant
        // We treat ArcHeight as the peak height at 20m distance
        float distance = Vector3.Distance(new Vector3(startPosition.x, 0, startPosition.z), 
                                          new Vector3(TargetPosition.x, 0, TargetPosition.z));
        float relativeHeight = ArcHeight * (distance / 20f);
        
        // Parabolic offset
        // Formula: 4 * H * t * (1 - t) gives a peak of H at t = 0.5
        float heightOffset = 4f * relativeHeight * t * (1f - t);
        
        return linearPos + Vector3.up * heightOffset;
    }
}
