using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageFeedback : MonoBehaviour
{
    [Header("Damage Flash")]
    [SerializeField] private List<Renderer> flashRenderers;
    [ColorUsage(true, true)]
    [SerializeField] private Color hitColor = Color.white;
    [SerializeField] private float flashDuration = 0.15f;
    [SerializeField] private string colorPropertyName = "_Color";

    [Header("Damage Popup")]
    [SerializeField] private DamagePopup damagePopupPrefab;
    [SerializeField] private Vector3 popupOffset = new Vector3(0f, 2f, 0f);

    private List<Material> materialInstances = new List<Material>();
    private List<Color> baseColors = new List<Color>();
    private Coroutine flashCoroutine;

    public void Init()
    {
        materialInstances.Clear();
        baseColors.Clear();

        if (flashRenderers == null || flashRenderers.Count == 0)
        {
            // Try to find renderers if not assigned
            var r = GetComponentInChildren<Renderer>();
            if (r != null) flashRenderers = new List<Renderer> { r };
        }

        foreach (var renderer in flashRenderers)
        {
            if (renderer == null) continue;
            
            Material[] mats = renderer.materials;
            foreach (var mat in mats)
            {
                if (mat.HasProperty(colorPropertyName))
                {
                    materialInstances.Add(mat);
                    baseColors.Add(mat.GetColor(colorPropertyName));
                }
            }
        }
    }

    public void PlayFeedback(float damage)
    {
        // 1. Show Damage Popup
        if (damagePopupPrefab != null)
        {
            Instantiate(damagePopupPrefab, transform.position + popupOffset, Quaternion.identity).Setup(damage);
        }

        // 2. Start Flash
        if (materialInstances.Count > 0)
        {
            if (flashCoroutine != null) StopCoroutine(flashCoroutine);
            flashCoroutine = StartCoroutine(FlashCoroutine());
        }
    }

    private IEnumerator FlashCoroutine()
    {
        // Instant set to hit color
        foreach (var mat in materialInstances)
        {
            mat.SetColor(colorPropertyName, hitColor);
        }

        float elapsed = 0f;
        while (elapsed < flashDuration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / flashDuration;
            
            for (int i = 0; i < materialInstances.Count; i++)
            {
                materialInstances[i].SetColor(colorPropertyName, Color.Lerp(hitColor, baseColors[i], t));
            }
            yield return null;
        }

        // Ensure we reset to base color
        for (int i = 0; i < materialInstances.Count; i++)
        {
            materialInstances[i].SetColor(colorPropertyName, baseColors[i]);
        }
        flashCoroutine = null;
    }
}
