using UnityEngine;

public class LaserScaler : MonoBehaviour
{
    public float maxDistance = 100f; 
    public float rayFactor = 100f;
    public LayerMask obstacleMask;   

    public Transform Transform;

    public GameObject EndParticle;

    void Update()
    {
        Ray ray = new Ray(Transform.position, Transform.forward);
        RaycastHit hit;

        float distance = maxDistance;

        if (Physics.Raycast(ray, out hit, maxDistance * rayFactor, obstacleMask, QueryTriggerInteraction.Ignore))
        {
            distance = hit.distance / rayFactor;
            EndParticle.transform.position = hit.point;
        }

        Vector3 newScale = Transform.localScale;
        newScale.z = distance;
        Transform.localScale = newScale;
    }

}
