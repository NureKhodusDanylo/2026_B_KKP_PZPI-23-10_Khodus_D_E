using System.Collections;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField] protected float speed;
    protected float damage;
    
    public GameObject Owner { get; set; }
    
    // Performance optimization: Using simple float timer instead of Coroutine 
    // to prevent Garbage Collection spikes from new WaitForSeconds.
    private float lifeTimer;
    private bool isCountingDown;

    public virtual void SetUp(float speed, float damage, float scaleFactor = 1f, float lifeTime = 5f)
    {
        this.speed = speed;
        this.damage = damage;
        transform.localScale = Vector3.one * scaleFactor;
        
        lifeTimer = lifeTime;
        isCountingDown = true;
    }

    private void OnDisable()
    {
        isCountingDown = false;
    }

    protected virtual void FixedUpdate()
    {
        if (isCountingDown)
        {
            lifeTimer -= Time.fixedDeltaTime;
            if (lifeTimer <= 0)
            {
                isCountingDown = false;
                ReturnToPool();
            }
        }

        Movement();
    }

    protected virtual void Movement()
    {
        transform.position += transform.forward * speed * Time.fixedDeltaTime;
    }

    protected virtual void OnTriggerEnter(Collider other)
    {
        // Don't collide with other triggers (like aggro checkers)
        if (other.isTrigger) return;

        // Ignore collisions with the shooter and their equipment/child colliders
        if (other.gameObject == Owner || (Owner != null && other.transform.IsChildOf(Owner.transform)))
            return;

        if (other.TryGetComponent(out IDamageable damageable))
        {
            damageable.TakeDamage(damage);
            ReturnToPool();
        }
        else
        {
            ReturnToPool();
        }
    }

    public void ReturnToPool()
    {
        isCountingDown = false;

        if (PoolManager.Instanse != null)
            PoolManager.Instanse.ReturnObject(gameObject);
        else
            Destroy(gameObject); // Fallback if no pool
    }
}
