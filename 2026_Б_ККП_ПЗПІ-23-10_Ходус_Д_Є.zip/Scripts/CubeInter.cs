using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeInter : MonoBehaviour, IInteractable
{
    [SerializeField]
    private InteractMenuAnimManager _interactMenuAnimManager;

    InteractMenuAnimManager IInteractable.interactMenuAnimManager
    {
        get => _interactMenuAnimManager;
        set => _interactMenuAnimManager = value;
    }


    public void Interact()
    {
        Debug.Log("Хули тыкаешь");
    }

}
