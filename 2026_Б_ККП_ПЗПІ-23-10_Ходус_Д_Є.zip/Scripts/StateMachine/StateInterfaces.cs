using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHaveFollowStateRefs
{
    Transform Transform { get; set; }
    Transform Target { get; set; }
    GameObject Model { get; set; }
    Rigidbody Rb { get; set; }
    void MoveEnemy(Vector3 targetMovement, float speed, ref Vector3 currentVelocityRef, float smoothTime);
}

