using System.Collections.Generic;
using UnityEngine;
using static State;

public class StateManager : MonoBehaviour, IInitializable
{
    public List<State> OmniStates = new List<State>();
    public State CurrentState { get; set; }

    public virtual void Init()
    {
    }

    protected virtual void FixedUpdate()
    {
        CurrentState?.EveryTick();

        if (OmniStates != null)
        {
            foreach (var state in OmniStates)
            {
                state?.EveryTick();
            }
        }
    }

    protected virtual void GoToNextState()
    {
        CurrentState?.OnEnd();

        State newState = CurrentState.NextState;
        if (newState == null) return;
        CurrentState = newState;

        CurrentState.OnStart();
    }

    protected virtual void GoToNextState(State newState)
    {
        CurrentState?.OnEnd();

        newState.PreviousState = CurrentState;
        CurrentState = newState;

        CurrentState.OnStart();
    }
}
