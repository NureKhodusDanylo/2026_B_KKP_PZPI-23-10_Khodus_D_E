using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class EnemyStateManager : StateManager, IHaveFollowStateRefs, IInitializable, IDisposable
{
    // REFS
    [SerializeField] private Transform _transform;
    [SerializeField] private Transform _target;
    [SerializeField] private GameObject _model;
    [SerializeField] private Rigidbody _rb;
    [SerializeField] private State _currentState;

    private bool isDead = false;
    private Vector3 cooldownVelocity = Vector3.zero;

    public Transform Transform { get => _transform; set => _transform = value; }
    public Transform Target { get => _target; set => _target = value; }
    public GameObject Model { get => _model; set => _model = value; }
    public Rigidbody Rb { get => _rb; set => _rb = value; }
    public State CurrentState { get => _currentState; set => _currentState = value; }

    // STATES
    protected FollowState followState;
    protected StayState stayState;
    protected AttackState attackState;

    //Omni States
    protected LookAtState lookAtState;

    //STATES VERBS
    public ColliderCheker followCheker;
    public ColliderCheker attackCheker;

    //Properties
    [SerializeField] protected float rotationSpeed = 5f;

    //Fields
    protected GameObject MyEnemy;

    // Events
    public event Action Run;
    public event Action Stay;

    public event Action AttackStart;
    public event Action AttackEnd;
    public event Action Die;

    protected override void FixedUpdate()
    {
        base.FixedUpdate();

        // Active pursuit of the player during attack cooldown!
        if (CurrentState is AttackState attackState && attackState.IsInCooldown && Target != null && !isDead)
        {
            Vector3 directionToTarget = Target.position - _transform.position;
            directionToTarget.y = 0f;

            if (directionToTarget.sqrMagnitude > 0.01f)
            {
                // Chase target during cooldown using FollowState speed
                float speed = (followState != null) ? followState.currentMaxSpeed : 5f;
                Vector3 targetMovement = directionToTarget.normalized * speed;
                MoveEnemy(targetMovement, speed, ref cooldownVelocity, 0.1f);
            }
        }
    }

    public override void Init()
    {
        followCheker.SetUp(new List<string> { "Player" });
        attackCheker.SetUp(new List<string> { "Player" });

        InitStates();

        GoToNextState(stayState);

        attackState.AttackStart += DoAnAttack;
        attackState.AttackEnd += StayAfterAttack;

        followCheker.TriggerEnter += FollowPlayer;
        followCheker.TriggerExit += EnemyStay;

        attackCheker.TriggerEnter += AttackPlayer;
        attackCheker.TriggerExit += FollowPlayer;

        this.enabled = true;
    }

    public void TriggerDie()
    {
        if (isDead) return;
        isDead = true;

        CurrentState?.OnEnd();
        CurrentState = null;
        this.enabled = false;

        Die?.Invoke();

        // Register kill if killed underground inside the dungeon
        if (transform.position.y < -900f)
        {
            DungeonEscapeController.RegisterKill();
        }
    }

    protected virtual void InitStates()
    {
        // Subclasses should create followState, stayState, attackState
        // then call base.InitStates() for omni-state setup
        lookAtState = new LookAtState(null, null, this);
        OmniStates.Add(lookAtState);
    }

    public void Dispose()
    {
        attackState.AttackStart -= DoAnAttack;
        attackState.AttackEnd -= StayAfterAttack;

        followCheker.TriggerEnter -= FollowPlayer;
        followCheker.TriggerExit -= EnemyStay;

        attackCheker.TriggerEnter -= AttackPlayer;
        attackCheker.TriggerExit -= FollowPlayer;
    }

    private void FollowPlayer(Collider other)
    {
        MyEnemy = other.gameObject;
        Target = MyEnemy.transform;

        GoToNextState(followState);
        Run?.Invoke();
    }

    private void EnemyStay(Collider other)
    {
        MyEnemy = null;
        Target = null;
        GoToNextState(stayState);
        Stay?.Invoke();
    }

    public void FaceTarget()
    {
        if (Target == null || Model == null) return;

        Vector3 direction = Target.position - Model.transform.position;
        direction.y = 0f;

        if (direction == Vector3.zero) return;

        Quaternion targetRotation = Quaternion.LookRotation(direction);
        Model.transform.rotation = Quaternion.Slerp(Model.transform.rotation, targetRotation, Time.deltaTime * rotationSpeed);
    }

    public void MoveEnemy(Vector3 targetMovement, float speed, ref Vector3 currentVelocityRef, float smoothTime)
    {
        // Dynamic frictionless material setup for enemy colliders
        Collider col = GetComponent<Collider>();
        if (col != null && (col.sharedMaterial == null || col.sharedMaterial.name != "FrictionlessEnemy"))
        {
            PhysicMaterial frictionlessMat = new PhysicMaterial("FrictionlessEnemy");
            frictionlessMat.dynamicFriction = 0f;
            frictionlessMat.staticFriction = 0f;
            frictionlessMat.frictionCombine = PhysicMaterialCombine.Minimum;
            frictionlessMat.bounciness = 0f;
            frictionlessMat.bounceCombine = PhysicMaterialCombine.Minimum;
            col.sharedMaterial = frictionlessMat;
        }

        // Smooth only horizontal velocity
        Vector3 horizontalVelocity = new Vector3(_rb.velocity.x, 0f, _rb.velocity.z);
        Vector3 targetHorizontal = new Vector3(targetMovement.x, 0f, targetMovement.z);
        if (targetHorizontal.sqrMagnitude > 0.01f)
        {
            targetHorizontal = targetHorizontal.normalized * speed;
        }

        Vector3 smoothedHorizontal = Vector3.SmoothDamp(
            horizontalVelocity,
            targetHorizontal,
            ref currentVelocityRef,
            smoothTime
        );

        // Ground check using SphereCast
        CapsuleCollider capsule = GetComponent<CapsuleCollider>();
        float radius = capsule != null ? capsule.radius : 0.3f;
        float height = capsule != null ? capsule.height : 2.0f;
        Vector3 center = capsule != null ? capsule.center : new Vector3(0f, 1f, 0f);
        float castDistance = 0.3f;

        float bottomYOffset = center.y - (height / 2f);
        Vector3 castOrigin = _transform.position + Vector3.up * (bottomYOffset + radius + 0.1f);
        RaycastHit hit;
        int groundMask = LayerMask.GetMask("Ground");
        if (groundMask == 0) groundMask = 128; // Fallback to Layer 7 (Ground)

        bool isGrounded = Physics.SphereCast(
            castOrigin,
            radius * 0.9f, // slightly smaller sphere to prevent wall friction
            Vector3.down,
            out hit,
            0.1f + castDistance,
            groundMask
        );

        if (isGrounded)
        {
            // Grounded: Project the smoothed horizontal velocity onto the slope normal
            Vector3 movementOnSurface = Vector3.ProjectOnPlane(smoothedHorizontal, hit.normal);
            
            // Crucial step: Preserve full horizontal movement speed on steep slopes/stairs
            if (smoothedHorizontal.magnitude > 0.01f)
            {
                movementOnSurface = movementOnSurface.normalized * smoothedHorizontal.magnitude;
            }
            
            _rb.velocity = movementOnSurface;
        }
        else
        {
            // In air: preserve gravity Y-velocity
            _rb.velocity = new Vector3(smoothedHorizontal.x, _rb.velocity.y, smoothedHorizontal.z);
        }

        // Smoothly rotate enemy model towards movement direction
        if (smoothedHorizontal.magnitude > 0.1f && Model != null)
        {
            Quaternion targetRotation = Quaternion.LookRotation(smoothedHorizontal.normalized);
            Model.transform.rotation = Quaternion.Slerp(
                Model.transform.rotation,
                targetRotation,
                rotationSpeed * Time.fixedDeltaTime
            );
        }
    }

    private void AttackPlayer(Collider other)
    {
        GoToNextState(attackState);
        StartCoroutine(StopRb(Rb, 0.3f));
    }   
    
    private void DoAnAttack()
    {
        AttackStart?.Invoke();
    }

    private void StayAfterAttack()
    {
        AttackEnd?.Invoke();
    }

    private IEnumerator StopRb(Rigidbody rb, float duration)
    {
        Vector3 initialVelocity = rb.velocity;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            float t = elapsed / duration;
            t = 1f - Mathf.Pow(1f - t, 3); 

            rb.velocity = Vector3.Lerp(initialVelocity, Vector3.zero, t);
            elapsed += Time.fixedDeltaTime;
            //Debug.Log(rb.velocity);

            yield return new WaitForFixedUpdate();
        }

        rb.velocity = Vector3.zero;
    }

}
