using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;


public class MeleeEnemyStateManager : EnemyStateManager
{
    [SerializeField] private MeleeWeapon meleeWeapon;


    protected override void InitStates()
    {
        if (meleeWeapon == null)
        {
            meleeWeapon = GetComponentInChildren<MeleeWeapon>();
        }

        followState = new FollowState(null, null, this);
        stayState = new StayState(null, null);

        attackState = new MeleeAttackState(null, null, meleeWeapon);

        if (meleeWeapon != null)
        {
            meleeWeapon.Init();
        }

        base.InitStates();
    }
}
