using System.Collections.Generic;
using UnityEngine;

public class LaserEnemyStateManager : RangeEnemyStateManager
{
    protected override void InitStates()
    {
        followState = new FollowState(null, null, this);
        stayState = new StayState(null, null);

        // Use the specialized LaserAttackState with the inherited 'weapon' field
        attackState = new LaserAttackState(null, null, weapon, this);

        // Initialize OmniStates (Logic from EnemyStateManager)
        lookAtState = new LookAtState(null, null, this);
        OmniStates.Add(lookAtState);
    }
}
