using System.Collections.Generic;
using UnityEngine;

public class RangeEnemyStateManager : EnemyStateManager
{
    [SerializeField] protected Weapon weapon;

    protected override void InitStates()
    {
        followState = new FollowState(null, null, this);
        stayState = new StayState(null, null);

        // Unified attack state handles target passing to the weapon
        attackState = new RangeAttackState(null, null, weapon, this);

        base.InitStates();
    }
}