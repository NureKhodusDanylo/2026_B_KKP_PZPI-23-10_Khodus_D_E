using UnityEngine;

public class RipperStateManager : EnemyStateManager
{
    [SerializeField] private RipperWeapon ripperWeapon;

    protected override void InitStates()
    {
        followState = new FollowState(null, null, this);
        stayState = new PatrolState(null, null, this);

        // We use RipperAttackState so StartAttack and StopAttack correctly toggle the explosion hit box
        attackState = new RipperAttackState(null, null, ripperWeapon);

        if (ripperWeapon != null)
        {
            ripperWeapon.Init();
        }

        base.InitStates();
    }
}
