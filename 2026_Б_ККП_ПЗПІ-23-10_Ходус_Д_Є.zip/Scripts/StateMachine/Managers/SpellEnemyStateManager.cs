using System.Collections.Generic;
using UnityEngine;

public class SpellEnemyStateManager : RangeEnemyStateManager
{
    protected override void InitStates()
    {
        followState = new FollowState(null, null, this);
        stayState = new StayState(null, null);

        // Uses our specialized SpellAttackState
        attackState = new SpellAttackState(null, null, weapon, this);

        // Required to register states in the base manager
        OmniStates = new List<State> { followState, stayState, attackState };
        
        // Ensure lookAtState is initialized if inherited (usually added to OmniStates)
        lookAtState = new LookAtState(null, null, this);
        OmniStates.Add(lookAtState);
    }
}
