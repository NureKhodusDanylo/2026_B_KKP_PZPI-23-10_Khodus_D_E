using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEngine.Rendering.DebugUI;

public class AttackState : State
{
    protected Weapon baseWeapon;

    public bool IsInCooldown { get; protected set; } = false;
    protected bool active = false;

    public event Action AttackStart;
    public event Action AttackEnd;

    protected Coroutine attackCoroutine;

    public AttackState(State previousState, List<State> availableStates, Weapon weapon)
        : base(previousState, availableStates)
    {
        Name = "AttackState";
        Type = StateType.Data;
        baseWeapon = weapon;
    }

    public override void OnStart()
    {
        Debug.Log("try init " + attackCoroutine);
        active = true;
        IsInCooldown = false;
        if (attackCoroutine == null)
        {
            Debug.Log("init");
            attackCoroutine = CoroutineRunner.Instance.RunCoroutine(Attack());
        }
    }

    public override void OnEnd()
    {
        StopAttack();
        active = false;
        IsInCooldown = false;
    }

    private void StopAttackScript()
    {
        if (attackCoroutine != null)
        {
            CoroutineRunner.Instance.StopRunning(attackCoroutine);
            attackCoroutine = null;
        }
    }

    protected IEnumerator Attack()
    {
        while (active)
        {
            IsInCooldown = false;
            AttackStart?.Invoke();
            yield return new WaitForSeconds(baseWeapon.Delay);
            StartAttack();

            yield return new WaitForSeconds(baseWeapon.Duration);
            StopAttack();
            IsInCooldown = true;
            AttackEnd?.Invoke();

            yield return new WaitForSeconds(baseWeapon.Cooldown);
        }
        StopAttackScript();
    }

    protected virtual void StartAttack()
    {
    }

    protected virtual void StopAttack()
    {
        baseWeapon.EndAttack();
    }
}
