using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StayState : State
{
    public StayState(State previousState, List<State> avalibleStates) 
        : base(previousState, avalibleStates)
    {
        Name = "StayState";
        Type = StateType.Data;
    }
    

}
