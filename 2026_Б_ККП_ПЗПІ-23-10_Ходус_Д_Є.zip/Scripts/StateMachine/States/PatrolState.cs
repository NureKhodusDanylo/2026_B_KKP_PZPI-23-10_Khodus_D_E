using System.Collections.Generic;
using UnityEngine;

public class PatrolState : StayState
{
    private IHaveFollowStateRefs _refs;
    private Rigidbody rb => _refs.Rb;
    private Transform transform => _refs.Transform;

    private float _patrolRadius;
    private float _patrolSpeed;
    private float _smoothTime = 0.5f;
    private float _waitTime;
    
    private Vector3 _startPosition;
    private Vector3 _targetPosition;
    private Vector3 _currentVelocity;
    private float _waitTimer = 0f;
    private bool _isWaiting = false;

    public PatrolState(State previousState, List<State> availableStates, IHaveFollowStateRefs refs, float radius = 7f, float speed = 2.5f, float waitTime = 2f) 
        : base(previousState, availableStates)
    {
        Name = "PatrolState";
        Type = StateType.EveryTick;
        _refs = refs;
        _patrolRadius = radius;
        _patrolSpeed = speed;
        _waitTime = waitTime;
    }

    public override void OnStart()
    {
        _startPosition = transform.position;
        SetNewPatrolTarget();
    }

    public override void EveryTick()
    {
        if (_isWaiting)
        {
            _waitTimer -= Time.deltaTime;
            if (_waitTimer <= 0)
            {
                _isWaiting = false;
                SetNewPatrolTarget();
            }
            
            // Damping velocity to 0 while waiting
            rb.velocity = Vector3.SmoothDamp(rb.velocity, Vector3.zero, ref _currentVelocity, _smoothTime);
            return;
        }

        Vector3 directionToTarget = _targetPosition - transform.position;
        directionToTarget.y = 0f;

        if (directionToTarget.magnitude < 0.5f)
        {
            _isWaiting = true;
            _waitTimer = _waitTime;
            return;
        }

        Vector3 targetMovement = directionToTarget.normalized * _patrolSpeed;

        // Delegate entire physical movement calculation to manager
        _refs.MoveEnemy(targetMovement, _patrolSpeed, ref _currentVelocity, _smoothTime);
        
        // Rotate towards movement direction since EnemyStateManager.FaceTarget ignores null Target
        if (directionToTarget.sqrMagnitude > 0.01f)
        {
            Quaternion targetRotation = Quaternion.LookRotation(directionToTarget.normalized);
            _refs.Model.transform.rotation = Quaternion.Slerp(_refs.Model.transform.rotation, targetRotation, Time.deltaTime * 5f);
        }
    }

    private void SetNewPatrolTarget()
    {
        Vector2 randomCircle = Random.insideUnitCircle * _patrolRadius;
        _targetPosition = _startPosition + new Vector3(randomCircle.x, 0, randomCircle.y);
    }
}
