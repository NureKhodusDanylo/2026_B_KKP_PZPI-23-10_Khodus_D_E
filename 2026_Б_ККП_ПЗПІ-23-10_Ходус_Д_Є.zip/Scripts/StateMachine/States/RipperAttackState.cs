using System.Collections.Generic;
using UnityEngine;

public class RipperAttackState : AttackState
{
    protected RipperWeapon ripperWeapon;

    public RipperAttackState(State previousState, List<State> availableStates, RipperWeapon _ripperWeapon) 
        : base(previousState, availableStates, _ripperWeapon)
    {
        Name = "RipperAttackState";
        ripperWeapon = _ripperWeapon;
    }

    protected override void StartAttack()
    {
        ripperWeapon.ActivateExplosion();
    }

    protected override void StopAttack()
    {
        ripperWeapon.DeactivateExplosion();
    }
}
