using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.VersionControl.Asset;

public class MeleeAttackState : AttackState
{
    protected MeleeWeapon meleeWeapon;

    public MeleeAttackState(State previousState, List<State> availableStates, MeleeWeapon _meleeWeapon) 
        : base(previousState, availableStates, _meleeWeapon)
    {
        Name = "MeleeAttackState";
        meleeWeapon = _meleeWeapon;
    }

    protected override void StartAttack()
    {
        meleeWeapon.ActivateBlade();
    }

    protected override void StopAttack()
    {
        meleeWeapon.DeactivateBlade();
    }
}