using System.Collections.Generic;
using UnityEngine;

public class LaserAttackState : AttackState
{
    private Weapon weapon;
    private EnemyStateManager manager;

    public LaserAttackState(State previousState, List<State> availableStates, Weapon _weapon, EnemyStateManager _manager) 
        : base(previousState, availableStates, _weapon)
    {
        Name = "LaserAttackState";
        Type = StateType.EveryTick;
        weapon = _weapon;
        manager = _manager;
    }

    public override void EveryTick()
    {
        base.EveryTick();

        if (weapon is LaserWeapon laserWeapon && manager.Target != null)
        {
            // 1. Horizontal rotation (Body) using Weapon's aimSpeed
            Vector3 bodyDir = manager.Target.position - manager.Model.transform.position;
            bodyDir.y = 0;
            if (bodyDir != Vector3.zero)
            {
                manager.Model.transform.rotation = Quaternion.Slerp(
                    manager.Model.transform.rotation, 
                    Quaternion.LookRotation(bodyDir), 
                    Time.deltaTime * laserWeapon.aimSpeed);
            }

            // 2. Vertical rotation (Barrel/ShootPoint) using Weapon's aimSpeed
            laserWeapon.AimAt(manager.Target.position + Vector3.up);
        }
    }

    protected override void StartAttack()
    {
        if (weapon != null)
        {
            weapon.Attack(manager.Target);
        }
    }
}
