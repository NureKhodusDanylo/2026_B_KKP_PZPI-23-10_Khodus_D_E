using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowState : State
{
    // MOVEMENT PARAMETERS
    private float smoothTime = 0.1f;
    private float maxSpeed = 5f;
    private float runSpeed = 7f;

    // REFS
    private IHaveFollowStateRefs _refs;
    private Rigidbody rb => _refs.Rb;
    private Transform transform => _refs.Transform;
    public Transform Target => _refs.Target;

    // SEPARATION PARAMETERS
    private float separationRadius = 2.5f;
    private float separationWeight = 5f;
    private static Collider[] overlapBuffer = new Collider[16]; // Zero-allocation buffer
    private static int enemyLayerMask = -1;

    // PERFORMANCE OPTIMIZATION: Frame Skipping
    private int updateInterval = 1; // Check separation every frame for maximum smoothness
    private int frameCounter = 0;
    private Vector3 lastSeparationForce = Vector3.zero;

    public float currentMaxSpeed = 0f;
    private Vector3 currentVelocity = Vector3.zero;

    public FollowState(State previousState, List<State> availableStates, IHaveFollowStateRefs followStateRefs) 
        : base(previousState, availableStates)
    {
        Name = "FollowState";
        Type = StateType.EveryTick;
        _refs = followStateRefs;
        currentMaxSpeed = runSpeed;

        if (enemyLayerMask == -1)
            enemyLayerMask = LayerMask.GetMask("Enemy"); 
        
        // Fallback if no Enemy layer exists: use all but ignore projectiles/props if known.
        if (enemyLayerMask == 0) enemyLayerMask = ~0; 
    }

    public override void EveryTick()
    {
        if (Target == null)
        {
            // Optimization: If no target, stop moving immediately to save physics
            if (rb.velocity.sqrMagnitude > 0.01f)
                rb.velocity = Vector3.SmoothDamp(rb.velocity, Vector3.zero, ref currentVelocity, smoothTime);
            return;
        }

        Vector3 directionToTarget = (Target.position - transform.position);
        directionToTarget.y = 0f;

        Vector3 targetMovement = directionToTarget.normalized * currentMaxSpeed;
        
        // PERFORMANCE OPTIMIZATION: Only calculate separation periodically
        if (frameCounter++ % updateInterval == 0)
        {
            lastSeparationForce = GetSeparationForce();
        }
        
        targetMovement += lastSeparationForce;

        if (targetMovement.magnitude > currentMaxSpeed)
        {
            targetMovement = targetMovement.normalized * currentMaxSpeed;
        }

        // Delegate entire physical movement calculation to manager
        _refs.MoveEnemy(targetMovement, currentMaxSpeed, ref currentVelocity, smoothTime);
    }

    private Vector3 GetSeparationForce()
    {
        Vector3 separation = Vector3.zero;
        int count = 0;
        
        // PERFORMANCE OPTIMIZATION: Non-Allocating Overlap with Layer Mask
        int numFound = Physics.OverlapSphereNonAlloc(transform.position, separationRadius, overlapBuffer, enemyLayerMask);

        for (int i = 0; i < numFound; i++)
        {
            Collider hitCollider = overlapBuffer[i];
            
            // Optimization: Use Tags or fast Layer checks instead of GetComponentInParent
            if (hitCollider.gameObject == transform.gameObject) continue;
            
            // If the layer mask is specific to Enemies, we don't even need GetComponent!
            Vector3 away = transform.position - hitCollider.transform.position;
            away.y = 0;
            float distance = away.magnitude;

            if (distance > 0 && distance < separationRadius)
            {
                separation += (away.normalized / distance);
                count++;
            }
        }

        if (count > 0)
        {
            separation /= count;
            separation = separation.normalized * separationWeight;
        }

        return separation;
    }
}
