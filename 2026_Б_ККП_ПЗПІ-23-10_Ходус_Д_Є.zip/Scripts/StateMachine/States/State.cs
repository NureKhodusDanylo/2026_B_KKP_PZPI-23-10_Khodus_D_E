using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class State
{
    public enum StateType
    {
        Data,
        EveryTick
    }

    public string Name { get; protected set; }
    public StateType Type { get; protected set; }

    public State PreviousState { get; set; }
    public List<State> AvalibleStates { get; private set; }
    public State NextState { get; private set; }

    public State( State previousState, List<State> avalibleStates)
    {
        PreviousState = previousState;
        AvalibleStates = avalibleStates;
    }

    public virtual void EveryTick()
    {
    }

    public virtual void OnStart()
    {
    }

    public virtual void OnEnd()
    {
    }

    public virtual void SetNextState() 
    {
    }
}
