using System.Collections.Generic;
using UnityEngine;

public class RangeAttackState : AttackState
{
    private Weapon weapon;
    private EnemyStateManager manager;

    public RangeAttackState(State previousState, List<State> availableStates, Weapon _weapon, EnemyStateManager _manager) 
        : base(previousState, availableStates, _weapon)
    {
        Name = "RangeAttackState";
        weapon = _weapon;
        manager = _manager;
    }

    protected override void StartAttack()
    {
        // Now works for any weapon (Standard Range, Artillery, etc.)
        if (weapon != null)
        {
            weapon.Attack(manager.Target);
        }
    }
}
