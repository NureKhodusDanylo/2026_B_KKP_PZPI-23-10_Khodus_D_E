using System.Collections.Generic;
using UnityEngine;

public class LookAtState : State
{
    private EnemyStateManager manager;

    public LookAtState(State previousState, List<State> availableStates, EnemyStateManager _manager) 
        : base(previousState, availableStates)
    {
        Name = "LookAtState";
        Type = StateType.EveryTick;
        manager = _manager;
    }

    public override void EveryTick()
    {
        manager.FaceTarget();
    }
}
