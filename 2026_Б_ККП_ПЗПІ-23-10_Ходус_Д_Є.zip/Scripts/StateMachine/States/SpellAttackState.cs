using System.Collections.Generic;
using UnityEngine;

public class SpellAttackState : AttackState
{
    private Weapon weapon;
    private EnemyStateManager manager;

    public SpellAttackState(State previousState, List<State> availableStates, Weapon _weapon, EnemyStateManager _manager) 
        : base(previousState, availableStates, _weapon)
    {
        Name = "SpellAttackState";
        Type = StateType.EveryTick;
        weapon = _weapon;
        manager = _manager;
    }

    public override void EveryTick()
    {
        base.EveryTick();

        if (manager.Target != null)
        {
            // Face the player while casting
            Vector3 targetDir = manager.Target.position - manager.Model.transform.position;
            targetDir.y = 0;
            if (targetDir != Vector3.zero)
            {
                manager.Model.transform.rotation = Quaternion.Slerp(
                    manager.Model.transform.rotation, 
                    Quaternion.LookRotation(targetDir), 
                    Time.deltaTime * 5f);
            }
        }
    }

    protected override void StartAttack()
    {
        if (weapon != null)
        {
            weapon.Attack(manager.Target);
        }
    }
}
