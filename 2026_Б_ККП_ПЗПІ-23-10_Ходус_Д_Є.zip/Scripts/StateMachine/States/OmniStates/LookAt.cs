using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LookAt : MonoBehaviour
{
    public Transform MyModel;
    public Transform Target;
    public float rotationSpeed = 5f;

    public void SetUp(Transform _myModel, Transform _target, float _rotationSpeed = 5f)
    {
        MyModel = _myModel;
        Target = _target;
    }

    private void Awake()
    {
        enabled = false;
    }
    private void FixedUpdate()
    {
        if (MyModel == null || Target == null)
        {
            Debug.LogError("LookAt script is not setup");
            enabled = false;
        }

        Vector3 direction = Target.transform.position - MyModel.position;

        if (direction == Vector3.zero) return;

        Quaternion targetRotation = Quaternion.LookRotation(direction);
        MyModel.rotation = Quaternion.Slerp(MyModel.rotation, targetRotation, Time.deltaTime * rotationSpeed);
    }
}
