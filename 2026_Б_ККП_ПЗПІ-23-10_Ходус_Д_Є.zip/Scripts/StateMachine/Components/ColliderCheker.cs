using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ColliderCheker : MonoBehaviour
{
    private List<string> filterTags = new List<string>();

    public event Action<Collider> TriggerEnter;
    public event Action<Collider> TriggerExit;

    public void SetUp(List<string> _targetTags)
    {
        filterTags = _targetTags;
    }

    private void OnTriggerEnter(Collider other)
    {
        // Silenced during initialization frames. 
        // Manager will set up tags in Init().
        if (filterTags == null || filterTags.Count == 0)
        {
            return;
        }

        if (filterTags.Contains(other.tag))
        {
            TriggerEnter?.Invoke(other);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (filterTags == null || filterTags.Count == 0)
        {
            return;
        }

        if (filterTags.Contains(other.tag))
        {
            TriggerExit?.Invoke(other);
        }
    }
}
