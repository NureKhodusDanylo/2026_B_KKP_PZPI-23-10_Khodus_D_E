using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEditor;

public class DebugSkyboxTool
{
    [MenuItem("Debug/Run Skybox Diagnostic")]
    public static void RunDiagnostic()
    {
        Debug.Log("=== SKYBOX DIAGNOSTIC START ===");
        
        // 1. RenderSettings Skybox Material
        Material skyboxMat = RenderSettings.skybox;
        if (skyboxMat == null)
        {
            Debug.LogError("RenderSettings.skybox is NULL!");
        }
        else
        {
            Debug.Log($"RenderSettings.skybox Material: '{skyboxMat.name}' with Shader: '{skyboxMat.shader.name}'");
            
            // Log float/color properties
            string[] floatProps = { "_Blend", "_Exposure", "_Rotation" };
            foreach (var prop in floatProps)
            {
                if (skyboxMat.HasProperty(prop))
                    Debug.Log($"{prop}: {skyboxMat.GetFloat(prop)}");
                else
                    Debug.LogWarning($"{prop} property not found in shader!");
            }
            
            if (skyboxMat.HasProperty("_Tint"))
                Debug.Log($"_Tint: {skyboxMat.GetColor("_Tint")}");
            
            // Check texture values
            string[] texNames = { "_FrontTex", "_BackTex", "_LeftTex", "_RightTex", "_UpTex", "_DownTex",
                                  "_FrontTex2", "_BackTex2", "_LeftTex2", "_RightTex2", "_UpTex2", "_DownTex2" };
            foreach (var name in texNames)
            {
                if (skyboxMat.HasProperty(name))
                {
                    Texture tex = skyboxMat.GetTexture(name);
                    Debug.Log($"{name}: {(tex != null ? tex.name + " (" + tex.GetType().Name + ")" : "null")}");
                }
                else
                {
                    Debug.LogWarning($"{name} property not found!");
                }
            }
        }
        
        // 2. Ambient Settings
        Debug.Log($"RenderSettings.ambientMode: {RenderSettings.ambientMode}");
        Debug.Log($"RenderSettings.ambientSkyColor: {RenderSettings.ambientSkyColor}");
        Debug.Log($"RenderSettings.ambientEquatorColor: {RenderSettings.ambientEquatorColor}");
        Debug.Log($"RenderSettings.ambientGroundColor: {RenderSettings.ambientGroundColor}");
        Debug.Log($"RenderSettings.ambientIntensity: {RenderSettings.ambientIntensity}");
        
        // 3. Fog Settings
        Debug.Log($"RenderSettings.fog: {RenderSettings.fog}");
        Debug.Log($"RenderSettings.fogColor: {RenderSettings.fogColor}");
        Debug.Log($"RenderSettings.fogMode: {RenderSettings.fogMode}");
        Debug.Log($"RenderSettings.fogDensity: {RenderSettings.fogDensity}");
        Debug.Log($"RenderSettings.fogStartDistance: {RenderSettings.fogStartDistance}");
        Debug.Log($"RenderSettings.fogEndDistance: {RenderSettings.fogEndDistance}");
        
        // 4. Cameras
        Camera[] cameras = Camera.allCameras;
        Debug.Log($"Total active cameras: {cameras.Length}");
        foreach (var cam in cameras)
        {
            var urpCam = cam.GetComponent<UniversalAdditionalCameraData>();
            Debug.Log($"Camera: '{cam.name}', clearFlags: {cam.clearFlags}, background: {cam.backgroundColor}");
            if (urpCam != null)
            {
                Debug.Log($"Camera '{cam.name}' URP: renderPostProcessing: {urpCam.renderPostProcessing}, renderShadows: {urpCam.renderShadows}, antialiasing: {urpCam.antialiasing}");
            }
        }
        
        // 5. URP Asset and Renderer Settings
        var pipelineAsset = GraphicsSettings.currentRenderPipeline as UniversalRenderPipelineAsset;
        if (pipelineAsset == null)
        {
            Debug.LogError("Current Render Pipeline is not URP!");
        }
        else
        {
            Debug.Log($"URP Asset: '{pipelineAsset.name}'");
            // Check opaque/depth texture settings on URP Asset
            Debug.Log($"URP Asset supportsCameraOpaqueTexture: {pipelineAsset.supportsCameraOpaqueTexture}");
            Debug.Log($"URP Asset supportsCameraDepthTexture: {pipelineAsset.supportsCameraDepthTexture}");
        }
        
        // 6. DayNightCycleController status
        var controller = GameObject.FindObjectOfType<MagicUniverse.World.DayNightCycleController>();
        if (controller == null)
        {
            Debug.LogError("DayNightCycleController not found in active scene!");
        }
        else
        {
            Debug.Log($"Found DayNightCycleController on GameObject: '{controller.gameObject.name}'");
            Debug.Log($"Controller timeOfDay: {controller.timeOfDay}");
            Debug.Log($"Controller isTimeFlowing: {controller.isTimeFlowing}");
            Debug.Log($"Controller skyboxExposure: {controller.skyboxExposure}");
        }
        
        Debug.Log("=== SKYBOX DIAGNOSTIC END ===");
    }
}