using System;
using Assets.Scripts.AMagic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Инструмент: вставляет 4 слота осколков прямо в первые 4 ячейки InventoryPanel.
/// Tools -> Magic Universe -> Place Shards In Inventory Slots
/// </summary>
public class ShardSlotInjector
{
#if UNITY_EDITOR
    [MenuItem("Tools/Magic Universe/Place Shards In Inventory Slots")]
    public static void InjectShardSlots()
    {
        // Найти InventoryPanel
        InventoryManager im = UnityEngine.Object.FindObjectOfType<InventoryManager>(true);
        if (im == null) { Debug.LogError("[ShardSlotInjector] InventoryManager not found!"); return; }

        SerializedObject imSO = new SerializedObject(im);
        GameObject invPanel = imSO.FindProperty("inventoryPanel").objectReferenceValue as GameObject;
        if (invPanel == null) { Debug.LogError("[ShardSlotInjector] inventoryPanel field is null!"); return; }

        string defFolder = "Assets/Scripts/AMagic/ShardDefinitions";
        ShardType[] types = (ShardType[])Enum.GetValues(typeof(ShardType));

        if (invPanel.transform.childCount < 4)
        {
            Debug.LogError("[ShardSlotInjector] InventoryPanel has fewer than 4 children!");
            return;
        }

        for (int i = 0; i < 4; i++)
        {
            Transform slotTransform = invPanel.transform.GetChild(i);
            GameObject slotGo = slotTransform.gameObject;
            ShardType type = types[i];
            ShardDefinition def = AssetDatabase.LoadAssetAtPath<ShardDefinition>($"{defFolder}/ShardDef_{type}.asset");

            // Удаляем старый контент слота (DraggableItem и т.п.)
            ClearChildren(slotGo);

            // Красим фон слота под цвет осколка
            Image slotImg = slotGo.GetComponent<Image>();
            if (slotImg != null && def != null)
            {
                Color bg = def.glowColor * 0.12f;
                bg.a = 0.95f;
                slotImg.color = bg;
            }

            // Удаляем старый ShardHUDSlot если есть
            ShardHUDSlot existingSlot = slotGo.GetComponent<ShardHUDSlot>();
            if (existingSlot != null) UnityEngine.Object.DestroyImmediate(existingSlot);

            // 3D Preview (RawImage — занимает верхние 80% слота)
            GameObject previewGo = new GameObject("Preview3D");
            previewGo.transform.SetParent(slotTransform, false);
            RectTransform previewRT = previewGo.AddComponent<RectTransform>();
            previewRT.anchorMin = new Vector2(0.05f, 0.2f);
            previewRT.anchorMax = new Vector2(0.95f, 0.98f);
            previewRT.offsetMin = previewRT.offsetMax = Vector2.zero;
            RawImage rawImg = previewGo.AddComponent<RawImage>();
            rawImg.color = Color.white;

            // Метка типа (сверху)
            GameObject labelGo = new GameObject("TypeLabel");
            labelGo.transform.SetParent(slotTransform, false);
            RectTransform labelRT = labelGo.AddComponent<RectTransform>();
            labelRT.anchorMin = new Vector2(0f, 0.82f);
            labelRT.anchorMax = new Vector2(1f, 1f);
            labelRT.offsetMin = labelRT.offsetMax = Vector2.zero;
            TextMeshProUGUI labelTmp = labelGo.AddComponent<TextMeshProUGUI>();
            string shortName = type == ShardType.Projectile ? "PROJ" : type.ToString().ToUpper();
            labelTmp.text = shortName;
            labelTmp.fontSize = 7;
            labelTmp.fontStyle = FontStyles.Bold;
            labelTmp.alignment = TextAlignmentOptions.Top;
            labelTmp.color = def != null ? def.glowColor : Color.white;

            // Счётчик (снизу)
            GameObject countGo = new GameObject("Count");
            countGo.transform.SetParent(slotTransform, false);
            RectTransform countRT = countGo.AddComponent<RectTransform>();
            countRT.anchorMin = Vector2.zero;
            countRT.anchorMax = new Vector2(1f, 0.22f);
            countRT.offsetMin = countRT.offsetMax = Vector2.zero;
            TextMeshProUGUI countTmp = countGo.AddComponent<TextMeshProUGUI>();
            countTmp.text = "0";
            countTmp.fontSize = 14;
            countTmp.fontStyle = FontStyles.Bold;
            countTmp.alignment = TextAlignmentOptions.Center;
            countTmp.color = def != null ? def.glowColor : Color.white;

            // Добавляем ShardHUDSlot
            ShardHUDSlot hudSlot = slotGo.AddComponent<ShardHUDSlot>();
            hudSlot.definition = def;

            SerializedObject so = new SerializedObject(hudSlot);
            so.FindProperty("previewImage").objectReferenceValue    = rawImg;
            so.FindProperty("backgroundImage").objectReferenceValue = slotImg;
            so.FindProperty("countText").objectReferenceValue       = countTmp;
            so.ApplyModifiedPropertiesWithoutUndo();

            Debug.Log($"[ShardSlotInjector] Slot[{i}] -> {type}");
        }

        UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene());
        AssetDatabase.SaveAssets();
        Debug.Log("[ShardSlotInjector] Done! First 4 inventory slots are now shard slots.");
    }

    private static void ClearChildren(GameObject go)
    {
        for (int c = go.transform.childCount - 1; c >= 0; c--)
            UnityEngine.Object.DestroyImmediate(go.transform.GetChild(c).gameObject);
    }
#endif
}
