using System;
using Assets.Scripts.AMagic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// Editor tool: creates all Shard HUD assets and scene objects.
/// Run via: Tools -> Magic Universe -> Setup Shard HUD
/// </summary>
public class ShardHUDSetupTool
{
#if UNITY_EDITOR
    [MenuItem("Tools/Magic Universe/Setup Shard HUD")]
    public static void SetupAll()
    {
        EnsureShardDefinitions();
        EnsureShardInventoryObject();
        EnsureShardPreviewSystemObject();
        BuildHUDPanel();
        BuildInvSection();
        WireInventoryManager();
        AssetDatabase.SaveAssets();
        EditorUtility.DisplayDialog(
            "Shard HUD - Done!",
            "Setup complete!\n\nPress Play, kill an enemy, collect shards.\n- Bottom-left HUD shows live 3D renders.\n- Open inventory (E) to see shards inside.",
            "OK");
    }

    // ------------------------------------------------------------------ assets

    private static void EnsureShardDefinitions()
    {
        string folder = "Assets/Scripts/AMagic/ShardDefinitions";
        if (!AssetDatabase.IsValidFolder(folder))
        {
            System.IO.Directory.CreateDirectory(Application.dataPath + "/Scripts/AMagic/ShardDefinitions");
            AssetDatabase.Refresh();
        }

        ShardType[] types  = (ShardType[])Enum.GetValues(typeof(ShardType));
        Color[]     colors = { new Color(0f,0.9f,1f), new Color(0.8f,0.1f,1f),
                               new Color(1f,0.4f,0f), new Color(1f,0f,0.5f) };
        string[]    names  = { "Laser Crystal","Arcane Orb","Ember Spike","Shield Fragment" };

        for (int i = 0; i < types.Length; i++)
        {
            string path = $"{folder}/ShardDef_{types[i]}.asset";
            if (AssetDatabase.LoadAssetAtPath<ShardDefinition>(path) != null) continue;
            ShardDefinition def = ScriptableObject.CreateInstance<ShardDefinition>();
            def.shardType   = types[i];
            def.displayName = names[i];
            def.glowColor   = colors[i];
            AssetDatabase.CreateAsset(def, path);
        }
    }

    // --------------------------------------------------------------- scene objs

    private static void EnsureShardInventoryObject()
    {
        if (UnityEngine.Object.FindObjectOfType<ShardInventory>() != null) return;
        new GameObject("ShardInventory").AddComponent<ShardInventory>();
        MarkDirty();
    }

    private static void EnsureShardPreviewSystemObject()
    {
        if (UnityEngine.Object.FindObjectOfType<ShardPreviewSystem>() != null) return;
        new GameObject("ShardPreviewSystem").AddComponent<ShardPreviewSystem>();
        MarkDirty();
    }

    // ------------------------------------------------------ bottom-left HUD panel

    private static void BuildHUDPanel()
    {
        Canvas canvas = FindMainCanvas();
        if (canvas == null) return;

        Transform old = canvas.transform.Find("ShardHUD");
        if (old != null) UnityEngine.Object.DestroyImmediate(old.gameObject);

        GameObject panel = new GameObject("ShardHUD");
        panel.transform.SetParent(canvas.transform, false);

        RectTransform panelRT = panel.AddComponent<RectTransform>();
        panelRT.anchorMin        = Vector2.zero;
        panelRT.anchorMax        = Vector2.zero;
        panelRT.pivot            = Vector2.zero;
        panelRT.anchoredPosition = new Vector2(20f, 20f);
        panelRT.sizeDelta        = new Vector2(316f, 88f);

        Image panelBg = panel.AddComponent<Image>();
        panelBg.color = new Color(0.04f, 0.04f, 0.1f, 0.72f);

        HorizontalLayoutGroup hlg = panel.AddComponent<HorizontalLayoutGroup>();
        hlg.padding              = new RectOffset(8,8,8,8);
        hlg.spacing              = 6f;
        hlg.childAlignment       = TextAnchor.MiddleCenter;
        hlg.childForceExpandWidth  = true;
        hlg.childForceExpandHeight = true;

        BuildSlotsIn(panel.transform, 72f, 11f, "Assets/Scripts/AMagic/ShardDefinitions");
        MarkDirty();
        Debug.Log("[ShardHUDSetup] HUD panel built.");
    }

    // ----------------------------------------- inventory shard section (inside E-menu)

    private static void BuildInvSection()
    {
        // Find InventoryPanel
        InventoryManager im = UnityEngine.Object.FindObjectOfType<InventoryManager>(true);
        if (im == null) { Debug.LogWarning("[ShardHUDSetup] No InventoryManager found."); return; }

        // Find Canvas to attach at same level as InventoryPanel
        Canvas canvas = FindMainCanvas();
        if (canvas == null) return;

        // Remove old
        Transform old = canvas.transform.Find("ShardInvSection");
        if (old != null) UnityEngine.Object.DestroyImmediate(old.gameObject);

        // Get InventoryPanel bounds via SerializedObject to position section above it
        SerializedObject imSO = new SerializedObject(im);
        GameObject invPanelGO = imSO.FindProperty("inventoryPanel").objectReferenceValue as GameObject;
        if (invPanelGO == null) { Debug.LogWarning("[ShardHUDSetup] inventoryPanel field is null on InventoryManager."); return; }
        RectTransform invRT = invPanelGO.GetComponent<RectTransform>();

        // InventoryPanel: anchors 0,0->1,1, offset 0. size ~417x583
        // We place ShardInvSection as sibling, anchored same as inv panel but only on top strip
        GameObject section = new GameObject("ShardInvSection");
        section.transform.SetParent(canvas.transform, false);
        section.AddComponent<ShardInvSection>();

        RectTransform secRT = section.AddComponent<RectTransform>();
        // Match inventory panel horizontal stretch, position at top
        secRT.anchorMin        = new Vector2(0f, 1f);
        secRT.anchorMax        = new Vector2(1f, 1f);
        secRT.pivot            = new Vector2(0.5f, 1f);
        secRT.anchoredPosition = new Vector2(0f, 0f);  // flush with top of screen
        secRT.sizeDelta        = new Vector2(0f, 100f); // full width, 100px tall

        // Dark background matching inventory style
        Image secBg = section.AddComponent<Image>();
        secBg.color = new Color(0.06f, 0.04f, 0.12f, 0.92f);

        // Title label
        GameObject titleGo = new GameObject("Title");
        titleGo.transform.SetParent(section.transform, false);
        RectTransform titleRT = titleGo.AddComponent<RectTransform>();
        titleRT.anchorMin = new Vector2(0f, 0.65f); titleRT.anchorMax = new Vector2(1f, 1f);
        titleRT.offsetMin = titleRT.offsetMax = Vector2.zero;
        TextMeshProUGUI title = titleGo.AddComponent<TextMeshProUGUI>();
        title.text = "MAGIC SHARDS";
        title.fontSize = 13;
        title.fontStyle = FontStyles.Bold;
        title.alignment = TextAlignmentOptions.Center;
        title.color = new Color(0.7f, 0.5f, 1f, 1f);

        // Slots row
        GameObject row = new GameObject("SlotsRow");
        row.transform.SetParent(section.transform, false);
        RectTransform rowRT = row.AddComponent<RectTransform>();
        rowRT.anchorMin = new Vector2(0f, 0f); rowRT.anchorMax = new Vector2(1f, 0.65f);
        rowRT.offsetMin = new Vector2(8f, 4f); rowRT.offsetMax = new Vector2(-8f, -2f);

        HorizontalLayoutGroup hlg = row.AddComponent<HorizontalLayoutGroup>();
        hlg.spacing              = 10f;
        hlg.childAlignment       = TextAnchor.MiddleCenter;
        hlg.childForceExpandWidth  = true;
        hlg.childForceExpandHeight = true;

        BuildSlotsIn(row.transform, 60f, 10f, "Assets/Scripts/AMagic/ShardDefinitions");

        section.SetActive(false); // hidden by default, shown by InventoryManager
        MarkDirty();
        Debug.Log("[ShardHUDSetup] Inventory shard section built.");
    }

    // ---------------------------------------------------------- wire InventoryManager

    private static void WireInventoryManager()
    {
        InventoryManager im = UnityEngine.Object.FindObjectOfType<InventoryManager>(true);
        if (im == null) return;

        Canvas canvas = FindMainCanvas();
        if (canvas == null) return;

        Transform hudT  = canvas.transform.Find("ShardHUD");
        Transform secT  = canvas.transform.Find("ShardInvSection");

        SerializedObject so = new SerializedObject(im);
        if (hudT != null) so.FindProperty("shardHUD").objectReferenceValue         = hudT.gameObject;
        if (secT != null) so.FindProperty("shardInvSection").objectReferenceValue  = secT.gameObject;
        so.ApplyModifiedPropertiesWithoutUndo();

        Debug.Log("[ShardHUDSetup] InventoryManager wired: shardHUD + shardInvSection.");
        MarkDirty();
    }

    // ---------------------------------------------------------- shared helpers

    /// Build 4 ShardHUDSlot children inside <parent>, each slotSize wide.
    private static void BuildSlotsIn(Transform parent, float slotSize, float fontSize, string defFolder)
    {
        ShardType[] types = (ShardType[])Enum.GetValues(typeof(ShardType));
        foreach (ShardType type in types)
        {
            ShardDefinition def =
                AssetDatabase.LoadAssetAtPath<ShardDefinition>($"{defFolder}/ShardDef_{type}.asset");
            BuildSlot(parent, type, def, slotSize, fontSize);
        }
    }

    private static void BuildSlot(Transform parent, ShardType type, ShardDefinition def, float slotSize, float fontSize)
    {
        GameObject slot = new GameObject($"ShardSlot_{type}");
        slot.transform.SetParent(parent, false);
        slot.AddComponent<RectTransform>().sizeDelta = new Vector2(slotSize, slotSize);
        slot.AddComponent<CanvasGroup>();

        // Background
        GameObject bgGo = new GameObject("Background");
        bgGo.transform.SetParent(slot.transform, false);
        StretchFull(bgGo.AddComponent<RectTransform>());
        Image bgImg = bgGo.AddComponent<Image>();
        Color bgColor = def != null ? def.glowColor * 0.15f : new Color(0.08f, 0.08f, 0.15f);
        bgColor.a = 0.9f;
        bgImg.color = bgColor;

        // 3D RawImage
        GameObject previewGo = new GameObject("Preview3D");
        previewGo.transform.SetParent(slot.transform, false);
        RectTransform previewRT = previewGo.AddComponent<RectTransform>();
        previewRT.anchorMin = new Vector2(0.05f, 0.2f);
        previewRT.anchorMax = new Vector2(0.95f, 0.95f);
        previewRT.offsetMin = previewRT.offsetMax = Vector2.zero;
        RawImage rawImg = previewGo.AddComponent<RawImage>();
        rawImg.color = Color.white;

        // Count badge
        GameObject countGo = new GameObject("Count");
        countGo.transform.SetParent(slot.transform, false);
        RectTransform countRT = countGo.AddComponent<RectTransform>();
        countRT.anchorMin = Vector2.zero;
        countRT.anchorMax = new Vector2(1f, 0.24f);
        countRT.offsetMin = countRT.offsetMax = Vector2.zero;
        TextMeshProUGUI tmp = countGo.AddComponent<TextMeshProUGUI>();
        tmp.text      = "0";
        tmp.fontSize  = fontSize;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.fontStyle = FontStyles.Bold;
        tmp.color     = def != null ? def.glowColor : Color.white;

        // ShardHUDSlot component
        ShardHUDSlot hudSlot = slot.AddComponent<ShardHUDSlot>();
        hudSlot.definition = def;

        SerializedObject so = new SerializedObject(hudSlot);
        so.FindProperty("previewImage").objectReferenceValue    = rawImg;
        so.FindProperty("backgroundImage").objectReferenceValue = bgImg;
        so.FindProperty("countText").objectReferenceValue       = tmp;
        so.ApplyModifiedPropertiesWithoutUndo();
    }

    private static Canvas FindMainCanvas()
    {
        foreach (var c in UnityEngine.Object.FindObjectsOfType<Canvas>(true))
            if (c.GetComponent<InventoryManager>() != null) return c;
        var fallback = UnityEngine.Object.FindObjectOfType<Canvas>(true);
        if (fallback == null) Debug.LogError("[ShardHUDSetup] No Canvas in scene!");
        return fallback;
    }

    private static void StretchFull(RectTransform rt)
    {
        rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one;
        rt.offsetMin = rt.offsetMax = Vector2.zero;
    }

    private static void MarkDirty() =>
        UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(
            UnityEngine.SceneManagement.SceneManager.GetActiveScene());

#endif
}
