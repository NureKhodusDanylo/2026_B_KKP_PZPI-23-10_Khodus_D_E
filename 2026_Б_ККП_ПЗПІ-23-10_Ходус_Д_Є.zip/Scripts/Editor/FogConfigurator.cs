using UnityEngine;
using UnityEditor;
using System.IO;

public static class FogConfigurator
{
    private const string LogPath = "Assets/diagnostics_log.txt";

    [MenuItem("Tools/Fog Configurator/Log Settings")]
    public static void LogSettings()
    {
        var skybox = RenderSettings.skybox;
        string skyboxInfo = skybox != null ? $"{skybox.name} (Shader: {skybox.shader.name})" : "None";

        string report = $"=== FOG & SKYBOX DIAGNOSTICS ===\n" +
                        $"Time: {System.DateTime.Now}\n" +
                        $"Fog Enabled: {RenderSettings.fog}\n" +
                        $"Fog Color: {RenderSettings.fogColor} (Hex: #{ColorUtility.ToHtmlStringRGBA(RenderSettings.fogColor)})\n" +
                        $"Fog Mode: {RenderSettings.fogMode}\n" +
                        $"Fog Density: {RenderSettings.fogDensity}\n" +
                        $"Fog Start: {RenderSettings.fogStartDistance}\n" +
                        $"Fog End: {RenderSettings.fogEndDistance}\n" +
                        $"Skybox: {skyboxInfo}\n";

        if (skybox != null)
        {
            report += "Skybox properties:\n";
            string[] textureProps = { "_FrontTex", "_BackTex", "_LeftTex", "_RightTex", "_UpTex", "_DownTex", "_Tex", "_TexEnv" };
            foreach (var prop in textureProps)
            {
                if (skybox.HasProperty(prop))
                {
                    var tex = skybox.GetTexture(prop);
                    report += $"  {prop}: {(tex != null ? tex.name : "null")}\n";
                }
            }
            if (skybox.HasProperty("_Tint")) report += $"  _Tint: {skybox.GetColor("_Tint")}\n";
            if (skybox.HasProperty("_Exposure")) report += $"  _Exposure: {skybox.GetFloat("_Exposure")}\n";
        }

        File.WriteAllText(LogPath, report);
        Debug.Log($"FogConfigurator: Saved settings report to {LogPath}");
    }

    [MenuItem("Tools/Fog Configurator/Apply Midnight Purple Fog (Very Dark)")]
    public static void ApplyMidnightPurpleFog()
    {
        // A very dark violet/indigo that matches the deep background of low-poly skybox
        Color midnightColor = new Color(0.04f, 0.015f, 0.12f, 1f); 
        ConfigureFog(midnightColor, 35f, 115f);
        Debug.Log("FogConfigurator: Applied Midnight Purple Fog");
    }

    [MenuItem("Tools/Fog Configurator/Apply Pitch Black Fog")]
    public static void ApplyPitchBlackFog()
    {
        ConfigureFog(Color.black, 35f, 115f);
        Debug.Log("FogConfigurator: Applied Pitch Black Fog");
    }

    [MenuItem("Tools/Fog Configurator/Apply Dark Blue Fog")]
    public static void ApplyDarkBlueFog()
    {
        Color darkBlueColor = new Color(0.02f, 0.02f, 0.15f, 1f);
        ConfigureFog(darkBlueColor, 35f, 115f);
        Debug.Log("FogConfigurator: Applied Dark Blue Fog");
    }

    [MenuItem("Tools/Fog Configurator/Apply Deep Indigo Fog")]
    public static void ApplyDeepIndigoFog()
    {
        Color deepIndigoColor = new Color(0.05f, 0.02f, 0.2f, 1f);
        ConfigureFog(deepIndigoColor, 35f, 115f);
        Debug.Log("FogConfigurator: Applied Deep Indigo Fog");
    }

    [MenuItem("Tools/Fog Configurator/Inspect Spawned Prefabs")]
    public static void InspectPrefabs()
    {
        var gen = GameObject.FindObjectOfType<GenerateEnvironmental>();
        if (gen == null)
        {
            Debug.LogError("FogConfigurator: GenerateEnvironmental component not found in active scene!");
            File.WriteAllText(LogPath, "GenerateEnvironmental component not found in active scene!");
            return;
        }

        string report = $"=== GENERATE ENVIRONMENTAL PREFABS ===\n" +
                        $"GameObject Name: {gen.name}\n" +
                        $"Default Prefabs Count: {gen.EnvironmentalObjects?.Count}\n";

        void ListPrefabs(string listName, System.Collections.Generic.List<GameObject> list)
        {
            report += $"\nList: {listName} (Count: {list?.Count})\n";
            if (list != null)
            {
                foreach (var item in list)
                {
                    if (item != null)
                    {
                        var renderer = item.GetComponentInChildren<Renderer>();
                        string matInfo = "";
                        if (renderer != null && renderer.sharedMaterial != null)
                        {
                            matInfo = $" (Material: {renderer.sharedMaterial.name}, Shader: {renderer.sharedMaterial.shader.name})";
                        }
                        report += $"  - {item.name}{matInfo}\n";
                    }
                }
            }
        }

        ListPrefabs("EnvironmentalObjects", gen.EnvironmentalObjects);
        ListPrefabs("Red", gen.EnvironmentalObjectsRed);
        ListPrefabs("Orange", gen.EnvironmentalObjectsOrange);
        ListPrefabs("Yellow", gen.EnvironmentalObjectsYellow);
        ListPrefabs("Green", gen.EnvironmentalObjectsGreen);
        ListPrefabs("LightBlue", gen.EnvironmentalObjectsLightBlue);
        ListPrefabs("Blue", gen.EnvironmentalObjectsBlue);
        ListPrefabs("Purple", gen.EnvironmentalObjectsPurple);

        File.WriteAllText(LogPath, report);
        Debug.Log($"FogConfigurator: Prefab inspection report written to {LogPath}");
    }

    [MenuItem("Tools/Fog Configurator/Assign Shared Material to Alien Prefabs")]
    public static void AssignSharedMaterial()
    {
        string matPath = "Assets/Free Demo of Low Poly Space Alien Worlds 3D Asset Pack/Texture/New Material.mat";
        Material sharedMat = AssetDatabase.LoadAssetAtPath<Material>(matPath);
        if (sharedMat == null)
        {
            Debug.LogError($"FogConfigurator: Shared material not found at {matPath}!");
            return;
        }

        string prefabsFolder = "Assets/Free Demo of Low Poly Space Alien Worlds 3D Asset Pack/Prefabs";
        string[] prefabGuids = AssetDatabase.FindAssets("t:Prefab", new[] { prefabsFolder });
        int count = 0;

        foreach (string guid in prefabGuids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            GameObject prefab = PrefabUtility.LoadPrefabContents(path);
            if (prefab == null) continue;

            MeshRenderer[] renderers = prefab.GetComponentsInChildren<MeshRenderer>(true);
            bool modified = false;

            foreach (var renderer in renderers)
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++)
                {
                    if (materials[i] == null || materials[i].name == "Mat" || materials[i].name.StartsWith("Mat (Instance)") || materials[i].name.Contains("embedded"))
                    {
                        materials[i] = sharedMat;
                        modified = true;
                    }
                }
                if (modified)
                {
                    renderer.sharedMaterials = materials;
                }
            }

            if (modified)
            {
                PrefabUtility.SaveAsPrefabAsset(prefab, path);
                count++;
            }
            PrefabUtility.UnloadPrefabContents(prefab);
        }

        Debug.Log($"FogConfigurator: Successfully updated {count} prefabs to use shared material.");
    }

    [MenuItem("Tools/Fog Configurator/Regenerate Environment")]
    public static void RegenerateEnvironment()
    {
        var gen = GameObject.FindObjectOfType<GenerateEnvironmental>();
        if (gen == null)
        {
            Debug.LogError("FogConfigurator: GenerateEnvironmental component not found in active scene!");
            return;
        }
        gen.ClearGeneratedObjects();
        gen.Init();
        Debug.Log("FogConfigurator: Successfully cleared and regenerated environment.");
    }

    [MenuItem("Tools/Fog Configurator/Sample Skybox Horizon Color")]
    public static void SampleSkyboxHorizon()
    {
        var skybox = RenderSettings.skybox;
        if (skybox == null)
        {
            Debug.LogError("No active skybox material!");
            return;
        }

        var tex = skybox.GetTexture("_FrontTex") as Texture2D;
        if (tex == null)
        {
            Debug.LogError("Skybox front texture not found or is not Texture2D!");
            return;
        }

        string path = AssetDatabase.GetAssetPath(tex);
        var importer = AssetImporter.GetAtPath(path) as TextureImporter;
        bool wasReadable = importer != null && importer.isReadable;
        if (importer != null && !wasReadable)
        {
            importer.isReadable = true;
            importer.SaveAndReimport();
        }

        Color sum = Color.clear;
        int samples = 10;
        for (int i = 0; i < samples; i++)
        {
            int x = (tex.width / samples) * i;
            sum += tex.GetPixel(x, 2);
        }
        Color avg = sum / samples;
        Debug.Log($"Skybox Horizon Average Color: {avg} (Hex: #{ColorUtility.ToHtmlStringRGBA(avg)})");

        if (importer != null && !wasReadable)
        {
            importer.isReadable = false;
            importer.SaveAndReimport();
        }
    }




    private static void ConfigureFog(Color color, float start, float end)
    {
        RenderSettings.fog = true;
        RenderSettings.fogColor = color;
        RenderSettings.fogMode = FogMode.Linear;
        RenderSettings.fogStartDistance = start;
        RenderSettings.fogEndDistance = end;
        
        // Mark scene dirty so it saves
        if (!Application.isPlaying)
        {
            var activeScene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(activeScene);
        }
    }
}

