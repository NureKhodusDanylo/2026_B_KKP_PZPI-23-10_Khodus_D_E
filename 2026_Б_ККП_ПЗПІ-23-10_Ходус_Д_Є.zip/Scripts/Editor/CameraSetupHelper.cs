using UnityEngine;
using UnityEditor;
using Cinemachine;

public static class CameraSetupHelper
{
    [MenuItem("Tools/Setup FreeLook Camera")]
    public static void SetupFreeLookCamera()
    {
        // 1. Find Player
        GameObject player = GameObject.Find("PL");
        if (player == null)
        {
            Debug.LogError("Error: PL GameObject not found in the scene.");
            return;
        }

        // Enable Rigidbody Interpolation and Freeze all physical rotations (X, Y, Z)
        // to prevent the root PL transform from tilting or turning due to physics/slopes.
        Rigidbody rb = player.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
            Undo.RegisterCompleteObjectUndo(rb, "Configure Rigidbody Constraints");
        }

        // 2. Set CinemachineBrain to SmartUpdate when using Interpolate
        GameObject mainCam = GameObject.Find("Main Camera");
        if (mainCam != null)
        {
            CinemachineBrain brain = mainCam.GetComponent<CinemachineBrain>();
            if (brain == null)
            {
                brain = mainCam.AddComponent<CinemachineBrain>();
            }
            brain.m_UpdateMethod = CinemachineBrain.UpdateMethod.SmartUpdate;
            Undo.RegisterCompleteObjectUndo(brain, "Update CinemachineBrain");
        }

        // 3. Find and deactivate existing "Virtual Camera"
        GameObject oldVcam = GameObject.Find("Virtual Camera");
        if (oldVcam != null)
        {
            oldVcam.SetActive(false);
            Undo.RegisterCompleteObjectUndo(oldVcam, "Deactivate Virtual Camera");
        }

        // 4. Create FreeLook Camera if it doesn't exist
        GameObject freeLookGo = GameObject.Find("FreeLook Camera");
        if (freeLookGo == null)
        {
            freeLookGo = new GameObject("FreeLook Camera");
            Undo.RegisterCreatedObjectUndo(freeLookGo, "Create FreeLook Camera");
        }
        
        CinemachineFreeLook freeLook = freeLookGo.GetComponent<CinemachineFreeLook>();
        if (freeLook == null)
        {
            freeLook = freeLookGo.AddComponent<CinemachineFreeLook>();
        }
        
        // 5. Configure Follow and LookAt
        freeLook.Follow = player.transform;
        freeLook.LookAt = player.transform;

        // 6. Set Binding Mode to World Space on the top-level camera
        freeLook.m_BindingMode = CinemachineTransposer.BindingMode.WorldSpace;

        // 7. Lock camera's reference heading to World Forward instead of Target Forward.
        freeLook.m_Heading.m_Definition = CinemachineOrbitalTransposer.Heading.HeadingDefinition.WorldForward;

        // 8. Disable any auto-recentering features so the camera never rotates itself
        freeLook.m_RecenterToTargetHeading.m_enabled = false;
        freeLook.m_YAxisRecentering.m_enabled = false;
        freeLook.m_XAxis.m_Recentering.m_enabled = false;

        // 9. Configure Orbits
        freeLook.m_Orbits = new CinemachineFreeLook.Orbit[3];
        freeLook.m_Orbits[0] = new CinemachineFreeLook.Orbit(4.5f, 2.5f); // Top
        freeLook.m_Orbits[1] = new CinemachineFreeLook.Orbit(1.5f, 4.5f); // Middle
        freeLook.m_Orbits[2] = new CinemachineFreeLook.Orbit(0.2f, 1.5f); // Bottom

        // 10. Configure Axis control
        freeLook.m_XAxis.m_InputAxisName = "Mouse X";
        freeLook.m_YAxis.m_InputAxisName = "Mouse Y";
        freeLook.m_YAxis.m_InvertInput = true;
        
        // 11. Enable collision detection (Cinemachine Collider) and ignore player
        CinemachineCollider collider = freeLookGo.GetComponent<CinemachineCollider>();
        if (collider == null)
        {
            collider = freeLookGo.AddComponent<CinemachineCollider>();
        }
        collider.m_IgnoreTag = "Player";

        // 11.5. Add CinemachineFreeLookZoom component if not present
        CinemachineFreeLookZoom zoom = freeLookGo.GetComponent<CinemachineFreeLookZoom>();
        if (zoom == null)
        {
            zoom = freeLookGo.AddComponent<CinemachineFreeLookZoom>();
        }

        // 12. Configure Rigs individually to enforce WorldSpace, WorldForward, and zero Damping
        for (int i = 0; i < 3; i++)
        {
            CinemachineVirtualCamera rig = freeLook.GetRig(i);
            if (rig != null)
            {
                var transposer = rig.GetCinemachineComponent<CinemachineOrbitalTransposer>();
                if (transposer != null)
                {
                    // Enforce WorldSpace binding mode on the rig transposer
                    transposer.m_BindingMode = CinemachineTransposer.BindingMode.WorldSpace;

                    // Enforce WorldForward heading definition on the rig transposer
                    transposer.m_Heading.m_Definition = CinemachineOrbitalTransposer.Heading.HeadingDefinition.WorldForward;
                    transposer.m_RecenterToTargetHeading.m_enabled = false;

                    // Set position damping to 0 for maximum stability and zero wobble
                    transposer.m_XDamping = 0f;
                    transposer.m_YDamping = 0f;
                    transposer.m_ZDamping = 0f;
                }

                // Set aim/look damping to 0
                var composer = rig.GetCinemachineComponent<CinemachineComposer>();
                if (composer != null)
                {
                    composer.m_HorizontalDamping = 0f;
                    composer.m_VerticalDamping = 0f;
                    
                    // Force Composer dead zones and soft zones to 0 to keep target centered instantly
                    composer.m_DeadZoneWidth = 0f;
                    composer.m_DeadZoneHeight = 0f;
                    composer.m_SoftZoneWidth = 0f;
                    composer.m_SoftZoneHeight = 0f;
                }
            }
        }

        // Save scene
        UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
        
        Debug.Log("Successfully configured FreeLook Camera and Rigidbody to enforce WorldSpace & WorldForward!");
    }
}
