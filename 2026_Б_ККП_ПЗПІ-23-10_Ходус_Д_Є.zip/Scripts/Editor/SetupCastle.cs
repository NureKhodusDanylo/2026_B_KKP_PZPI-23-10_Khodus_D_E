using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Reflection;
using Cinemachine;

public static class SetupCastle
{
    [MenuItem("Tools/Setup Castle Interaction")]
    public static void RunSetup()
    {
        // Find Castle))
        GameObject castleParent = GameObject.Find("Castle))");
        if (castleParent == null)
        {
            Debug.LogError("[SetupCastle] Castle)) GameObject not found in the scene! Make sure SampleScene is loaded.");
            return;
        }

        Transform existing = castleParent.transform.Find("CastleInteraction");
        if (existing != null)
        {
            Object.DestroyImmediate(existing.gameObject);
        }

        GameObject castleInteraction = new GameObject("CastleInteraction");
        castleInteraction.transform.SetParent(castleParent.transform);
        castleInteraction.transform.localPosition = Vector3.zero;
        castleInteraction.transform.localRotation = Quaternion.identity;
        castleInteraction.transform.localScale = Vector3.one;

        SphereCollider trigger = castleInteraction.AddComponent<SphereCollider>();
        trigger.isTrigger = true;
        trigger.radius = 12f;

        CastleInteractable castleInteractable = castleInteraction.AddComponent<CastleInteractable>();

        GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/InteractObjerct.prefab");
        if (prefab == null)
        {
            Debug.LogError("[SetupCastle] Assets/Prefabs/InteractObjerct.prefab not found!");
            return;
        }

        Transform innerInteractObj = prefab.transform.Find("InteractObjerct");
        if (innerInteractObj == null)
        {
            Debug.LogError("[SetupCastle] Inner InteractObjerct child not found in prefab!");
            return;
        }

        Transform menuTransform = innerInteractObj.Find("IntecactMenu");
        if (menuTransform == null)
        {
            Debug.LogError("[SetupCastle] IntecactMenu child not found in prefab!");
            return;
        }

        GameObject menuInstance = Object.Instantiate(menuTransform.gameObject, castleInteraction.transform);
        menuInstance.name = "IntecactMenu";
        menuInstance.transform.localPosition = new Vector3(0f, 35f, 0f);
        menuInstance.transform.localRotation = Quaternion.identity;
        menuInstance.transform.localScale = new Vector3(15f, 15f, 15f);

        // Add Billboard component so it faces the camera at all times
        menuInstance.AddComponent<Billboard>();

        InteractMenuAnimManager animManager = menuInstance.GetComponent<InteractMenuAnimManager>();
        if (animManager == null)
        {
            Debug.LogError("[SetupCastle] InteractMenuAnimManager component not found on IntecactMenu instance!");
            return;
        }

        FieldInfo field = typeof(CastleInteractable).GetField("_interactMenuAnimManager", BindingFlags.NonPublic | BindingFlags.Instance);
        if (field == null)
        {
            Debug.LogError("[SetupCastle] Field _interactMenuAnimManager not found on CastleInteractable class!");
            return;
        }

        field.SetValue(castleInteractable, animManager);

        EditorSceneManager.MarkSceneDirty(UnityEngine.SceneManagement.SceneManager.GetActiveScene());
        EditorSceneManager.SaveScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene());

        Debug.Log("[SetupCastle] SUCCESS: CastleInteraction set up correctly on Castle)) (elevated, scaled 15x, and billboarded) and scene saved successfully!");
    }

    [MenuItem("Tools/Inspect Dungeon")]
    public static void InspectDungeon()
    {
        // 1. Inspect Main World
        GameObject mainTerrainObj = GameObject.Find("Terrain");
        if (mainTerrainObj != null)
        {
            Terrain terrain = mainTerrainObj.GetComponent<Terrain>();
            if (terrain != null)
            {
                Debug.Log($"[InspectDungeon] Main Terrain Pos: {mainTerrainObj.transform.position}, Size: {terrain.terrainData.size}, Layer: {mainTerrainObj.layer} ({LayerMask.LayerToName(mainTerrainObj.layer)})");
            }
        }

        // 2. Inspect Dungeon
        GameObject dungTerrainObj = GameObject.Find("DungeonTerrain");
        GameObject dungEntryPointObj = GameObject.Find("DungeonEntryPoint");

        if (dungTerrainObj == null)
        {
            Debug.LogError("[InspectDungeon] DungeonTerrain not found in active scene!");
        }
        else if (dungEntryPointObj == null)
        {
            Debug.LogError("[InspectDungeon] DungeonEntryPoint not found in active scene!");
        }
        else
        {
            Terrain terrain = dungTerrainObj.GetComponent<Terrain>();
            Vector3 terPos = dungTerrainObj.transform.position;
            Vector3 epPos = dungEntryPointObj.transform.position;

            float terrainHeightAtEP = terrain.SampleHeight(epPos);
            float absoluteHeight = terPos.y + terrainHeightAtEP;

            Debug.Log(string.Format("[InspectDungeon] DungeonTerrain Pos: {0}, Size: {1}, Layer: {2} ({3}), EntryPoint Pos: {4}, SampleHeight: {5}, Absolute Ground Height: {6}", 
                terPos, terrain.terrainData.size, dungTerrainObj.layer, LayerMask.LayerToName(dungTerrainObj.layer), epPos, terrainHeightAtEP, absoluteHeight));
        }

        // 3. Inspect Player
        GameObject playerObj = GameObject.Find("PL");
        if (playerObj != null)
        {
            Debug.Log($"[InspectDungeon] Player 'PL' is active in scene at: {playerObj.transform.position}");
        }
        else
        {
            Debug.LogWarning("[InspectDungeon] Player 'PL' not found in active scene!");
        }

        // 4. Inspect URP Settings
        var pipeline = UnityEngine.QualitySettings.renderPipeline;
        if (pipeline != null)
        {
            Debug.Log($"[InspectDungeon] Active Render Pipeline: {pipeline.name} (Type: {pipeline.GetType().Name})");
            
            // Inspect additional lights support using reflection
            try
            {
                var addLightsSupportProp = pipeline.GetType().GetProperty("supportsAdditionalLights", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                var addLightsRenderingProp = pipeline.GetType().GetProperty("additionalLightsRenderingMode", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                var maxAddLightsProp = pipeline.GetType().GetProperty("maxAdditionalLightsCount", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);

                object support = addLightsSupportProp != null ? addLightsSupportProp.GetValue(pipeline) : "Unknown";
                object mode = addLightsRenderingProp != null ? addLightsRenderingProp.GetValue(pipeline) : "Unknown";
                object count = maxAddLightsProp != null ? maxAddLightsProp.GetValue(pipeline) : "Unknown";

                Debug.Log($"[InspectDungeon] URP settings -> supportsAdditionalLights: {support}, additionalLightsRenderingMode: {mode}, maxAdditionalLightsCount: {count}");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[InspectDungeon] Failed to read URP properties via reflection: {ex.Message}");
            }
        }
        else
        {
            Debug.LogWarning("[InspectDungeon] QualitySettings.renderPipeline is null! Using Built-in Render Pipeline?");
        }
    }

    [MenuItem("Tools/Runtime Diagnostics")]
    public static void RuntimeDiagnostics()
    {
        Debug.Log("=== RUNTIME DIAGNOSTICS START ===");
        
        // 1. Inspect Player
        GameObject playerObj = GameObject.Find("PL");
        if (playerObj != null)
        {
            PlayerController pc = playerObj.GetComponent<PlayerController>();
            if (pc != null)
            {
                // Access private fields using reflection
                var layerMaskField = typeof(PlayerController).GetField("layerMask", BindingFlags.NonPublic | BindingFlags.Instance);
                var rayDistField = typeof(PlayerController).GetField("raycastDistance", BindingFlags.NonPublic | BindingFlags.Instance);
                
                LayerMask mask = layerMaskField != null ? (LayerMask)layerMaskField.GetValue(pc) : (LayerMask)0;
                float dist = rayDistField != null ? (float)rayDistField.GetValue(pc) : 1f;

                RaycastHit hit;
                bool isGrounded = Physics.Raycast(playerObj.transform.position, Vector3.down, out hit, dist, mask);
                
                // Let's also check with a much longer raycast (10 units) and ignore layer mask
                RaycastHit checkHit;
                bool foundGroundLong = Physics.Raycast(playerObj.transform.position, Vector3.down, out checkHit, 10f);

                Debug.Log($"[Runtime] Player 'PL' Pos: {playerObj.transform.position}");
                Debug.Log($"[Runtime] Ground Check -> raycastDistance: {dist}, layerMask value: {mask.value} (Mask Layers: {GetLayerNames(mask)})");
                Debug.Log($"[Runtime] IsGrounded (Raycast): {isGrounded} (Hit Object: {(isGrounded ? hit.collider.name : "None")}, Hit Distance: {(isGrounded ? hit.distance.ToString() : "N/A")})");
                Debug.Log($"[Runtime] Long Ground Check (10 units, any layer) -> Hits: {(foundGroundLong ? checkHit.collider.name : "None")}, Distance to ground: {(foundGroundLong ? checkHit.distance.ToString() : "N/A")}, Hit Layer: {(foundGroundLong ? checkHit.collider.gameObject.layer.ToString() : "N/A")}");
            }
            else
            {
                Debug.LogWarning("[Runtime] Player 'PL' found, but PlayerController component is missing!");
            }
        }
        else
        {
            Debug.LogWarning("[Runtime] Player 'PL' not found!");
        }

        // 2. Inspect Camera
        Camera mainCam = Camera.main;
        if (mainCam != null)
        {
            Debug.Log($"[Runtime] Main Camera Position: {mainCam.transform.position}, Target Texture: {mainCam.targetTexture}, Culling Mask: {mainCam.cullingMask}");
        }
        else
        {
            Debug.LogWarning("[Runtime] Main Camera not found!");
        }

        // 3. Inspect Dungeon Lights
        GameObject lightsContainer = GameObject.Find("DungeonLights");
        if (lightsContainer != null)
        {
            Debug.Log($"[Runtime] DungeonLights Container Position: {lightsContainer.transform.position}, Active: {lightsContainer.activeInHierarchy}");
            Light[] lights = lightsContainer.GetComponentsInChildren<Light>(true);
            Debug.Log($"[Runtime] Total lights found in container: {lights.Length}");
            foreach (var l in lights)
            {
                Debug.Log($"[Runtime] Light Name: '{l.name}', Type: {l.type}, Pos: {l.transform.position}, Color: {l.color}, Range: {l.range}, Intensity: {l.intensity}, Enabled: {l.enabled}, ActiveInHierarchy: {l.gameObject.activeInHierarchy}");
            }
        }
        else
        {
            Debug.LogWarning("[Runtime] DungeonLights container not found!");
        }

        // 4. General Lights in Scene
        Light[] allLights = Object.FindObjectsOfType<Light>();
        Debug.Log($"[Runtime] Total active lights in entire scene: {allLights.Length}");
        foreach (var l in allLights)
        {
            if (l.transform.parent == null || !l.transform.parent.name.Contains("Dungeon"))
            {
                Debug.Log($"[Runtime] Other Light Name: '{l.name}', Type: {l.type}, Pos: {l.transform.position}, Enabled: {l.enabled}, Intensity: {l.intensity}");
            }
        }

        Debug.Log("=== RUNTIME DIAGNOSTICS END ===");
    }

    [MenuItem("Tools/Setup In-Scene Dungeon")]
    public static void SetupInSceneDungeon()
    {
        if (EditorApplication.isPlaying)
        {
            Debug.LogWarning("[SetupCastle] Automatically exiting Play Mode to run Setup In-Scene Dungeon. Please wait a second and run 'Tools -> Setup In-Scene Dungeon' again!");
            EditorApplication.isPlaying = false;
            return;
        }

        // 1. First, let's restore and clean up Dungeon.unity scene
        var dungeonScene = EditorSceneManager.OpenScene("Assets/Scenes/Dungeon.unity", OpenSceneMode.Single);
        
        // Remove copied player-camera setup in Dungeon if they exist
        string[] toDeleteInDungeon = { "PL", "Main Camera", "FreeLook Camera", "Canvas", "EventSystem" };
        foreach (string name in toDeleteInDungeon)
        {
            GameObject obj = GameObject.Find(name);
            if (obj != null)
            {
                Object.DestroyImmediate(obj);
            }
        }

        // Restore a clean Main Camera in Dungeon.unity
        GameObject originalCam = GameObject.Find("Main Camera");
        if (originalCam == null)
        {
            originalCam = new GameObject("Main Camera");
            originalCam.tag = "MainCamera";
            originalCam.AddComponent<Camera>();
            originalCam.AddComponent<AudioListener>();
            originalCam.transform.position = new Vector3(0f, 10f, -10f);
        }

        // Clean up EntryPoint Players list in Dungeon
        GameObject dungeonEntryPointObj = GameObject.Find("EntryPoint");
        if (dungeonEntryPointObj != null)
        {
            EnterPoint ep = dungeonEntryPointObj.GetComponent<EnterPoint>();
            if (ep != null)
            {
                ep.Players.Clear();
            }
        }

        EditorSceneManager.MarkSceneDirty(dungeonScene);
        EditorSceneManager.SaveScene(dungeonScene);

        // 2. Export the Dungeon Terrain and EntryPoint from Dungeon.unity as temporary prefabs
        GameObject terrainSource = GameObject.Find("Terrain");
        GameObject entryPointSource = GameObject.Find("EntryPoint");

        if (terrainSource == null || entryPointSource == null)
        {
            Debug.LogError("[SetupCastle] ERROR: Could not find Terrain or EntryPoint in Dungeon.unity!");
            return;
        }

        string tempFolder = "Assets/TempCopy";
        if (!AssetDatabase.IsValidFolder(tempFolder))
        {
            AssetDatabase.CreateFolder("Assets", "TempCopy");
        }

        string terrainPath = tempFolder + "/DungeonTerrain_Temp.prefab";
        string entryPointPath = tempFolder + "/DungeonEntryPoint_Temp.prefab";

        GameObject terrainPrefab = PrefabUtility.SaveAsPrefabAsset(terrainSource, terrainPath);
        GameObject entryPointPrefab = PrefabUtility.SaveAsPrefabAsset(entryPointSource, entryPointPath);

        // 3. Open SampleScene.unity
        var sampleScene = EditorSceneManager.OpenScene("Assets/Scenes/SampleScene.unity", OpenSceneMode.Single);

        // Clean up old copies in SampleScene if they exist
        GameObject existingDungeonTerrain = GameObject.Find("DungeonTerrain");
        if (existingDungeonTerrain != null)
        {
            Object.DestroyImmediate(existingDungeonTerrain);
        }
        GameObject existingDungeonEntryPoint = GameObject.Find("DungeonEntryPoint");
        if (existingDungeonEntryPoint != null)
        {
            Object.DestroyImmediate(existingDungeonEntryPoint);
        }

        // 4. Instantiate the Dungeon Terrain and EntryPoint into SampleScene
        GameObject terrainCopy = (GameObject)PrefabUtility.InstantiatePrefab(terrainPrefab);
        GameObject entryPointCopy = (GameObject)PrefabUtility.InstantiatePrefab(entryPointPrefab);

        terrainCopy.name = "DungeonTerrain";
        entryPointCopy.name = "DungeonEntryPoint";

        PrefabUtility.UnpackPrefabInstance(terrainCopy, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);
        PrefabUtility.UnpackPrefabInstance(entryPointCopy, PrefabUnpackMode.Completely, InteractionMode.AutomatedAction);

        // Set the layer of DungeonTerrain to 7 (Ground) so that player/enemy ground detection raycasts work!
        terrainCopy.layer = 7;

        // 5. Position them deep below the ground (y = -1000f) to make it under the ground!
        terrainCopy.transform.position = new Vector3(-534f, -1000f, -525f);
        
        // Spawn the player EXACTLY at the center top of the generated ziggurat (-34f, -949f, -25f)
        entryPointCopy.transform.position = new Vector3(-34f, -949f, -25f);
        entryPointCopy.transform.rotation = Quaternion.identity;

        // 6. Create Point Lights around the dungeon ziggurat layers
        GameObject lightsContainer = new GameObject("DungeonLights");
        lightsContainer.transform.SetParent(terrainCopy.transform);
        lightsContainer.transform.localPosition = Vector3.zero;

        // Warm color constants
        Color centralColor = new Color(1.0f, 0.85f, 0.6f); // Warm gold
        Color midLayerColor = new Color(1.0f, 0.7f, 0.4f);  // Warm orange
        Color outerLayerColor = new Color(1.0f, 0.6f, 0.3f); // Dark orange/red

        // Spawns helper for point lights
        System.Action<Vector3, Color, float, float, string> SpawnPointLight = (pos, color, range, intensity, lName) =>
        {
            GameObject lightObj = new GameObject(lName);
            lightObj.transform.SetParent(lightsContainer.transform);
            lightObj.transform.position = pos;
            Light l = lightObj.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = color;
            l.range = range;
            l.intensity = intensity;
            l.shadows = LightShadows.Soft;
        };

        // Center light at the top/spawn point
        SpawnPointLight(new Vector3(-34f, -945f, -25f), centralColor, 60f, 25f, "Central_Light");

        // 4 mid-layer lights (radius 55)
        SpawnPointLight(new Vector3(-34f + 55f, -959f, -25f), midLayerColor, 45f, 15f, "Mid_Light_E");
        SpawnPointLight(new Vector3(-34f - 55f, -959f, -25f), midLayerColor, 45f, 15f, "Mid_Light_W");
        SpawnPointLight(new Vector3(-34f, -959f, -25f + 55f), midLayerColor, 45f, 15f, "Mid_Light_N");
        SpawnPointLight(new Vector3(-34f, -959f, -25f - 55f), midLayerColor, 45f, 15f, "Mid_Light_S");

        // 8 outer-layer lights (radius 115)
        SpawnPointLight(new Vector3(-34f + 115f, -972f, -25f + 115f), outerLayerColor, 50f, 12f, "Outer_Light_NE");
        SpawnPointLight(new Vector3(-34f - 115f, -972f, -25f - 115f), outerLayerColor, 50f, 12f, "Outer_Light_SW");
        SpawnPointLight(new Vector3(-34f - 115f, -972f, -25f + 115f), outerLayerColor, 50f, 12f, "Outer_Light_NW");
        SpawnPointLight(new Vector3(-34f + 115f, -972f, -25f - 115f), outerLayerColor, 50f, 12f, "Outer_Light_SE");
        SpawnPointLight(new Vector3(-34f + 115f, -972f, -25f), outerLayerColor, 50f, 12f, "Outer_Light_E");
        SpawnPointLight(new Vector3(-34f - 115f, -972f, -25f), outerLayerColor, 50f, 12f, "Outer_Light_W");
        SpawnPointLight(new Vector3(-34f, -972f, -25f + 115f), outerLayerColor, 50f, 12f, "Outer_Light_N");
        SpawnPointLight(new Vector3(-34f, -972f, -25f - 115f), outerLayerColor, 50f, 12f, "Outer_Light_S");

        // 7. Add DungeonEnemySpawner component to DungeonTerrain and configure it
        DungeonEnemySpawner spawnerComp = terrainCopy.GetComponent<DungeonEnemySpawner>();
        if (spawnerComp == null)
        {
            spawnerComp = terrainCopy.AddComponent<DungeonEnemySpawner>();
        }
        spawnerComp.enemiesPerChunk = 2;
        spawnerComp.respawnInterval = 20f;
        spawnerComp.spawnRadius = 60f;
        spawnerComp.chunkSize = 40f;
        spawnerComp.baseHP = 120f;
        spawnerComp.baseDamage = 20f;
        
        // Find player in scene to hook it up (will also find it at runtime, but good to have)
        GameObject plObj = GameObject.Find("PL");
        if (plObj != null)
        {
            spawnerComp.playerTransform = plObj.transform;

            // Fix player PL ground detection parameters
            PlayerController pc = plObj.GetComponent<PlayerController>();
            if (pc != null)
            {
                var layerMaskField = typeof(PlayerController).GetField("layerMask", BindingFlags.NonPublic | BindingFlags.Instance);
                var rayDistField = typeof(PlayerController).GetField("raycastDistance", BindingFlags.NonPublic | BindingFlags.Instance);
                
                if (layerMaskField != null)
                {
                    // Layer 7 is Ground. 1 << 7 = 128.
                    LayerMask mask = 128;
                    layerMaskField.SetValue(pc, mask);
                    Debug.Log("[SetupCastle] Set player PL layerMask to Layer 7 (Ground)!");
                }
                
                if (rayDistField != null)
                {
                    // Set raycast distance to 1.5f for smooth ground detection on slopes
                    rayDistField.SetValue(pc, 1.5f);
                    Debug.Log("[SetupCastle] Set player PL raycastDistance to 1.5f!");
                }
            }

            // Also fix the PL prefab so that any newly instantiated players are fixed too!
            GameObject plPrefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/Prefabs/PL.prefab");
            if (plPrefab != null)
            {
                PlayerController prefabPc = plPrefab.GetComponent<PlayerController>();
                if (prefabPc != null)
                {
                    var layerMaskField = typeof(PlayerController).GetField("layerMask", BindingFlags.NonPublic | BindingFlags.Instance);
                    var rayDistField = typeof(PlayerController).GetField("raycastDistance", BindingFlags.NonPublic | BindingFlags.Instance);
                    
                    bool changed = false;
                    if (layerMaskField != null)
                    {
                        LayerMask mask = 128;
                        layerMaskField.SetValue(prefabPc, mask);
                        changed = true;
                    }
                    if (rayDistField != null)
                    {
                        rayDistField.SetValue(prefabPc, 1.5f);
                        changed = true;
                    }
                    if (changed)
                    {
                        EditorUtility.SetDirty(plPrefab);
                        AssetDatabase.SaveAssets();
                        Debug.Log("[SetupCastle] SUCCESSFULLY updated player prefab PL.prefab ground check parameters!");
                    }
                }
            }
        }

        // 8. Register the DungeonTerrain components in StartPoint's initialization list
        GameObject startPointObj = GameObject.Find("StartPoint");
        if (startPointObj != null)
        {
            EnterPoint epComponent = startPointObj.GetComponent<EnterPoint>();
            TerrainNoise_Dungeon noiseDungeon = terrainCopy.GetComponent<TerrainNoise_Dungeon>();
            if (noiseDungeon != null)
            {
                noiseDungeon.stairsPerRamp = 40;
                noiseDungeon.stoneRoughness = 0.001f;
            }
            if (epComponent != null)
            {
                // Remove nulls first
                epComponent.InitializableObjects.RemoveAll(x => x == null);
                
                // Add TerrainNoise_Dungeon
                if (noiseDungeon != null && !epComponent.InitializableObjects.Contains(noiseDungeon))
                {
                    epComponent.InitializableObjects.Add(noiseDungeon);
                }

                // Add DungeonEnemySpawner
                if (spawnerComp != null && !epComponent.InitializableObjects.Contains(spawnerComp))
                {
                    epComponent.InitializableObjects.Add(spawnerComp);
                    Debug.Log("[SetupCastle] Registered DungeonEnemySpawner in StartPoint!");
                }
            }
        }

        // 9. Save SampleScene changes
        EditorSceneManager.MarkSceneDirty(sampleScene);
        EditorSceneManager.SaveScene(sampleScene);

        // 10. Clean up temporary folder
        AssetDatabase.DeleteAsset(tempFolder);

        Debug.Log("[SetupCastle] SUCCESS: In-scene DungeonTerrain set up at y=-1000f, EntryPoint centered at ziggurat top, point lights scattered, and DungeonEnemySpawner configured!");
    }

    private static string GetLayerNames(LayerMask mask)
    {
        System.Text.StringBuilder sb = new System.Text.StringBuilder();
        for (int i = 0; i < 32; i++)
        {
            if ((mask.value & (1 << i)) != 0)
            {
                string name = LayerMask.LayerToName(i);
                if (!string.IsNullOrEmpty(name))
                {
                    if (sb.Length > 0) sb.Append(", ");
                    sb.Append($"{name} ({i})");
                }
            }
        }
        return sb.ToString();
    }
}
