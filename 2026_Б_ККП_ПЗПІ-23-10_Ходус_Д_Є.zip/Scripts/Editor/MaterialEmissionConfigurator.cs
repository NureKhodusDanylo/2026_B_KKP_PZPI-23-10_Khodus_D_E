using UnityEngine;
using UnityEditor;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

public static class MaterialEmissionConfigurator
{
    [MenuItem("Tools/Graphics/Clear Crystal Lights from Scene")]
    public static void ClearCrystalLights()
    {
        Debug.Log("--- Clearing Crystal Lights from Scene ---");
        // Find all GameObjects in the scene to be absolutely sure we get them even if they are inactive
        Light[] lights = GameObject.FindObjectsOfType<Light>(true);
        int count = 0;
        foreach (Light l in lights)
        {
            if (l != null && (l.gameObject.name == "CrystalGlow" || l.gameObject.name == "CrystalGlowLight"))
            {
                Undo.DestroyObjectImmediate(l.gameObject);
                count++;
            }
        }
        
        // Also let's search by name just in case any lost components or empty gameobjects exist
        GameObject[] allObjects = GameObject.FindObjectsOfType<GameObject>(true);
        int emptyCount = 0;
        foreach (GameObject go in allObjects)
        {
            if (go != null && (go.name == "CrystalGlow" || go.name == "CrystalGlowLight"))
            {
                Undo.DestroyObjectImmediate(go);
                emptyCount++;
            }
        }

        Debug.Log($"✅ Cleaned up: deleted {count} light objects (total {emptyCount} objects removed).");
        
        // Mark scene dirty to allow saving
        if (!Application.isPlaying)
        {
            var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(scene);
            UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene);
            Debug.Log("✅ Scene saved after light cleanup.");
        }
    }

    [MenuItem("Tools/Graphics/Configure Magical Forest visuals")]
    public static void ConfigureVisuals()
    {
        Debug.Log("--- MagicUniverse Visual Upgrade V2 Starting ---");

        // ===== 1. SKYBOX: Procedural Night Sky (always works, no texture import issues) =====
        string procSkyPath = "Assets/Materials/ProceduralNightSkybox.mat";
        Material skyboxMat = AssetDatabase.LoadAssetAtPath<Material>(procSkyPath);
        if (skyboxMat == null)
        {
            skyboxMat = new Material(Shader.Find("Skybox/Procedural"));
            AssetDatabase.CreateAsset(skyboxMat, procSkyPath);
            Debug.Log("✅ Created ProceduralNightSkybox.mat");
        }

        skyboxMat.shader = Shader.Find("Skybox/Procedural");
        skyboxMat.SetFloat("_SunDisk", 0f);        // No sun disk
        skyboxMat.SetFloat("_SunSize", 0f);
        skyboxMat.SetFloat("_AtmosphereThickness", 0.35f);
        skyboxMat.SetFloat("_Exposure", 1.6f);
        skyboxMat.SetColor("_SkyTint", new Color(0.06f, 0.03f, 0.2f));       // Deep cosmic violet
        skyboxMat.SetColor("_GroundColor", new Color(0.1f, 0.05f, 0.22f));    // Purple ground
        skyboxMat.EnableKeyword("_SUNDISK_NONE");
        EditorUtility.SetDirty(skyboxMat);
        AssetDatabase.SaveAssets();
        Debug.Log("✅ ProceduralNightSkybox configured.");

        // ===== 2. ASSIGN SKYBOX & AMBIENT =====
        RenderSettings.skybox = skyboxMat;
        RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
        // Trilight gives us explicit control: sky + equator + ground
        RenderSettings.ambientSkyColor    = new Color(0.10f, 0.05f, 0.35f);   // Cosmic violet sky
        RenderSettings.ambientEquatorColor = new Color(0.18f, 0.08f, 0.45f); // Deeper violet
        RenderSettings.ambientGroundColor = new Color(0.08f, 0.03f, 0.25f);  // Dark purple
        RenderSettings.ambientIntensity   = 1.0f;
        Debug.Log("✅ Trilight ambient configured (purple/violet cosmic atmosphere).");

        // ===== 3. DIRECTIONAL LIGHT (Moonlight) =====
        GameObject dirLightObj = GameObject.Find("Directional Light");
        if (dirLightObj != null)
        {
            Light light = dirLightObj.GetComponent<Light>();
            if (light != null)
            {
                light.color     = new Color(0.55f, 0.62f, 0.95f);  // Cool moonlit blue-white
                light.intensity = 1.1f;                              // Visible but not washing out
                light.shadows   = LightShadows.Soft;
                light.shadowStrength = 0.75f;
                // Angle moonlight from upper-left for nice shadows on low-poly meshes
                dirLightObj.transform.rotation = Quaternion.Euler(45f, -30f, 0f);
                EditorUtility.SetDirty(light);
                Debug.Log("✅ Directional Light = moonlit blue-white, intensity 1.1");
            }
        }

        // ===== 4. FOG =====
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.05f, 0.02f, 0.12f);
        RenderSettings.fogMode  = FogMode.Linear;
        RenderSettings.fogStartDistance = 60f;
        RenderSettings.fogEndDistance   = 200f;
        Debug.Log("✅ Atmospheric fog configured.");

        // ===== 5. MATERIAL EMISSIONS =====
        // Crystal materials — find by name from all loaded assets
        string[] matGuids = AssetDatabase.FindAssets("t:Material");
        int count = 0;
        foreach (string guid in matGuids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            Material mat = AssetDatabase.LoadAssetAtPath<Material>(path);
            if (mat == null) continue;

            bool modified = false;
            Color emColor = Color.black;

            switch (mat.name)
            {
                // Cyan crystals
                case "Material.001":
                    emColor = new Color(0.0f, 3.5f, 5.0f);
                    modified = true;
                    break;
                // Magenta/hot-pink crystals
                case "Material.003":
                    emColor = new Color(4.5f, 0.0f, 3.5f);
                    modified = true;
                    break;
                // Deep purple crystals
                case "Material.005":
                    emColor = new Color(2.5f, 0.0f, 5.0f);
                    modified = true;
                    break;
                // Teal/green leaves/highlights
                case "New Material":
                case "New Material 1":
                    emColor = new Color(0.0f, 5.0f, 2.5f);
                    modified = true;
                    break;
                // Bioluminescent path runes
                case "Bioluminescence Emission Shader":
                case "Grid Lines With Edge Emission":
                case "mif 3":
                    emColor = new Color(3.0f, 0.0f, 4.0f);
                    modified = true;
                    break;
                // Sakura / warm flower
                case "Flower warm 1":
                    emColor = new Color(4.0f, 1.5f, 0.5f);
                    modified = true;
                    break;
            }

            if (modified)
            {
                mat.EnableKeyword("_EMISSION");
                mat.SetColor("_EmissionColor", emColor);
                mat.globalIlluminationFlags = MaterialGlobalIlluminationFlags.RealtimeEmissive;
                EditorUtility.SetDirty(mat);
                count++;
                Debug.Log("✅ Emission on: " + mat.name + " → " + path);
            }
        }
        Debug.Log("✅ Configured emission on " + count + " materials.");

        // ===== 6. GOD RAYS (Light shafts) =====
        GameObject raysParent = GameObject.Find("Magical God Rays");
        if (raysParent != null)
        {
            for (int i = raysParent.transform.childCount - 1; i >= 0; i--)
                Object.DestroyImmediate(raysParent.transform.GetChild(i).gameObject);
        }
        else
        {
            raysParent = new GameObject("Magical God Rays");
        }

        Texture2D gradTex;
        Material rayMat;
        CreateGodRayAssets(out gradTex, out rayMat);

        Vector3[] positions = { new Vector3(0f, 22f, 5f), new Vector3(-15f, 20f, -12f), new Vector3(18f, 25f, 15f), new Vector3(10f, 21f, -10f) };
        Vector3[] rotations = { new Vector3(32f, 45f, 0f), new Vector3(38f, 28f, 0f), new Vector3(28f, 62f, 0f), new Vector3(36f, 22f, 0f) };
        Vector3[] scales    = { new Vector3(3f, 22f, 3f), new Vector3(3.5f, 26f, 3.5f), new Vector3(2.5f, 24f, 2.5f), new Vector3(2f, 20f, 2f) };

        for (int i = 0; i < positions.Length; i++)
        {
            GameObject ray = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ray.name = "GodRay_" + (i + 1);
            ray.transform.SetParent(raysParent.transform);
            ray.transform.position      = positions[i];
            ray.transform.rotation      = Quaternion.Euler(rotations[i]);
            ray.transform.localScale    = scales[i];
            Collider col = ray.GetComponent<Collider>();
            if (col != null) Object.DestroyImmediate(col);
            MeshRenderer mr = ray.GetComponent<MeshRenderer>();
            if (mr != null)
            {
                mr.sharedMaterial  = rayMat;
                mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
                mr.receiveShadows  = false;
            }
        }
        Debug.Log("✅ 4 God Rays created under 'Magical God Rays'.");

        // ===== 7. POST-PROCESSING =====
        string profilePath = "Assets/Settings/SampleSceneProfile.asset";
        VolumeProfile profile = AssetDatabase.LoadAssetAtPath<VolumeProfile>(profilePath);
        if (profile != null)
        {
            profile.components.RemoveAll(c => c == null);

            // Tonemapping – ACES for filmic look
            Tonemapping tm;
            if (!profile.TryGet<Tonemapping>(out tm))
            {
                tm = profile.Add<Tonemapping>(true);
                AssetDatabase.AddObjectToAsset(tm, profile);
            }
            tm.mode.Override(TonemappingMode.ACES);
            EditorUtility.SetDirty(tm);

            // Bloom – lush glow
            Bloom bloom;
            if (!profile.TryGet<Bloom>(out bloom))
            {
                bloom = profile.Add<Bloom>(true);
                AssetDatabase.AddObjectToAsset(bloom, profile);
            }
            bloom.threshold.Override(0.7f);
            bloom.intensity.Override(2.2f);
            bloom.scatter.Override(0.72f);
            EditorUtility.SetDirty(bloom);

            // Vignette – cinematic frame
            Vignette vignette;
            if (!profile.TryGet<Vignette>(out vignette))
            {
                vignette = profile.Add<Vignette>(true);
                AssetDatabase.AddObjectToAsset(vignette, profile);
            }
            vignette.intensity.Override(0.38f);
            vignette.smoothness.Override(0.5f);
            EditorUtility.SetDirty(vignette);

            // Color Adjustments – vivid, punchy
            ColorAdjustments ca;
            if (!profile.TryGet<ColorAdjustments>(out ca))
            {
                ca = profile.Add<ColorAdjustments>(true);
                AssetDatabase.AddObjectToAsset(ca, profile);
            }
            ca.postExposure.Override(0.3f);  // Slight exposure boost
            ca.contrast.Override(20f);        // Rich shadows
            ca.saturation.Override(35f);      // Vivid purples/cyans/magentas
            ca.colorFilter.Override(new Color(1f, 1f, 1f));
            EditorUtility.SetDirty(ca);

            // Lift Gamma Gain – purple midtones
            LiftGammaGain lgg;
            if (!profile.TryGet<LiftGammaGain>(out lgg))
            {
                lgg = profile.Add<LiftGammaGain>(true);
                AssetDatabase.AddObjectToAsset(lgg, profile);
            }
            lgg.lift.Override(new Vector4(1.0f, 0.98f, 1.02f, 0.0f));    // Slight purple shadows
            lgg.gamma.Override(new Vector4(1.0f, 0.98f, 1.04f, 0.0f));   // Purple midtones
            lgg.gain.Override(new Vector4(0.95f, 0.95f, 1.05f, 0.0f));   // Blue-purple highlights
            EditorUtility.SetDirty(lgg);

            EditorUtility.SetDirty(profile);
            AssetDatabase.SaveAssets();
            Debug.Log("✅ Post-processing profile updated (ACES + Bloom + CA + LGG + Vignette).");
        }
        else
        {
            Debug.LogWarning("⚠️ Volume Profile not found at " + profilePath);
        }

        // ===== SAVE SCENE =====
        AssetDatabase.SaveAssets();
        if (!Application.isPlaying)
        {
            var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(scene);
            UnityEditor.SceneManagement.EditorSceneManager.SaveScene(scene);
            Debug.Log("✅ Scene saved.");
        }
        Debug.Log("✅✅✅ MagicUniverse Visual Upgrade V2 Complete! ✅✅✅");
    }

    private static void CreateGodRayAssets(out Texture2D gradientTex, out Material godRayMat)
    {
        string texPath = "Assets/Day-Night Skyboxes/Textures/GodRayGradient.png";
        string matPath = "Assets/Day-Night Skyboxes/Materials/GodRayMaterial.mat";

        gradientTex = AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
        if (gradientTex == null)
        {
            int w = 128, h = 128;
            gradientTex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            for (int y = 0; y < h; y++)
            {
                float alpha = Mathf.Pow((float)y / (h - 1), 1.8f);
                for (int x = 0; x < w; x++)
                    gradientTex.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
            }
            gradientTex.Apply();
            byte[] bytes = gradientTex.EncodeToPNG();
            System.IO.File.WriteAllBytes(System.IO.Path.Combine(Application.dataPath, "../" + texPath), bytes);
            AssetDatabase.ImportAsset(texPath);
            TextureImporter imp = AssetImporter.GetAtPath(texPath) as TextureImporter;
            if (imp != null) { imp.alphaIsTransparency = true; imp.wrapMode = TextureWrapMode.Clamp; imp.SaveAndReimport(); }
            gradientTex = AssetDatabase.LoadAssetAtPath<Texture2D>(texPath);
        }

        godRayMat = AssetDatabase.LoadAssetAtPath<Material>(matPath);
        if (godRayMat == null) { godRayMat = new Material(Shader.Find("Universal Render Pipeline/Unlit")); AssetDatabase.CreateAsset(godRayMat, matPath); }
        godRayMat.shader = Shader.Find("Universal Render Pipeline/Unlit");
        godRayMat.SetTexture("_BaseMap", gradientTex);
        godRayMat.SetColor("_BaseColor", new Color(0.4f, 0.55f, 1.0f, 0.14f));
        godRayMat.SetFloat("_Surface", 1); godRayMat.SetFloat("_Blend", 1);
        godRayMat.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.One);
        godRayMat.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.One);
        godRayMat.SetInt("_ZWrite", 0);
        godRayMat.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        EditorUtility.SetDirty(godRayMat);
        AssetDatabase.SaveAssets();
    }
}
