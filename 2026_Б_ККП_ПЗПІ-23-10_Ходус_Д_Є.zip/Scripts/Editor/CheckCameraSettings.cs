using UnityEngine;
using UnityEditor;
using Cinemachine;

public static class CheckCameraSettings
{
    [MenuItem("Tools/Check Camera Settings")]
    public static void CheckSettings()
    {
        GameObject playerGo = GameObject.Find("PL");
        if (playerGo == null)
        {
            Debug.LogError("CheckCameraSettings: PL GameObject not found!");
            return;
        }

        PlayerController pc = playerGo.GetComponent<PlayerController>();
        if (pc == null)
        {
            Debug.LogError("CheckCameraSettings: PlayerController component not found!");
        }
        else
        {
            // Use reflection to get the private field 'model'
            var modelField = typeof(PlayerController).GetField("model", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (modelField != null)
            {
                GameObject modelGo = (GameObject)modelField.GetValue(pc);
                Debug.Log($"--- Player Model Settings ---");
                Debug.Log($"Player Go: {playerGo.name} (Instance ID: {playerGo.GetInstanceID()})");
                Debug.Log($"Player Controller 'model' field: {(modelGo != null ? modelGo.name : "null")} (Instance ID: {(modelGo != null ? modelGo.GetInstanceID().ToString() : "null")})");
                Debug.Log($"Are they the same object? {(playerGo == modelGo ? "YES" : "NO")}");
            }
            else
            {
                Debug.LogError("CheckCameraSettings: 'model' field not found via reflection!");
            }
        }

        GameObject freeLookGo = GameObject.Find("FreeLook Camera");
        if (freeLookGo == null)
        {
            Debug.LogError("CheckCameraSettings: FreeLook Camera GameObject not found!");
            return;
        }

        CinemachineFreeLook freeLook = freeLookGo.GetComponent<CinemachineFreeLook>();
        if (freeLook == null)
        {
            Debug.LogError("CheckCameraSettings: CinemachineFreeLook component not found!");
            return;
        }

        Debug.Log($"--- FreeLook Camera Top-Level Settings ---");
        Debug.Log($"Follow Target: {(freeLook.Follow != null ? freeLook.Follow.name : "null")} (Instance ID: {(freeLook.Follow != null ? freeLook.Follow.gameObject.GetInstanceID().ToString() : "null")})");
        Debug.Log($"LookAt Target: {(freeLook.LookAt != null ? freeLook.LookAt.name : "null")} (Instance ID: {(freeLook.LookAt != null ? freeLook.LookAt.gameObject.GetInstanceID().ToString() : "null")})");
        Debug.Log($"Binding Mode: {freeLook.m_BindingMode}");
        Debug.Log($"Heading Definition: {freeLook.m_Heading.m_Definition}");
        Debug.Log($"Recenter To Target Heading: {freeLook.m_RecenterToTargetHeading.m_enabled}");
        
        // Check X and Y Axis Recentering
        Debug.Log($"X Axis Recentering enabled: {freeLook.m_XAxis.m_Recentering.m_enabled}");
        Debug.Log($"Y Axis Recentering enabled: {freeLook.m_YAxis.m_Recentering.m_enabled}");

        for (int i = 0; i < 3; i++)
        {
            CinemachineVirtualCamera rig = freeLook.GetRig(i);
            if (rig != null)
            {
                var body = rig.GetCinemachineComponent(CinemachineCore.Stage.Body);
                var aim = rig.GetCinemachineComponent(CinemachineCore.Stage.Aim);
                
                string bodyType = body != null ? body.GetType().Name : "null";
                string aimType = aim != null ? aim.GetType().Name : "null";

                var transposer = body as CinemachineOrbitalTransposer;
                string transposerDetails = "";
                if (transposer != null)
                {
                    transposerDetails = $", BindingMode={transposer.m_BindingMode}, HeadingDef={transposer.m_Heading.m_Definition}";
                }

                Debug.Log($"Rig {i}: Body={bodyType}{transposerDetails} | Aim={aimType}");
            }
            else
            {
                Debug.Log($"Rig {i} is null!");
            }
        }
    }
}
