using UnityEngine;
using UnityEditor;
using System.IO;
using System.Collections.Generic;

public class CelShadingSetupHelper : EditorWindow
{
    [MenuItem("Tools/Toon Cel-Shading/Apply Toon Preset to Selection")]
    public static void ApplyPresetToSelection()
    {
        GameObject[] selectedObjects = Selection.gameObjects;
        if (selectedObjects.Length == 0)
        {
            EditorUtility.DisplayDialog("Toon Shading", "Please select at least one GameObject in the Hierarchy or Scene.", "OK");
            return;
        }

        Material toonPreset = AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/CelShadingPreset.mat");
        if (toonPreset == null)
        {
            EditorUtility.DisplayDialog("Toon Shading Error", "CelShadingPreset.mat not found at Assets/Shaders/CelShadingPreset.mat. Please make sure the shader and material files exist.", "OK");
            return;
        }

        int count = 0;
        foreach (GameObject go in selectedObjects)
        {
            // First check and generate smoothed mesh for selected object
            SetupMeshWithSmoothedNormals(go);

            Renderer[] renderers = go.GetComponentsInChildren<Renderer>(true);
            foreach (Renderer renderer in renderers)
            {
                Undo.RecordObject(renderer, "Apply Toon Preset Material");
                Material[] newMats = new Material[renderer.sharedMaterials.Length];
                for (int i = 0; i < newMats.Length; i++)
                {
                    newMats[i] = toonPreset;
                }
                renderer.sharedMaterials = newMats;
                EditorUtility.SetDirty(renderer);
                count++;
            }
        }

        AssetDatabase.SaveAssets();
        Debug.Log($"Successfully applied Cel Shading Preset to {count} renderers.");
        EditorUtility.DisplayDialog("Toon Shading", $"Applied Cel Shading Preset to {count} renderers!", "Awesome");
    }

    [MenuItem("Tools/Toon Cel-Shading/Convert Selected Materials to Toon")]
    public static void ConvertMaterialsToToon()
    {
        GameObject[] selectedObjects = Selection.gameObjects;
        if (selectedObjects.Length == 0)
        {
            EditorUtility.DisplayDialog("Toon Shading", "Please select at least one GameObject to convert.", "OK");
            return;
        }

        Shader toonShader = Shader.Find("URP/Custom/CelShading");
        if (toonShader == null)
        {
            EditorUtility.DisplayDialog("Toon Shading Error", "Shader 'URP/Custom/CelShading' not found! Make sure the shader compiled successfully.", "OK");
            return;
        }

        int count = 0;
        foreach (GameObject go in selectedObjects)
        {
            // First setup smoothed normals mesh to avoid outline tearing!
            SetupMeshWithSmoothedNormals(go);

            Renderer[] renderers = go.GetComponentsInChildren<Renderer>(true);
            foreach (Renderer renderer in renderers)
            {
                Undo.RecordObject(renderer, "Convert materials to Toon");
                Material[] materials = renderer.sharedMaterials;
                Material[] newMats = new Material[materials.Length];

                for (int i = 0; i < materials.Length; i++)
                {
                    Material originalMat = materials[i];
                    if (originalMat == null) continue;

                    // Skip if already custom toon
                    if (originalMat.shader == toonShader)
                    {
                        newMats[i] = originalMat;
                        continue;
                    }

                    // Create a new customized toon material
                    string dir = Path.GetDirectoryName(AssetDatabase.GetAssetPath(originalMat));
                    if (string.IsNullOrEmpty(dir)) dir = "Assets";
                    string newPath = Path.Combine(dir, originalMat.name + "_Toon.mat");
                    
                    Material toonMat = AssetDatabase.LoadAssetAtPath<Material>(newPath);
                    if (toonMat == null)
                    {
                        toonMat = new Material(toonShader);
                        // Copy basic properties
                        if (originalMat.HasProperty("_BaseMap") && originalMat.GetTexture("_BaseMap") != null)
                            toonMat.SetTexture("_BaseMap", originalMat.GetTexture("_BaseMap"));
                        else if (originalMat.HasProperty("_MainTex") && originalMat.GetTexture("_MainTex") != null)
                            toonMat.SetTexture("_BaseMap", originalMat.GetTexture("_MainTex"));

                        if (originalMat.HasProperty("_BaseColor"))
                            toonMat.SetColor("_BaseColor", originalMat.GetColor("_BaseColor"));
                        else if (originalMat.HasProperty("_Color"))
                            toonMat.SetColor("_BaseColor", originalMat.GetColor("_Color"));

                        if (originalMat.HasProperty("_BumpMap") && originalMat.GetTexture("_BumpMap") != null)
                        {
                            toonMat.SetTexture("_BumpMap", originalMat.GetTexture("_BumpMap"));
                            toonMat.SetFloat("_NormalMapOn", 1.0f);
                            toonMat.EnableKeyword("_NORMAL_MAP_ON");
                        }

                        // Copy emission but scale it down slightly to keep it stylized, not overblown!
                        if (originalMat.HasProperty("_EmissionColor"))
                        {
                            Color emColor = originalMat.GetColor("_EmissionColor");
                            // If emission is super bright, scale it down to typical stylized HDR glow
                            float maxIntensity = Mathf.Max(emColor.r, emColor.g, emColor.b);
                            if (maxIntensity > 5.0f)
                            {
                                emColor = emColor * (3.0f / maxIntensity); // Cap at comfortable intensity
                            }
                            
                            toonMat.SetColor("_EmissionColor", emColor);
                            toonMat.SetFloat("_EmissionOn", 1.0f);
                            toonMat.EnableKeyword("_EMISSION_ON");
                        }

                        if (originalMat.HasProperty("_EmissionMap") && originalMat.GetTexture("_EmissionMap") != null)
                        {
                            toonMat.SetTexture("_EmissionMap", originalMat.GetTexture("_EmissionMap"));
                        }

                        // Enable standard preset keywords
                        toonMat.EnableKeyword("_RIM_ON");
                        toonMat.EnableKeyword("_SPECULAR_ON");
                        toonMat.EnableKeyword("_OUTLINE_SCREENSPACE");
                        toonMat.EnableKeyword("_USE_SMOOTHED_NORMALS");
                        
                        // Set outline and shadow properties
                        toonMat.SetColor("_OutlineColor", new Color(0.12f, 0.08f, 0.15f, 1f));
                        toonMat.SetFloat("_OutlineThickness", 0.02f);
                        toonMat.SetFloat("_OutlineDepthOffset", -0.05f);
                        toonMat.SetFloat("_UseSmoothedNormals", 1.0f); // Default to on!
                        
                        // Harmonious shadow color
                        toonMat.SetColor("_ShadowColor", new Color(0.15f, 0.12f, 0.28f, 0.75f));
                        toonMat.SetFloat("_ShadowStrength", 0.8f);
                        
                        AssetDatabase.CreateAsset(toonMat, newPath);
                    }

                    newMats[i] = toonMat;
                    count++;
                }
                renderer.sharedMaterials = newMats;
                EditorUtility.SetDirty(renderer);
            }
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log($"Successfully converted {count} materials to Toon!");
        EditorUtility.DisplayDialog("Toon Shading", $"Successfully converted {count} materials to Cel Shaded! Check original material folders for new Toon materials.", "Awesome");
    }

    [MenuItem("Tools/Toon Cel-Shading/DEMO - Apply to Crystal in Scene")]
    public static void DemoApplyToCrystal()
    {
        var go = GameObject.Find("crystal");
        if (go == null)
        {
            Debug.LogError("GameObject 'crystal' not found in scene!");
            return;
        }

        Selection.activeGameObject = go;

        // 1. Process mesh with smoothed normals to fix outline tearing!
        SetupMeshWithSmoothedNormals(go);

        // 2. Load or create high-quality, beautiful custom material specifically for this crystal
        Shader toonShader = Shader.Find("URP/Custom/CelShading");
        if (toonShader == null)
        {
            Debug.LogError("Toon shader not found!");
            return;
        }

        string matPath = "Assets/Shaders/CrystalToonDemo.mat";
        Material crystalMat = AssetDatabase.LoadAssetAtPath<Material>(matPath);
        if (crystalMat == null)
        {
            crystalMat = new Material(toonShader);
            
            // Base dark amethyst color
            crystalMat.SetColor("_BaseColor", new Color(0.22f, 0.15f, 0.25f, 1f));
            
            // Stylized deep purple shadows
            crystalMat.SetColor("_ShadowColor", new Color(0.1f, 0.05f, 0.18f, 0.85f));
            crystalMat.SetFloat("_ShadowStrength", 0.9f);
            
            // Cel steps and softness
            crystalMat.SetFloat("_CelSteps", 2.0f);
            crystalMat.SetFloat("_CelCutoff", -0.1f);
            crystalMat.SetFloat("_CelSoftness", 0.02f);

            // Neon pink rim light
            crystalMat.SetFloat("_RimOn", 1.0f);
            crystalMat.EnableKeyword("_RIM_ON");
            crystalMat.SetColor("_RimColor", new Color(1.5f, 0.3f, 1.2f, 1f)); // HDR glow rim!
            crystalMat.SetFloat("_RimSize", 0.35f);
            crystalMat.SetFloat("_RimSoftness", 0.05f);
            crystalMat.SetFloat("_RimPower", 2.0f);
            crystalMat.SetFloat("_RimLightAlign", 0.0f); // Rim all around to pop out low poly facets!

            // Specular
            crystalMat.SetFloat("_SpecularOn", 1.0f);
            crystalMat.EnableKeyword("_SPECULAR_ON");
            crystalMat.SetColor("_SpecularColor", new Color(1.0f, 0.8f, 1.0f, 1f));
            crystalMat.SetFloat("_SpecularSize", 0.06f);
            crystalMat.SetFloat("_SpecularSoftness", 0.01f);
            crystalMat.SetFloat("_Glossiness", 128f);

            // Emission (beautiful glowing neon purple, controlled HDR brightness)
            crystalMat.SetFloat("_EmissionOn", 1.0f);
            crystalMat.EnableKeyword("_EMISSION_ON");
            crystalMat.SetColor("_EmissionColor", new Color(1.8f, 0.4f, 1.5f, 1f)); // Gorgeous glow!

            // Outline - graphite purple
            crystalMat.SetColor("_OutlineColor", new Color(0.12f, 0.05f, 0.15f, 1f));
            crystalMat.SetFloat("_OutlineThickness", 0.025f);
            crystalMat.SetFloat("_OutlineDepthOffset", -0.02f);
            crystalMat.SetFloat("_OutlineScreenspace", 1.0f);
            crystalMat.EnableKeyword("_OUTLINE_SCREENSPACE");
            
            // Smoothed normals
            crystalMat.SetFloat("_UseSmoothedNormals", 1.0f);
            crystalMat.EnableKeyword("_USE_SMOOTHED_NORMALS");

            AssetDatabase.CreateAsset(crystalMat, matPath);
        }
        else
        {
            // Reset demo properties to perfect values
            crystalMat.shader = toonShader;
            crystalMat.SetColor("_BaseColor", new Color(0.22f, 0.15f, 0.25f, 1f));
            crystalMat.SetColor("_ShadowColor", new Color(0.1f, 0.05f, 0.18f, 0.85f));
            crystalMat.SetFloat("_ShadowStrength", 0.9f);
            crystalMat.SetFloat("_CelSteps", 2.0f);
            crystalMat.SetFloat("_CelCutoff", -0.1f);
            crystalMat.SetFloat("_CelSoftness", 0.02f);
            crystalMat.SetColor("_RimColor", new Color(1.5f, 0.3f, 1.2f, 1f));
            crystalMat.SetFloat("_RimSize", 0.35f);
            crystalMat.SetFloat("_RimSoftness", 0.05f);
            crystalMat.SetFloat("_RimPower", 2.0f);
            crystalMat.SetFloat("_RimLightAlign", 0.0f);
            crystalMat.SetColor("_SpecularColor", new Color(1.0f, 0.8f, 1.0f, 1f));
            crystalMat.SetFloat("_SpecularSize", 0.06f);
            crystalMat.SetFloat("_SpecularSoftness", 0.01f);
            crystalMat.SetFloat("_Glossiness", 128f);
            crystalMat.SetColor("_EmissionColor", new Color(1.8f, 0.4f, 1.5f, 1f));
            crystalMat.SetColor("_OutlineColor", new Color(0.12f, 0.05f, 0.15f, 1f));
            crystalMat.SetFloat("_OutlineThickness", 0.025f);
            crystalMat.SetFloat("_OutlineDepthOffset", -0.02f);
            crystalMat.SetFloat("_OutlineScreenspace", 1.0f);
            crystalMat.SetFloat("_UseSmoothedNormals", 1.0f);
            crystalMat.EnableKeyword("_USE_SMOOTHED_NORMALS");
        }

        // Apply material to crystal
        var renderer = go.GetComponent<Renderer>();
        if (renderer != null)
        {
            Undo.RecordObject(renderer, "Apply Demo Material");
            renderer.sharedMaterial = crystalMat;
            EditorUtility.SetDirty(renderer);
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    [MenuItem("Tools/Toon Cel-Shading/Setup Global Screen-Space Outline Material")]
    public static void SetupScreenSpaceOutlineMaterial()
    {
        Shader shader = Shader.Find("Hidden/ScreenSpaceOutline");
        if (shader == null)
        {
            Debug.LogError("Error: Shader 'Hidden/ScreenSpaceOutline' not found! Make sure the shader file exists and compiled correctly.");
            return;
        }

        string matPath = "Assets/Shaders/ScreenSpaceOutline.mat";
        Material mat = AssetDatabase.LoadAssetAtPath<Material>(matPath);
        if (mat == null)
        {
            mat = new Material(shader);
            AssetDatabase.CreateAsset(mat, matPath);
        }
        else
        {
            mat.shader = shader;
        }

        // Set beautiful defaults for global outlines:
        mat.SetFloat("_OutlineScale", 1.5f);
        mat.SetColor("_OutlineColor", new Color(0.08f, 0.06f, 0.1f, 1.0f)); // Elegant dark obsidian shadow outline
        mat.SetFloat("_DepthThreshold", 1.5f);
        mat.SetFloat("_NormalThreshold", 0.4f);
        mat.SetFloat("_UseDistanceFade", 1.0f);
        mat.SetFloat("_FadeStart", 20.0f);
        mat.SetFloat("_FadeEnd", 100.0f);

        EditorUtility.SetDirty(mat);
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();

        Debug.Log("Successfully created/updated Assets/Shaders/ScreenSpaceOutline.mat with Hidden/ScreenSpaceOutline shader!");
    }

    [MenuItem("Tools/Toon Cel-Shading/Add Global Outline Feature to Balanced Renderer")]
    public static void AddOutlineFeatureToRenderer()
    {
        var rendererData = AssetDatabase.LoadAssetAtPath<UnityEngine.Rendering.Universal.ScriptableRendererData>("Assets/Settings/URP-Balanced-Renderer.asset");
        if (rendererData == null)
        {
            Debug.LogError("Error: Assets/Settings/URP-Balanced-Renderer.asset not found!");
            return;
        }

        // Setup material first
        SetupScreenSpaceOutlineMaterial();

        bool alreadyExists = false;
        foreach (var feature in rendererData.rendererFeatures)
        {
            if (feature != null && feature.GetType().Name == "ScreenSpaceOutlineFeature")
            {
                alreadyExists = true;
                break;
            }
        }

        if (!alreadyExists)
        {
            var featureInstance = ScriptableObject.CreateInstance<ScreenSpaceOutlineFeature>();
            featureInstance.name = "Screen Space Outline Feature";
            
            // Assign material
            Material outlineMat = AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/ScreenSpaceOutline.mat");
            if (outlineMat != null)
            {
                featureInstance.settings.outlineMaterial = outlineMat;
            }

            AssetDatabase.AddObjectToAsset(featureInstance, rendererData);
            rendererData.rendererFeatures.Add(featureInstance);
            
            EditorUtility.SetDirty(rendererData);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            
            Debug.Log("Successfully added ScreenSpaceOutlineFeature to URP-Balanced-Renderer!");
            EditorUtility.DisplayDialog("Global Toon Outlines", "Successfully added the Screen Space Outline Feature to your URP Balanced Renderer! Outlines are now active across the entire scene.", "Awesome!");
        }
        else
        {
            EditorUtility.DisplayDialog("Global Toon Outlines", "Screen Space Outline Feature is already active on your URP Balanced Renderer!", "Excellent");
        }
    }

    [MenuItem("Tools/Toon Cel-Shading/Add Global Outline Feature WITHOUT Dialog")]
    public static void AddOutlineFeatureToRendererSilent()
    {
        var rendererData = AssetDatabase.LoadAssetAtPath<UnityEngine.Rendering.Universal.ScriptableRendererData>("Assets/Settings/URP-Balanced-Renderer.asset");
        if (rendererData == null)
        {
            Debug.LogError("Error: Assets/Settings/URP-Balanced-Renderer.asset not found!");
            return;
        }

        SetupScreenSpaceOutlineMaterial();

        bool alreadyExists = false;
        foreach (var feature in rendererData.rendererFeatures)
        {
            if (feature != null && feature.GetType().Name == "ScreenSpaceOutlineFeature")
            {
                alreadyExists = true;
                break;
            }
        }

        if (!alreadyExists)
        {
            var featureInstance = ScriptableObject.CreateInstance<ScreenSpaceOutlineFeature>();
            featureInstance.name = "Screen Space Outline Feature";
            
            Material outlineMat = AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/ScreenSpaceOutline.mat");
            if (outlineMat != null)
            {
                featureInstance.settings.outlineMaterial = outlineMat;
            }

            AssetDatabase.AddObjectToAsset(featureInstance, rendererData);
            rendererData.rendererFeatures.Add(featureInstance);
            
            EditorUtility.SetDirty(rendererData);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            
            Debug.Log("Successfully added ScreenSpaceOutlineFeature to URP-Balanced-Renderer!");
        }
        else
        {
            Debug.Log("ScreenSpaceOutlineFeature is already added to URP-Balanced-Renderer.");
        }
    }

    [MenuItem("Tools/Toon Cel-Shading/Setup Global Outlines on Active URP Pipeline")]
    public static void SetupOutlinesOnActiveURPPipeline()
    {
        var pipelineAsset = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline as UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset;
        if (pipelineAsset == null)
        {
            EditorUtility.DisplayDialog("Global Outlines Error", "Active Render Pipeline is not a Universal Render Pipeline Asset! Make sure URP is set up under Project Settings -> Graphics.", "OK");
            return;
        }

        // 1. Enable Depth Texture on active URP Asset
        SerializedObject so = new SerializedObject(pipelineAsset);
        SerializedProperty depthProp = so.FindProperty("m_RequireDepthTexture");
        if (depthProp != null)
        {
            depthProp.boolValue = true;
            so.ApplyModifiedProperties();
            EditorUtility.SetDirty(pipelineAsset);
        }

        // 2. Setup Material
        SetupScreenSpaceOutlineMaterial();
        Material outlineMat = AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/ScreenSpaceOutline.mat");

        // 3. Find and configure default renderer
        SerializedProperty rendererDataListProp = so.FindProperty("m_RendererDataList");
        SerializedProperty defaultRendererIndexProp = so.FindProperty("m_DefaultRendererIndex");
        if (rendererDataListProp != null && defaultRendererIndexProp != null)
        {
            int defaultIndex = defaultRendererIndexProp.intValue;
            if (defaultIndex >= 0 && defaultIndex < rendererDataListProp.arraySize)
            {
                SerializedProperty rendererDataProp = rendererDataListProp.GetArrayElementAtIndex(defaultIndex);
                var rendererData = rendererDataProp.objectReferenceValue as UnityEngine.Rendering.Universal.ScriptableRendererData;
                if (rendererData != null)
                {
                    bool alreadyExists = false;
                    foreach (var feature in rendererData.rendererFeatures)
                    {
                        if (feature != null && feature.GetType().Name == "ScreenSpaceOutlineFeature")
                        {
                            alreadyExists = true;
                            // Ensure material is assigned
                            var outlineFeature = feature as ScreenSpaceOutlineFeature;
                            if (outlineFeature != null && outlineFeature.settings.outlineMaterial == null)
                            {
                                outlineFeature.settings.outlineMaterial = outlineMat;
                                EditorUtility.SetDirty(outlineFeature);
                            }
                            break;
                        }
                    }

                    if (!alreadyExists)
                    {
                        var featureInstance = ScriptableObject.CreateInstance<ScreenSpaceOutlineFeature>();
                        featureInstance.name = "Screen Space Outline Feature";
                        featureInstance.settings.outlineMaterial = outlineMat;

                        AssetDatabase.AddObjectToAsset(featureInstance, rendererData);
                        rendererData.rendererFeatures.Add(featureInstance);
                        
                        EditorUtility.SetDirty(rendererData);
                    }
                }
            }
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        
        EditorUtility.DisplayDialog("Global Outlines Setup", "Successfully enabled 'Depth Texture' on your active URP asset and added the Screen Space Outline Feature to your active renderer! Outlines are now active across the entire scene.", "Awesome!");
    }

    [MenuItem("Tools/Toon Cel-Shading/Setup Global Outlines on Active URP Pipeline WITHOUT Dialog")]
    public static void SetupOutlinesOnActiveURPPipelineSilent()
    {
        var pipelineAsset = UnityEngine.Rendering.GraphicsSettings.currentRenderPipeline as UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset;
        if (pipelineAsset == null)
        {
            Debug.LogError("Error: Active Render Pipeline is not a URP Asset!");
            return;
        }

        SerializedObject so = new SerializedObject(pipelineAsset);
        SerializedProperty depthProp = so.FindProperty("m_RequireDepthTexture");
        if (depthProp != null)
        {
            depthProp.boolValue = true;
            so.ApplyModifiedProperties();
            EditorUtility.SetDirty(pipelineAsset);
        }

        SetupScreenSpaceOutlineMaterial();
        Material outlineMat = AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/ScreenSpaceOutline.mat");

        SerializedProperty rendererDataListProp = so.FindProperty("m_RendererDataList");
        SerializedProperty defaultRendererIndexProp = so.FindProperty("m_DefaultRendererIndex");
        if (rendererDataListProp != null && defaultRendererIndexProp != null)
        {
            int defaultIndex = defaultRendererIndexProp.intValue;
            if (defaultIndex >= 0 && defaultIndex < rendererDataListProp.arraySize)
            {
                SerializedProperty rendererDataProp = rendererDataListProp.GetArrayElementAtIndex(defaultIndex);
                var rendererData = rendererDataProp.objectReferenceValue as UnityEngine.Rendering.Universal.ScriptableRendererData;
                if (rendererData != null)
                {
                    bool alreadyExists = false;
                    foreach (var feature in rendererData.rendererFeatures)
                    {
                        if (feature != null && feature.GetType().Name == "ScreenSpaceOutlineFeature")
                        {
                            alreadyExists = true;
                            var outlineFeature = feature as ScreenSpaceOutlineFeature;
                            if (outlineFeature != null && outlineFeature.settings.outlineMaterial == null)
                            {
                                outlineFeature.settings.outlineMaterial = outlineMat;
                                EditorUtility.SetDirty(outlineFeature);
                            }
                            break;
                        }
                    }

                    if (!alreadyExists)
                    {
                        var featureInstance = ScriptableObject.CreateInstance<ScreenSpaceOutlineFeature>();
                        featureInstance.name = "Screen Space Outline Feature";
                        featureInstance.settings.outlineMaterial = outlineMat;

                        AssetDatabase.AddObjectToAsset(featureInstance, rendererData);
                        rendererData.rendererFeatures.Add(featureInstance);
                        
                        EditorUtility.SetDirty(rendererData);
                    }
                }
            }
        }

        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
        Debug.Log("Successfully silently configured Global Outlines on active URP Pipeline.");
    }

    [MenuItem("Tools/Toon Cel-Shading/Assign and Setup Active Pipeline")]
    public static void AssignAndSetupActivePipeline()
    {
        EnableDepthOnAllURPAssets();

        var pipelineAsset = UnityEngine.Rendering.GraphicsSettings.renderPipelineAsset as UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset;
        if (pipelineAsset == null)
        {
            pipelineAsset = AssetDatabase.LoadAssetAtPath<UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset>("Assets/Settings/URP-Balanced.asset");
            if (pipelineAsset != null)
            {
                UnityEngine.Rendering.GraphicsSettings.renderPipelineAsset = pipelineAsset;
                Debug.Log($"Assigned active render pipeline to: {pipelineAsset.name}");
            }
            else
            {
                Debug.LogError("Error: URP-Balanced.asset not found at Assets/Settings/URP-Balanced.asset");
                return;
            }
        }
        
        SetupOutlinesOnActiveURPPipelineSilent();
    }

    [MenuItem("Tools/Toon Cel-Shading/Enable Depth Texture on ALL URP Assets")]
    public static void EnableDepthOnAllURPAssets()
    {
        string[] guids = AssetDatabase.FindAssets("t:UniversalRenderPipelineAsset");
        foreach (string guid in guids)
        {
            string path = AssetDatabase.GUIDToAssetPath(guid);
            var urpAsset = AssetDatabase.LoadAssetAtPath<UnityEngine.Rendering.Universal.UniversalRenderPipelineAsset>(path);
            if (urpAsset != null)
            {
                SerializedObject so = new SerializedObject(urpAsset);
                SerializedProperty depthProp = so.FindProperty("m_RequireDepthTexture");
                if (depthProp != null)
                {
                    depthProp.boolValue = true;
                    so.ApplyModifiedProperties();
                    EditorUtility.SetDirty(urpAsset);
                    Debug.Log($"Successfully enabled Depth Texture on URP Asset: {urpAsset.name}");
                }
            }
        }
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }

    private static void SetupMeshWithSmoothedNormals(GameObject go)
    {
        MeshFilter meshFilter = go.GetComponent<MeshFilter>();
        if (meshFilter != null && meshFilter.sharedMesh != null)
        {
            Mesh originalMesh = meshFilter.sharedMesh;
            
            // Avoid double processing
            if (originalMesh.name.EndsWith("_Smoothed")) return;

            string smoothedDir = "Assets/Shaders/SmoothedMeshes";
            if (!Directory.Exists(smoothedDir))
            {
                Directory.CreateDirectory(smoothedDir);
            }

            string assetPath = Path.Combine(smoothedDir, originalMesh.name + "_Smoothed.asset");
            Mesh smoothedMesh = AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
            
            if (smoothedMesh == null)
            {
                smoothedMesh = GenerateSmoothedNormals(originalMesh);
                smoothedMesh.name = originalMesh.name + "_Smoothed";
                AssetDatabase.CreateAsset(smoothedMesh, assetPath);
            }

            Undo.RecordObject(meshFilter, "Apply Smoothed Mesh");
            meshFilter.sharedMesh = smoothedMesh;
            EditorUtility.SetDirty(meshFilter);
        }

        SkinnedMeshRenderer skinnedRenderer = go.GetComponent<SkinnedMeshRenderer>();
        if (skinnedRenderer != null && skinnedRenderer.sharedMesh != null)
        {
            Mesh originalMesh = skinnedRenderer.sharedMesh;
            if (originalMesh.name.EndsWith("_Smoothed")) return;

            string smoothedDir = "Assets/Shaders/SmoothedMeshes";
            if (!Directory.Exists(smoothedDir))
            {
                Directory.CreateDirectory(smoothedDir);
            }

            string assetPath = Path.Combine(smoothedDir, originalMesh.name + "_Smoothed.asset");
            Mesh smoothedMesh = AssetDatabase.LoadAssetAtPath<Mesh>(assetPath);
            
            if (smoothedMesh == null)
            {
                smoothedMesh = GenerateSmoothedNormals(originalMesh);
                smoothedMesh.name = originalMesh.name + "_Smoothed";
                AssetDatabase.CreateAsset(smoothedMesh, assetPath);
            }

            Undo.RecordObject(skinnedRenderer, "Apply Smoothed Skinned Mesh");
            skinnedRenderer.sharedMesh = smoothedMesh;
            EditorUtility.SetDirty(skinnedRenderer);
        }
    }

    public static Mesh GenerateSmoothedNormals(Mesh originalMesh)
    {
        Mesh mesh = Instantiate(originalMesh);
        Vector3[] vertices = mesh.vertices;
        Vector3[] normals = mesh.normals;
        Vector4[] tangents = new Vector4[vertices.Length];

        // Dictionary to group normals by position
        Dictionary<Vector3, Vector3> positionToNormal = new Dictionary<Vector3, Vector3>();

        for (int i = 0; i < vertices.Length; i++)
        {
            Vector3 v = vertices[i];
            if (!positionToNormal.ContainsKey(v))
            {
                positionToNormal[v] = Vector3.zero;
            }
            positionToNormal[v] += normals[i];
        }

        // Normalize grouped normals
        List<Vector3> keys = new List<Vector3>(positionToNormal.Keys);
        foreach (Vector3 key in keys)
        {
            positionToNormal[key] = positionToNormal[key].normalized;
        }

        // Write as tangents
        for (int i = 0; i < vertices.Length; i++)
        {
            Vector3 smoothedNormal = positionToNormal[vertices[i]];
            tangents[i] = new Vector4(smoothedNormal.x, smoothedNormal.y, smoothedNormal.z, 1f);
        }

        mesh.tangents = tangents;
        return mesh;
    }
}
