using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Singleton that tracks how many shards of each type the player has collected.
/// Persists counts via PlayerPrefs.
/// </summary>
public class ShardInventory : MonoBehaviour
{
    public static ShardInventory Instance { get; private set; }

    // Fires when any count changes: (type, newCount)
    public event Action<ShardType, int> OnChanged;

    private Dictionary<ShardType, int> _counts = new Dictionary<ShardType, int>();

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
        LoadAll();
    }

    // ─── Public API ────────────────────────────────────────────────────────────

    public void Add(ShardType type, int amount = 1)
    {
        if (!_counts.ContainsKey(type)) _counts[type] = 0;
        _counts[type] += amount;
        OnChanged?.Invoke(type, _counts[type]);
        SaveAll();
        Debug.Log($"<color=#A0FFB0>[ShardInventory]</color> +{amount} <b>{type}</b> Shard  (total: {_counts[type]})");
    }

    public int Get(ShardType type) =>
        _counts.TryGetValue(type, out int v) ? v : 0;

    public bool Remove(ShardType type, int amount = 1)
    {
        if (Get(type) < amount) return false;
        _counts[type] -= amount;
        OnChanged?.Invoke(type, _counts[type]);
        SaveAll();
        return true;
    }

    // ─── Persistence ───────────────────────────────────────────────────────────

    private void SaveAll()
    {
        foreach (ShardType t in Enum.GetValues(typeof(ShardType)))
            PlayerPrefs.SetInt("ShardInv_" + t, Get(t));
        PlayerPrefs.Save();
    }

    private void LoadAll()
    {
        foreach (ShardType t in Enum.GetValues(typeof(ShardType)))
            _counts[t] = PlayerPrefs.GetInt("ShardInv_" + t, 0);
    }
}
