﻿using UnityEngine;
using System.Collections.Generic;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager Instance { get; private set; }

    [SerializeField] private GameObject inventoryPanel;

    [Header("Shard HUD")]
    [Tooltip("Bottom-left HUD with live 3D shard renders (hidden while inventory is open)")]
    [SerializeField] private GameObject shardHUD;

    private List<Transform> slots = new List<Transform>();

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private void Start()
    {
        inventoryPanel.SetActive(false);
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;

        // Collect only non-shard drag-and-drop slots (slots 4+ which have InventorySlot but no ShardHUDSlot)
        foreach (Transform child in inventoryPanel.transform)
        {
            if (child.GetComponent<ShardHUDSlot>() == null)
                slots.Add(child);
        }

        LoadInventory();
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
            OpenInventory(!inventoryPanel.activeSelf);
    }

    public void OpenInventory(bool open)
    {
        inventoryPanel.SetActive(open);

        // Hide bottom HUD while inventory is open (shards visible in slots instead)
        if (shardHUD != null) shardHUD.SetActive(!open);

        if (open)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible   = true;
            Time.timeScale   = 0f;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible   = false;
            Time.timeScale   = 1f;
        }
    }

    public void SaveInventory()
    {
        for (int i = 0; i < slots.Count; i++)
        {
            PlayerPrefs.SetString("Slot_" + i,
                slots[i].childCount > 0 ? slots[i].GetChild(0).name : "Empty");
        }
        PlayerPrefs.Save();
        Debug.Log("[InventoryManager] Saved.");
    }

    public void LoadInventory()
    {
        DraggableItem[] allItems = FindObjectsOfType<DraggableItem>(true);
        for (int i = 0; i < slots.Count; i++)
        {
            if (!PlayerPrefs.HasKey("Slot_" + i)) continue;
            string savedName = PlayerPrefs.GetString("Slot_" + i);
            if (savedName == "Empty") continue;
            foreach (DraggableItem item in allItems)
            {
                if (item.name == savedName)
                {
                    item.transform.SetParent(slots[i]);
                    item.transform.localPosition = Vector3.zero;
                    break;
                }
            }
        }
        Debug.Log("[InventoryManager] Loaded.");
    }
}
