using UnityEngine;

public static class ShaderColorCalculator
{
    // --- Helper for frac (GLSL equivalent) ---
    private static float Frac(float x)
    {
        return x - Mathf.Floor(x);
    }

    private static Vector3 Frac(Vector3 v)
    {
        return new Vector3(Frac(v.x), Frac(v.y), Frac(v.z));
    }

    // --- Kolca Logic ---
    // Corresponds to the 'kolca (Custom Function)'
    public static float CalculateHue(Vector2 worldXZ_uv, float time, float speed, float ringDensity)
    {
        Vector2 centeredUV = worldXZ_uv - new Vector2(0.5f, 0.5f);
        float dist = centeredUV.magnitude; // length(centeredUV)

        float animated = dist * ringDensity - time * speed;
        float ringID = animated; // As in shader
        float hue = Frac(ringID * 0.1f);

        return hue;
    }

    // --- HSVtoRGB Logic (Custom Implementation) ---
    // Corresponds to the 'HSVtoRGB (Custom Function)'
    public static Color CustomHSVToRGB(Vector3 hsv) // hsv.x = H, hsv.y = S, hsv.z = V
    {
        // In GLSL c.x = H, c.y = S, c.z = V
        float H = hsv.x;
        float S = hsv.y;
        float V = hsv.z;

        Vector4 K = new Vector4(1.0f, 2.0f / 3.0f, 1.0f / 3.0f, 3.0f);

        Vector3 pInput = new Vector3(H + K.x, H + K.y, H + K.z);
        Vector3 pFrac = Frac(pInput);
        Vector3 p = new Vector3(
            Mathf.Abs(pFrac.x * 6.0f - K.w),
            Mathf.Abs(pFrac.y * 6.0f - K.w),
            Mathf.Abs(pFrac.z * 6.0f - K.w)
        );

        Vector3 pMinusKxxx = new Vector3(p.x - K.x, p.y - K.x, p.z - K.x);
        Vector3 saturatedP = new Vector3(
            Mathf.Clamp01(pMinusKxxx.x),
            Mathf.Clamp01(pMinusKxxx.y),
            Mathf.Clamp01(pMinusKxxx.z)
        );

        float r = V * Mathf.Lerp(K.x, saturatedP.x, S);
        float g = V * Mathf.Lerp(K.x, saturatedP.y, S);
        float b = V * Mathf.Lerp(K.x, saturatedP.z, S);

        return new Color(r, g, b, 1.0f); // Assuming alpha is 1
    }

    // --- Main function to get color at world coordinates ---
    public static Color GetColorAtWorldPosition(float worldX, float worldZ,
                                                float time, float speed, float ringDensity)
    {
        // 1. Get UV from World Position (as per your graph)
        Vector2 worldXZ_uv = new Vector2(worldX, worldZ);

        // 2. Calculate Hue using Kolca logic
        float hue = CalculateHue(worldXZ_uv, time, speed, ringDensity);

        // 3. Construct HSV vector (Saturation and Value are 1.0f from the graph)
        Vector3 hsv = new Vector3(hue, 1.0f, 1.0f);

        // 4. Convert HSV to RGB
        // You can use Unity's built-in, which is often more optimized and robust,
        // or your custom one if it has specific behavior you need.
        // For standard HSV, Unity's is fine:
        // Color finalColor = Color.HSVToRGB(hsv.x, hsv.y, hsv.z);

        // Using your custom HSVtoRGB function:
        Color finalColor = CustomHSVToRGB(hsv);

        return finalColor;
    }
}

