using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.VFX;
using System;

public class MeleeEnemyAnimationController : MonoBehaviour, IInitializable, IDisposable
{
    [SerializeField] private EnemyStateManager enemyStateManager;
    [SerializeField] private Animator animationController;

    [Header("Death")]
    [SerializeField] private GameObject smertVFX;
    [SerializeField] private Renderer dissolveRenderer;
    private List<Material> dissolveInstances = new List<Material>();
    [SerializeField] private float dissolveDuration = 1.5f;

    private bool isDead = false;

    public void Init()
    {
        animationController.applyRootMotion = false;

        enemyStateManager.Stay += Stand;
        enemyStateManager.Run += Run;
        enemyStateManager.AttackStart += Attack;
        enemyStateManager.AttackEnd += Stand;
        enemyStateManager.Die += OnDeath;

        if (smertVFX != null)
            smertVFX.SetActive(false);

        if (dissolveRenderer != null)
        {
            // .materials (plural) creates unique instances for ALL materials on this renderer
            Material[] mats = dissolveRenderer.materials;
            dissolveInstances.Clear();
            
            foreach (var mat in mats)
            {
                if (mat.HasProperty("_Dissolve_Amount"))
                {
                    dissolveInstances.Add(mat);
                    mat.SetFloat("_Dissolve_Amount", 0f);
                }
            }
        }
    }

    public void Dispose()
    {
        enemyStateManager.Stay -= Stand;
        enemyStateManager.Run -= Run;
        enemyStateManager.AttackStart -= Attack;
        enemyStateManager.Die -= OnDeath;
    }

    private void Stand()
    {
        if (isDead) return;
        animationController.SetTrigger("Stay");
    }

    private void Run()
    {
        if (isDead) return;
        animationController.SetTrigger("Run");
    }

    private void Attack()
    {
        if (isDead) return;
        animationController.SetTrigger("Attack");
    }

    private void OnDeath()
    {
        if (isDead) return;
        isDead = true;

        animationController.applyRootMotion = true;
        animationController.SetTrigger("Death");

        if (smertVFX != null)
        {
            smertVFX.SetActive(true);
            var vfx = smertVFX.GetComponent<VisualEffect>();
            if (vfx != null)
                vfx.Play();
        }

        StartCoroutine(DissolveCoroutine());
    }

    private IEnumerator DissolveCoroutine()
    {
        if (dissolveInstances.Count > 0)
        {
            float elapsed = 0f;
            while (elapsed < dissolveDuration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / dissolveDuration);
                
                foreach (var mat in dissolveInstances)
                {
                    mat.SetFloat("_Dissolve_Amount", t);
                }
                yield return null;
            }

            foreach (var mat in dissolveInstances)
            {
                mat.SetFloat("_Dissolve_Amount", 1f);
            }
        }
        else
        {
            yield return new WaitForSeconds(dissolveDuration);
        }

        Destroy(enemyStateManager.gameObject);
    }
}
