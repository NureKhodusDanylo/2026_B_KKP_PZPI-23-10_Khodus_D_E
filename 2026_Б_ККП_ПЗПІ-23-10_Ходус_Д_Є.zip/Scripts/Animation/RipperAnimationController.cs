using System;
using UnityEngine;

public class RipperAnimationController : MonoBehaviour, IInitializable, IDisposable
{
    [SerializeField] private EnemyStateManager enemyStateManager;
    [SerializeField] private Animator animationController;

    public void Init()
    {
        if (animationController != null)
        {
            animationController.applyRootMotion = false;
        }

        if (enemyStateManager != null)
        {
            enemyStateManager.Stay += Stand;
            enemyStateManager.Run += Run;
            enemyStateManager.AttackStart += Explosion;
            enemyStateManager.AttackEnd += Stand;
        }
        else
        {
            Debug.LogError("RipperAnimationController: EnemyStateManager is not assigned!");
        }
    }

    public void Dispose()
    {
        if (enemyStateManager != null)
        {
            enemyStateManager.Stay -= Stand;
            enemyStateManager.Run -= Run;
            enemyStateManager.AttackStart -= Explosion;
            enemyStateManager.AttackEnd -= Stand;
        }
    }

    private void Stand()
    {
        if (animationController != null) animationController.SetTrigger("Stay");
    }

    private void Run()
    {
        if (animationController != null) animationController.SetTrigger("Run");
    }

    private void Explosion()
    {
        if (animationController != null) animationController.SetTrigger("Explosion");
    }
}
