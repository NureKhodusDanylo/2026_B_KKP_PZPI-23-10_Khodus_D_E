using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractMenuAnimManager : MonoBehaviour
{
    [SerializeField] private Animator animator;


    public void StartAnimation()
    {
        if (animator != null)
        {
            animator.enabled = true;
            animator.SetBool("received", true);
        }
    }

    public void ReverseAnimation()
    {
        if (animator != null)
        {
            animator.SetBool("received", false);                          
        }
    }
}
