using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using Assets.Scripts.AMagic;

public class PlayerAnimationController : MonoBehaviour, IInitializable, IDisposable
{
    [SerializeField] private PlayerController playerController;
    [SerializeField] private MagicWeapon magicWeapon;
    [SerializeField] private Animator animationController;

    public void Init()
    {
        animationController.applyRootMotion = false;

        playerController.OnWalk += Walk;
        playerController.OnStop += Stand;
        playerController.OnRun += Run;
        playerController.OnDash += Dash;
        
        if (magicWeapon != null)
            magicWeapon.OnCast += Cast;

    }

    public void Dispose()
    {
        playerController.OnWalk -= Walk;
        playerController.OnStop -= Stand;
        playerController.OnRun -= Run;
        playerController.OnDash -= Dash;

        if (magicWeapon != null)
            magicWeapon.OnCast -= Cast;
    }

    private void Stand()
    {
       animationController.SetTrigger("Stand");
    }

    private void Walk()
    {
        animationController.SetTrigger("Walk");
    }

    private void Run()
    {
        animationController.SetTrigger("Run");
    }

    private void Dash()
    {
        animationController.SetTrigger("Dash");
    }

    private void Cast()
    {
        animationController.SetTrigger("Cast");
    }
}
