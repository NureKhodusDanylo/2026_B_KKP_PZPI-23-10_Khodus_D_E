using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class RangeEnemyAnimationController : MonoBehaviour, IInitializable, IDisposable
{
    [SerializeField] private EnemyStateManager enemyStateManager;
    [SerializeField] private Animator animationController;

    public void Init()
    {
        animationController.applyRootMotion = false;

        enemyStateManager.Stay += Stand;
        enemyStateManager.Run += Run;
        enemyStateManager.AttackStart += Attack;
        enemyStateManager.AttackEnd += Stand;
    }

    public void Dispose()
    {
        if (enemyStateManager != null)
        {
            enemyStateManager.Stay -= Stand;
            enemyStateManager.Run -= Run;
            enemyStateManager.AttackStart -= Attack;
            enemyStateManager.AttackEnd -= Stand;
        }
    }

    private void Stand()
    {
        animationController.SetTrigger("Stay");
    }

    private void Run()
    {
        animationController.SetTrigger("Run");
    }

    private void Attack()
    {
        animationController.SetTrigger("Attack");
    }
}
