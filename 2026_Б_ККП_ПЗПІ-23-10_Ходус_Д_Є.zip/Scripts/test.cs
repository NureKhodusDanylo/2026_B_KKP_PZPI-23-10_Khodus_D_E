using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (!other.TryGetComponent<IDamageable>(out var component))
        {
            component = other.GetComponentInParent<IDamageable>();
        }

        if (component != null)
        {
            component.TakeDamage(5f);
            Debug.Log("Damage taken");
        }
    }
}
