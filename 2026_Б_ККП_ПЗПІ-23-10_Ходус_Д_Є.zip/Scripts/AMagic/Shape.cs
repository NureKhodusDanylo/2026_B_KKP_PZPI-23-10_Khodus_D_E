using Assets.Scripts.AMagic;
using System.Collections.Generic;
using UnityEngine;
using System;
using UnityEngine.UIElements;
using System.Collections;

public abstract class Shape : MonoBehaviour, IModifiable
{
    [SerializeField] public GameObject BaseObjectPref;
    [SerializeField] protected Transform SpawnPoint;
    public GameObject BaseObject { get; protected set; }
    public GameObject Parent { get; protected set; }

    public Shape NextShape;

    public Vector3 Position { get; protected set; }
    public Quaternion Rotation { get; protected set; }
    public float ScaleFactor { get; protected set; }

    public static Dictionary<Type, Action<IModifiable, Shape>> ShapeTypeIModifiable =
    new Dictionary<Type, Action<IModifiable, Shape>>()
    {
        { typeof(SphereForm), (mod, caller) => mod.SphereModify(caller) },
        { typeof(LaserForm), (mod, caller) => mod.LaserModify(caller) },
        { typeof(ProjectileForm), (mod, caller) => mod.ProjectileModify(caller) },
        { typeof(SprayForm), (mod, caller) => mod.SprayModify(caller) }
    };

    public void SetUpForFirst()
    {
        Position = SpawnPoint.position;
        Rotation = SpawnPoint.rotation;
        ScaleFactor = 1;
    }

    public virtual void ShapeLogic()
    {
        if (NextShape == null)
        {
            BaseLogic();
        }
        else if (ShapeTypeIModifiable.TryGetValue(this.GetType(), out var action))
        {
            action((IModifiable)NextShape, this);
        }
        else
        {
            Debug.LogWarning($" {NextShape.GetType()} ShapeTypeIModifiable");
        }
    }


    public virtual void BaseLogic() { }

    public abstract void SphereModify(Shape shape);
    public abstract void LaserModify(Shape shape);
    public abstract void ProjectileModify(Shape shape);
    public abstract void SprayModify(Shape shape);

    protected virtual IEnumerator CascadeSpawn(float delay, Vector3 centerPos, Quaternion finalRotation)
    {
        yield return new WaitForSeconds(delay);

        Position = centerPos;
        Rotation = finalRotation;

        ShapeLogic();
    }

    // ========================
    // Helper methods for forms
    // ========================

    /// <summary>
    /// Simple modify: sets scale, position, rotation, parent from source shape and calls ShapeLogic.
    /// </summary>
    protected void SimpleModify(Shape sourceShape, float scaleFactor)
    {
        ScaleFactor = scaleFactor;
        Position = sourceShape.Position;
        Rotation = sourceShape.Rotation;
        Parent = sourceShape.Parent;
        ShapeLogic();
    }

    /// <summary>
    /// Spawns shapes distributed on a fibonacci sphere.
    /// </summary>
    protected void SpawnInSpherePattern(Assets.Scripts.AMagic.SphereDistributionConfig config, Shape sourceShape, GameObject parentOverride = null)
    {
        Parent = parentOverride != null ? parentOverride : sourceShape.Parent;
        ScaleFactor = sourceShape.ScaleFactor * config.scaleFactorMultiplier;

        int count = Assets.Scripts.AMagic.SpawnDistribution.CalcCount(config.countMultiplier, sourceShape.ScaleFactor, config.minCount);
        float radius = config.radiusScalesWithShape
            ? config.radius * sourceShape.ScaleFactor
            : config.radius;

        Quaternion? baseRot = config.useRandomRotation ? (Quaternion?)null : (Quaternion?)sourceShape.Rotation;
        var points = Assets.Scripts.AMagic.SpawnDistribution.FibonacciSphere(
            sourceShape.Position, count, radius, config.useRandomRotation, baseRot);

        foreach (var point in points)
        {
            Position = point.Position;
            Rotation = point.Rotation;
            ShapeLogic();
        }
    }

    /// <summary>
    /// Spawns shapes in a fan/spray arc pattern using cascade coroutines.
    /// </summary>
    protected void SpawnInFanPattern(Assets.Scripts.AMagic.FanDistributionConfig config, Shape sourceShape)
    {
        Parent = sourceShape.Parent;
        ScaleFactor = sourceShape.ScaleFactor * config.scaleFactorMultiplier;

        int count = Assets.Scripts.AMagic.SpawnDistribution.CalcCount(config.countMultiplier, sourceShape.ScaleFactor, config.minCount);

        var points = Assets.Scripts.AMagic.SpawnDistribution.Fan(
            sourceShape.Position, sourceShape.Rotation, count,
            config.startAngle, config.endAngle, config.distance,
            config.rotationAxis, config.alternateOrder);

        for (int i = 0; i < points.Count; i++)
        {
            Vector3 pos = config.useSourcePosition ? sourceShape.Position : points[i].Position;
            CoroutineRunner.Instance.RunCoroutine(
                CascadeSpawn(config.cascadeDelay * i, pos, points[i].Rotation));
        }
    }

    /// <summary>
    /// Spawns shapes along a line in the forward direction.
    /// </summary>
    protected void SpawnInLinePattern(Assets.Scripts.AMagic.LinearDistributionConfig config, Shape sourceShape)
    {
        Parent = sourceShape.Parent;
        ScaleFactor = sourceShape.ScaleFactor * config.scaleFactorMultiplier;

        int count = Assets.Scripts.AMagic.SpawnDistribution.CalcCount(config.countMultiplier, sourceShape.ScaleFactor, config.minCount);
        float interval = config.intervalScalesWithShape
            ? config.interval * sourceShape.ScaleFactor
            : config.interval;

        var points = Assets.Scripts.AMagic.SpawnDistribution.Linear(
            sourceShape.Position, sourceShape.Rotation, count, interval);

        for (int i = 0; i < points.Count; i++)
        {
            CoroutineRunner.Instance.RunCoroutine(
                CascadeSpawn(config.cascadeDelay * i, points[i].Position, points[i].Rotation));
        }
    }

    /// <summary>
    /// Launches the source shape's BaseObjectPref as a physics projectile.
    /// </summary>
    protected GameObject LaunchProjectile(Assets.Scripts.AMagic.ProjectileLaunchConfig config, Shape sourceShape)
    {
        Position = sourceShape.Position;
        Rotation = sourceShape.Rotation;
        ScaleFactor = sourceShape.ScaleFactor * config.scaleFactorMultiplier;

        GameObject projectileObject = PoolManager.Instanse.CreateObject(
            sourceShape.BaseObjectPref, Position, Rotation, sourceShape.ScaleFactor);

        Rigidbody rb = projectileObject.GetComponent<Rigidbody>();
        rb.AddForce(projectileObject.transform.forward * config.force);
        rb.AddTorque(UnityEngine.Random.onUnitSphere * config.torqueStrength, ForceMode.Impulse);

        return projectileObject;
    }
}
