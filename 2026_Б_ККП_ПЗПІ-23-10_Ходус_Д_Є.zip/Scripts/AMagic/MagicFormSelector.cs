using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

namespace Assets.Scripts.AMagic
{
    public class MagicFormSelector : MonoBehaviour
    {
        [System.Serializable]
        public class MagicFormOption
        {
            public string formName;
            public GameObject visualPrefab; // 3D префаб для отображения в колесе выбора
            public Shape shapePrefab;       // Сам префаб формы (LaserForm, SphereForm и т.д.)
        }

        public MagicWeapon magicWeapon;
        public List<MagicFormOption> formOptions;

        [Header("UI Настройки")]
        public float radius = 2f;
        public float distanceFromCamera = 4f;
        public float scaleNormal = 1f;
        public float scaleSelected = 1.6f;
        
        [Header("Анимации")]
        public float animationSpeed = 12f;  // Скорость изменения размера
        public float floatAmplitude = 0.15f;// Амплитуда парения (вверх-вниз)
        public float floatSpeed = 2f;       // Скорость парения
        public float rotationSpeed = 45f;   // Скорость вращения фигур

        [Header("Орбита выбранных фигур")]
        public float orbitRadius = 1.2f;
        public float orbitRotationSpeed = 60f;
        public float orbitScale = 0.35f;    // Размер фигурок на орбите

        private bool isSelecting = false;
        private int selectedIndex = 0;

        // Состояние фигурок в меню выбора
        private class VisualState
        {
            public int optionIndex;
            public GameObject visual;
            public Vector3 baseLocalPosition;
            public float targetScale;
            public float currentScale;
            public float floatOffsetTime;
            public Vector3 rotationAxis;
        }

        // Состояние фигурок, которые летают по орбите (выбранные заклинания)
        private class OrbitState
        {
            public GameObject visual;
            public float orbitAngle;
            public float floatOffsetTime;
            public Vector3 rotationAxis;
        }

        private List<VisualState> spawnedStates = new List<VisualState>();
        private List<OrbitState> orbitingStates = new List<OrbitState>();

        private struct CameraSpeedState
        {
            public CinemachineFreeLook camera;
            public float originalXSpeed;
            public float originalYSpeed;
        }

        private List<CameraSpeedState> activeCameraSpeeds = new List<CameraSpeedState>();
        private List<CinemachineFreeLookZoom> disabledZoomScripts = new List<CinemachineFreeLookZoom>();

        void Start()
        {
            // Подписываемся на событие каста палочки, чтобы удалять фигурки
            if (magicWeapon != null)
            {
                magicWeapon.OnCast += HandleWeaponCast;
            }
        }

        void OnDestroy()
        {
            if (magicWeapon != null)
            {
                magicWeapon.OnCast -= HandleWeaponCast;
            }
        }

        void OnDisable()
        {
            if (isSelecting)
            {
                EndSelection();
            }
        }

        void Update()
        {
            if (Input.GetMouseButtonDown(2))
            {
                StartSelection();
            }

            if (isSelecting)
            {
                HandleSelection();
            }

            if (Input.GetMouseButtonUp(2))
            {
                EndSelection();
            }

            AnimateVisuals();
            AnimateOrbitingVisuals();
        }

        private void StartSelection()
        {
            isSelecting = true;
            selectedIndex = 0;

            // Freeze all Cinemachine FreeLook cameras
            activeCameraSpeeds.Clear();
            CinemachineFreeLook[] freeLooks = FindObjectsOfType<CinemachineFreeLook>();
            foreach (var freeLook in freeLooks)
            {
                if (freeLook != null)
                {
                    activeCameraSpeeds.Add(new CameraSpeedState
                    {
                        camera = freeLook,
                        originalXSpeed = freeLook.m_XAxis.m_MaxSpeed,
                        originalYSpeed = freeLook.m_YAxis.m_MaxSpeed
                    });
                    
                    freeLook.m_XAxis.m_MaxSpeed = 0f;
                    freeLook.m_YAxis.m_MaxSpeed = 0f;
                }
            }

            // Disable camera zooming while selecting
            disabledZoomScripts.Clear();
            CinemachineFreeLookZoom[] zooms = FindObjectsOfType<CinemachineFreeLookZoom>();
            foreach (var zoom in zooms)
            {
                if (zoom != null && zoom.enabled)
                {
                    zoom.enabled = false;
                    disabledZoomScripts.Add(zoom);
                }
            }

            // Unlock and show cursor
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;

            Transform camTransform = Camera.main.transform;

            for (int i = 0; i < formOptions.Count; i++)
            {
                if (formOptions[i].visualPrefab == null) continue;

                float angle = i * Mathf.PI * 2 / formOptions.Count;
                Vector3 offset = new Vector3(Mathf.Cos(angle), Mathf.Sin(angle), 0) * radius;
                Vector3 spawnPos = camTransform.position + camTransform.forward * distanceFromCamera + camTransform.TransformDirection(offset);
                
                GameObject visual = Instantiate(formOptions[i].visualPrefab, spawnPos, camTransform.rotation);
                visual.transform.SetParent(camTransform, true);

                VisualState state = new VisualState
                {
                    optionIndex = i,
                    visual = visual,
                    baseLocalPosition = visual.transform.localPosition,
                    targetScale = i == selectedIndex ? scaleSelected : scaleNormal,
                    currentScale = 0f,
                    floatOffsetTime = Random.Range(0f, 100f),
                    rotationAxis = new Vector3(0, 1, 0)
                };
                
                visual.transform.localScale = Vector3.zero;
                spawnedStates.Add(state);
            }
        }

        private void HandleSelection()
        {
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (Mathf.Abs(scroll) > 0.01f)
            {
                if (scroll > 0)
                {
                    selectedIndex--;
                    if (selectedIndex < 0) selectedIndex = formOptions.Count - 1;
                }
                else
                {
                    selectedIndex++;
                    if (selectedIndex >= formOptions.Count) selectedIndex = 0;
                }
                UpdateTargetScales();
                return;
            }

            Vector2 screenCenter = new Vector2(Screen.width / 2f, Screen.height / 2f);
            Vector2 mouseDelta = (Vector2)Input.mousePosition - screenCenter;

            if (mouseDelta.magnitude > 30f && formOptions.Count > 0)
            {
                float angle = Mathf.Atan2(mouseDelta.y, mouseDelta.x) * Mathf.Rad2Deg;
                if (angle < 0) angle += 360f;

                float sectorSize = 360f / formOptions.Count;
                float shiftedAngle = (angle + sectorSize / 2f) % 360f;
                
                int newIndex = Mathf.FloorToInt(shiftedAngle / sectorSize);
                if (newIndex != selectedIndex)
                {
                    selectedIndex = newIndex;
                    UpdateTargetScales();
                }
            }
        }

        private void UpdateTargetScales()
        {
            for (int i = 0; i < spawnedStates.Count; i++)
            {
                if (spawnedStates[i].visual == null) continue;
                spawnedStates[i].targetScale = (spawnedStates[i].optionIndex == selectedIndex) ? scaleSelected : scaleNormal;
            }
        }

        private void AnimateVisuals()
        {
            float dt = Time.deltaTime;
            foreach (var state in spawnedStates)
            {
                if (state.visual == null) continue;

                state.currentScale = Mathf.Lerp(state.currentScale, state.targetScale, dt * animationSpeed);
                state.visual.transform.localScale = Vector3.one * state.currentScale;

                state.floatOffsetTime += dt * floatSpeed;
                float hoverY = Mathf.Sin(state.floatOffsetTime) * floatAmplitude;
                float extraZ = (state.targetScale == scaleSelected) ? -0.8f : 0f;

                Vector3 targetLocalPosition = state.baseLocalPosition + new Vector3(0, hoverY, extraZ);
                state.visual.transform.localPosition = Vector3.Lerp(state.visual.transform.localPosition, targetLocalPosition, dt * animationSpeed);

                state.visual.transform.Rotate(state.rotationAxis, rotationSpeed * dt, Space.Self);
            }
        }

        private void EndSelection()
        {
            isSelecting = false;

            // Restore all Cinemachine FreeLook camera speeds
            foreach (var state in activeCameraSpeeds)
            {
                if (state.camera != null)
                {
                    state.camera.m_XAxis.m_MaxSpeed = state.originalXSpeed;
                    state.camera.m_YAxis.m_MaxSpeed = state.originalYSpeed;
                }
            }
            activeCameraSpeeds.Clear();

            // Re-enable camera zooming
            foreach (var zoom in disabledZoomScripts)
            {
                if (zoom != null)
                {
                    zoom.enabled = true;
                }
            }
            disabledZoomScripts.Clear();

            // Lock and hide cursor
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
            
            if (formOptions.Count > 0 && selectedIndex >= 0 && selectedIndex < formOptions.Count)
            {
                Shape selectedShapePrefab = formOptions[selectedIndex].shapePrefab;
                if (selectedShapePrefab != null && magicWeapon != null)
                {
                    // Добавляем логику
                    Shape newShape = Instantiate(selectedShapePrefab, magicWeapon.transform);
                    magicWeapon.shapes.Add(newShape);
                    
                    // Находим визуальный объект выбранной формы, чтобы отправить его на орбиту
                    VisualState chosenState = spawnedStates.Find(s => s.optionIndex == selectedIndex);
                    if (chosenState != null && chosenState.visual != null)
                    {
                        spawnedStates.Remove(chosenState); // Убираем из списка на удаление
                        
                        OrbitState orbit = new OrbitState
                        {
                            visual = chosenState.visual,
                            orbitAngle = Random.Range(0f, 360f), // Запускаем с рандомного угла
                            floatOffsetTime = chosenState.floatOffsetTime,
                            rotationAxis = chosenState.rotationAxis
                        };
                        orbitingStates.Add(orbit);
                        
                        // Запускаем корутину, которая уменьшит его до маленького размера
                        StartCoroutine(ScaleToTarget(orbit.visual, orbitScale));
                    }
                }
            }

            // Плавное исчезновение и удаление ВСЕХ ОСТАЛЬНЫХ визуальных объектов
            foreach (var state in spawnedStates)
            {
                if (state.visual != null)
                {
                    StartCoroutine(ShrinkAndDestroy(state.visual));
                }
            }
            spawnedStates.Clear();
        }

        private void AnimateOrbitingVisuals()
        {
            if (orbitingStates.Count == 0) return;

            float dt = Time.deltaTime;
            Transform camTransform = Camera.main.transform;
            
            // Центр орбиты (немного ниже центра экрана, перед камерой)
            Vector3 orbitCenter = camTransform.position + camTransform.forward * (distanceFromCamera * 0.7f) + camTransform.up * -0.8f;

            for (int i = 0; i < orbitingStates.Count; i++)
            {
                var state = orbitingStates[i];
                if (state.visual == null) continue;

                // Для равномерного распределения фигурок по орбите:
                // Притягиваем их угол к идеальному равномерному углу
                float targetAngle = (i * 360f / orbitingStates.Count) + (Time.time * orbitRotationSpeed);
                state.orbitAngle = Mathf.LerpAngle(state.orbitAngle, targetAngle, dt * 5f);

                float rad = state.orbitAngle * Mathf.Deg2Rad;
                
                // Координаты на окружности
                Vector3 offset = new Vector3(Mathf.Cos(rad), 0, Mathf.Sin(rad)) * orbitRadius;
                
                // Левитация (отдельно для каждой фигурки)
                state.floatOffsetTime += dt * floatSpeed;
                float hoverY = Mathf.Sin(state.floatOffsetTime) * floatAmplitude;
                
                // Относительная позиция перед камерой
                Vector3 localOffset = new Vector3(offset.x, hoverY + offset.y, offset.z);
                Vector3 worldPos = orbitCenter + camTransform.TransformDirection(localOffset);
                
                // Плавное движение к нужной точке (чтобы при добавлении новой фигурки они плавно раздвигались)
                state.visual.transform.position = Vector3.Lerp(state.visual.transform.position, worldPos, dt * 8f);
                
                // Вращение вокруг своей оси
                state.visual.transform.Rotate(state.rotationAxis, rotationSpeed * dt, Space.Self);
            }
        }

        // Вызывается событием OnCast из MagicWeapon
        private void HandleWeaponCast()
        {
            foreach (var state in orbitingStates)
            {
                if (state.visual != null)
                {
                    StartCoroutine(ShrinkAndDestroy(state.visual));
                }
            }
            orbitingStates.Clear();
        }

        private IEnumerator ScaleToTarget(GameObject visual, float targetScaleFactor)
        {
            float t = 0f;
            Vector3 startScale = visual.transform.localScale;
            Vector3 targetScale = Vector3.one * targetScaleFactor;

            while (t < 1f)
            {
                if (visual == null) yield break;
                t += Time.deltaTime * animationSpeed * 0.5f; // Чуть медленнее
                visual.transform.localScale = Vector3.Lerp(startScale, targetScale, t);
                yield return null;
            }
        }

        private IEnumerator ShrinkAndDestroy(GameObject visual)
        {
            float t = 1f;
            Vector3 initialScale = visual.transform.localScale;
            while (t > 0)
            {
                t -= Time.deltaTime * animationSpeed;
                if (t < 0) t = 0;
                
                if (visual != null) 
                    visual.transform.localScale = initialScale * t;
                else 
                    break;
                    
                yield return null;
            }
            if (visual != null) Destroy(visual);
        }
    }
}
