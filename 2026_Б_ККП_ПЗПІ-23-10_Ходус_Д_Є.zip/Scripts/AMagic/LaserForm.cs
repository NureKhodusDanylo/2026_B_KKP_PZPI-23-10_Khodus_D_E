using Assets.Scripts.AMagic;
using System.Collections;
using UnityEngine;

public class LaserForm : Shape
{
    [Header("Base Logic")]
    [SerializeField] private float poolReturnDelay = 1f;

    [Header("Laser Modify Config")]
    [SerializeField] private LinearDistributionConfig laserModifyConfig = new LinearDistributionConfig
    {
        countMultiplier = 10f,
        minCount = 3,
        interval = 5f,
        cascadeDelay = 0.05f,
        scaleFactorMultiplier = 1f
    };
    [SerializeField] private float perpendicularAngle = 90f;

    [Header("Projectile Modify Config")]
    [SerializeField] private ProjectileLaunchConfig projectileLaunchConfig = new ProjectileLaunchConfig
    {
        force = 1500f,
        torqueStrength = 1f,
        scaleFactorMultiplier = 0.3f
    };
    [SerializeField] private SphereDistributionConfig projectileSphereConfig = new SphereDistributionConfig
    {
        countMultiplier = 6f,
        minCount = 3,
        radius = 0.5f,
        radiusScalesWithShape = true,
        scaleFactorMultiplier = 1f,
        useRandomRotation = true
    };

    [Header("Sphere Modify Config")]
    [SerializeField] private SphereDistributionConfig sphereModifyConfig = new SphereDistributionConfig
    {
        countMultiplier = 20f,
        minCount = 5,
        radius = 5f,
        scaleFactorMultiplier = 1f,
        useRandomRotation = false
    };

    [Header("Spray Modify Config")]
    [SerializeField] private FanDistributionConfig sprayModifyConfig = new FanDistributionConfig
    {
        countMultiplier = 12f,
        minCount = 4,
        startAngle = -45f,
        endAngle = 45f,
        distance = 0f,
        useSourcePosition = true,
        cascadeDelay = 0.05f,
        scaleFactorMultiplier = 0.3f
    };

    public override void BaseLogic()
    {
        BaseObject = PoolManager.Instanse.CreateObject(BaseObjectPref, Position, Rotation, ScaleFactor);
        if (Parent != null)
        {
            BaseObject.transform.SetParent(Parent.transform);
        }
        PoolManager.Instanse.ReturnObject(BaseObject, poolReturnDelay);
    }

    public override void LaserModify(Shape shape)
    {
        Parent = shape.Parent;
        Position = shape.Position;
        Rotation = shape.Rotation;
        ScaleFactor = shape.ScaleFactor;

        // Spawn center
        CoroutineRunner.Instance.RunCoroutine(CascadeSpawn(0, Position, Rotation));

        int count = SpawnDistribution.CalcCount(laserModifyConfig.countMultiplier, shape.ScaleFactor, laserModifyConfig.minCount);
        float interval = laserModifyConfig.interval;

        // Spawn pairs along the line with perpendicular rotations
        for (int i = 0; i < count; i++)
        {
            Position = shape.Position + (shape.Rotation * Vector3.forward) * interval * i;

            Rotation = shape.Rotation * Quaternion.Euler(0, perpendicularAngle, 0);
            CoroutineRunner.Instance.RunCoroutine(CascadeSpawn(laserModifyConfig.cascadeDelay * i, Position, Rotation));

            Rotation = shape.Rotation * Quaternion.Euler(0, -perpendicularAngle, 0);
            CoroutineRunner.Instance.RunCoroutine(CascadeSpawn(laserModifyConfig.cascadeDelay * i, Position, Rotation));
        }
    }

    public override void ProjectileModify(Shape shape)
    {
        GameObject projectileObject = LaunchProjectile(projectileLaunchConfig, shape);
        Parent = projectileObject;

        // Spawn sphere pattern around projectile
        SpawnInSpherePattern(projectileSphereConfig, shape, projectileObject);
    }

    public override void SphereModify(Shape shape)
    {
        SpawnInSpherePattern(sphereModifyConfig, shape);
    }

    public override void SprayModify(Shape shape)
    {
        SpawnInFanPattern(sprayModifyConfig, shape);
    }
}
