﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assets.Scripts.AMagic
{
    public interface IModifiable
    {
        public void SphereModify(Shape shape);
        public void LaserModify(Shape shape);
        public void ProjectileModify(Shape shape);
        public void SprayModify(Shape shape);
    }
}
