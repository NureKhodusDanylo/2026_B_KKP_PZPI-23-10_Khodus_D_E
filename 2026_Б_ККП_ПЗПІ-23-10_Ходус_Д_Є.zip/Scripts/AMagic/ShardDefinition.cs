using Assets.Scripts.AMagic;
using UnityEngine;

[CreateAssetMenu(fileName = "ShardDefinition", menuName = "MagicUniverse/Shard Definition")]
public class ShardDefinition : ScriptableObject
{
    [Header("Identity")]
    public ShardType shardType;
    public string displayName;

    [Header("Visuals")]
    public Sprite icon;
    [ColorUsage(false, true)]
    public Color glowColor = Color.cyan;
}
