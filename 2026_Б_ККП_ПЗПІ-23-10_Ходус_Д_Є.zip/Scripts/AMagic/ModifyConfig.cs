using System;
using UnityEngine;

namespace Assets.Scripts.AMagic
{
    [Serializable]
    public class SphereDistributionConfig
    {
        [Tooltip("Multiplier for spawn count (count = multiplier * scaleFactor)")]
        public float countMultiplier = 10f;

        [Tooltip("Minimum number of spawns")]
        public int minCount = 3;

        [Tooltip("Radius of the sphere distribution")]
        public float radius = 5f;

        [Tooltip("If true, radius is multiplied by source shape's scale factor")]
        public bool radiusScalesWithShape = false;

        [Tooltip("Scale factor multiplier applied to spawned shapes")]
        public float scaleFactorMultiplier = 1f;

        [Tooltip("Use random rotation offset for sphere distribution")]
        public bool useRandomRotation = true;
    }

    [Serializable]
    public class FanDistributionConfig
    {
        [Tooltip("Multiplier for spawn count (count = multiplier * scaleFactor)")]
        public float countMultiplier = 12f;

        [Tooltip("Minimum number of spawns")]
        public int minCount = 4;

        [Tooltip("Starting angle of the fan arc (degrees)")]
        public float startAngle = -90f;

        [Tooltip("Ending angle of the fan arc (degrees)")]
        public float endAngle = 90f;

        [Tooltip("Distance from center for spawned points")]
        public float distance = 15f;

        [Tooltip("Delay between cascade spawns")]
        public float cascadeDelay = 0.1f;

        [Tooltip("Scale factor multiplier applied to spawned shapes")]
        public float scaleFactorMultiplier = 1f;

        [Tooltip("Axis around which the fan rotates")]
        public Vector3 rotationAxis = Vector3.up;

        [Tooltip("If true, alternate spawn order (center outward) instead of sequential")]
        public bool alternateOrder = false;

        [Tooltip("If true, use the source shape position instead of calculated fan position")]
        public bool useSourcePosition = false;
    }

    [Serializable]
    public class ProjectileLaunchConfig
    {
        [Tooltip("Force applied to the projectile")]
        public float force = 1500f;

        [Tooltip("Torque strength for random spin")]
        public float torqueStrength = 1f;

        [Tooltip("Scale factor multiplier applied after projectile impact")]
        public float scaleFactorMultiplier = 0.3f;
    }

    [Serializable]
    public class LinearDistributionConfig
    {
        [Tooltip("Multiplier for spawn count (count = multiplier * scaleFactor)")]
        public float countMultiplier = 10f;

        [Tooltip("Minimum number of spawns")]
        public int minCount = 3;

        [Tooltip("Interval between spawns along the line")]
        public float interval = 5f;

        [Tooltip("If true, interval is multiplied by source shape's scale factor")]
        public bool intervalScalesWithShape = false;

        [Tooltip("Delay between cascade spawns")]
        public float cascadeDelay = 0.05f;

        [Tooltip("Scale factor multiplier applied to spawned shapes")]
        public float scaleFactorMultiplier = 1f;
    }
}
