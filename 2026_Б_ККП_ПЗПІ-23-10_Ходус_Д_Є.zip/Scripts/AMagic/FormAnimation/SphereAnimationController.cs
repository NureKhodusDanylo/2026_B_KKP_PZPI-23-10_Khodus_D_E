using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereAnimationController : MonoBehaviour
{
    public float Scale { get; protected set; }
    public float Duration { get; protected set; }
    public float FadeDuration { get; protected set; } = 0.5f;

    [SerializeField] private List<ParticleSystem> particles;
    [SerializeField] private GameObject shpere;


    public void SetUp(float scale, float duration)
    {
        Scale = scale;
        Duration = duration;
    }

    public void StartAnimate()
    {
        Renderer renderer = shpere.GetComponent<Renderer>();
        SetDefaultForMaterial(renderer);
        CoroutineRunner.Instance.StartCoroutine(Fade(renderer, Duration - FadeDuration));


        foreach (var p in particles)
        {
            p.Play();
            var main = p.main;
            main.scalingMode = ParticleSystemScalingMode.Hierarchy;
            //p.transform.localScale = new Vector3(Scale, Scale, Scale);
        }
    }

    private IEnumerator Fade(Renderer renderer, float delay)
    {
        if (renderer == null) yield break;

        yield return new WaitForSeconds(delay);

        float elapsedTime = 0f;
        float startPower = 1f;
        float endPower = 0f;

        var block = new MaterialPropertyBlock();

        while (elapsedTime < FadeDuration)
        {
            elapsedTime += Time.deltaTime;
            float currentPower = Mathf.Lerp(startPower, endPower, elapsedTime / FadeDuration);

            block.SetFloat("_power", currentPower);
            renderer.SetPropertyBlock(block);

            yield return null;
        }

        block.SetFloat("_power", endPower);
        renderer.SetPropertyBlock(block);
    }

    private void SetDefaultForMaterial(Renderer renderer)
    {
        var block = new MaterialPropertyBlock();
        block.SetFloat("_power", 1f);
        renderer.SetPropertyBlock(block);
    }

    void Start()
    {
        
    }
}
