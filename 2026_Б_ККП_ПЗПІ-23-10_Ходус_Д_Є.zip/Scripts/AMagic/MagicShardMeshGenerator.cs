using UnityEngine;

namespace Assets.Scripts.AMagic
{
    public static class MagicShardMeshGenerator
    {
        public static Mesh GenerateLaserMesh()
        {
            // Elongated double pointed prism (cylinder slice)
            Mesh mesh = new Mesh();
            mesh.name = "LaserShardMesh";

            Vector3[] vertices = new Vector3[]
            {
                new Vector3(0, 0.4f, 0), // 0: Top point
                new Vector3(0, -0.4f, 0), // 1: Bottom point

                // Mid ring 1 (Y = 0.15)
                new Vector3(-0.08f, 0.15f, -0.08f), // 2
                new Vector3(0.08f, 0.15f, -0.08f),  // 3
                new Vector3(0.12f, 0.15f, 0.05f),   // 4
                new Vector3(0f, 0.15f, 0.12f),      // 5
                new Vector3(-0.12f, 0.15f, 0.05f),  // 6

                // Mid ring 2 (Y = -0.15)
                new Vector3(-0.08f, -0.15f, -0.08f), // 7
                new Vector3(0.08f, -0.15f, -0.08f),  // 8
                new Vector3(0.12f, -0.15f, 0.05f),   // 9
                new Vector3(0f, -0.15f, 0.12f),      // 10
                new Vector3(-0.12f, -0.15f, 0.05f)   // 11
            };

            // Faces
            System.Collections.Generic.List<int> triangles = new System.Collections.Generic.List<int>();

            // Top pyramid faces
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                triangles.Add(0);
                triangles.Add(2 + next);
                triangles.Add(2 + i);
            }

            // Middle side faces (quads split into triangles)
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                int topCurr = 2 + i;
                int topNext = 2 + next;
                int botCurr = 7 + i;
                int botNext = 7 + next;

                // Triangle 1
                triangles.Add(topCurr);
                triangles.Add(topNext);
                triangles.Add(botCurr);

                // Triangle 2
                triangles.Add(topNext);
                triangles.Add(botNext);
                triangles.Add(botCurr);
            }

            // Bottom pyramid faces
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                triangles.Add(1);
                triangles.Add(7 + i);
                triangles.Add(7 + next);
            }

            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();

            return mesh;
        }

        public static Mesh GenerateProjectileMesh()
        {
            // Faceted gem-like sphere (dodecahedron segment)
            Mesh mesh = new Mesh();
            mesh.name = "ProjectileShardMesh";

            Vector3[] vertices = new Vector3[]
            {
                new Vector3(0, 0.25f, 0), // 0: Top
                new Vector3(0, -0.25f, 0), // 1: Bottom

                // Ring (Y = 0)
                new Vector3(-0.18f, 0, -0.18f), // 2
                new Vector3(0.18f, 0, -0.18f),  // 3
                new Vector3(0.22f, 0, 0.08f),   // 4
                new Vector3(0f, 0, 0.25f),      // 5
                new Vector3(-0.22f, 0, 0.08f)   // 6
            };

            System.Collections.Generic.List<int> triangles = new System.Collections.Generic.List<int>();

            // Top faces
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                triangles.Add(0);
                triangles.Add(2 + next);
                triangles.Add(2 + i);
            }

            // Bottom faces
            for (int i = 0; i < 5; i++)
            {
                int next = (i + 1) % 5;
                triangles.Add(1);
                triangles.Add(2 + i);
                triangles.Add(2 + next);
            }

            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();

            return mesh;
        }

        public static Mesh GenerateSprayMesh()
        {
            // Faceted cone fragment (pyramid)
            Mesh mesh = new Mesh();
            mesh.name = "SprayShardMesh";

            Vector3[] vertices = new Vector3[]
            {
                new Vector3(0, 0.35f, 0), // 0: Peak
                new Vector3(-0.15f, -0.15f, -0.15f), // 1: Base A
                new Vector3(0.15f, -0.15f, -0.15f),  // 2: Base B
                new Vector3(0f, -0.15f, 0.2f)        // 3: Base C
            };

            int[] triangles = new int[]
            {
                // Sides
                0, 2, 1,
                0, 3, 2,
                0, 1, 3,
                // Base
                1, 2, 3
            };

            mesh.vertices = vertices;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();

            return mesh;
        }

        public static Mesh GenerateSphereMesh()
        {
            // Curved shell / shield piece (extruded curved quad)
            Mesh mesh = new Mesh();
            mesh.name = "SphereShardMesh";

            Vector3[] vertices = new Vector3[]
            {
                // Front Curved face
                new Vector3(-0.15f, 0.15f, 0.05f),  // 0
                new Vector3(0.15f, 0.15f, 0.05f),   // 1
                new Vector3(0.2f, -0.15f, 0.12f),   // 2
                new Vector3(-0.2f, -0.15f, 0.12f),  // 3
                new Vector3(0f, 0f, 0.22f),         // 4: Center Peak

                // Back Curved face (extruded backward)
                new Vector3(-0.15f, 0.15f, -0.05f), // 5
                new Vector3(0.15f, 0.15f, -0.05f),  // 6
                new Vector3(0.2f, -0.15f, 0.02f),   // 7
                new Vector3(-0.2f, -0.15f, 0.02f),  // 8
                new Vector3(0f, 0f, 0.12f)          // 9: Back Center Peak
            };

            System.Collections.Generic.List<int> triangles = new System.Collections.Generic.List<int>();

            // Front face triangles (fan out from Center Peak 4)
            triangles.AddRange(new int[] { 4, 1, 0 });
            triangles.AddRange(new int[] { 4, 2, 1 });
            triangles.AddRange(new int[] { 4, 3, 2 });
            triangles.AddRange(new int[] { 4, 0, 3 });

            // Back face triangles (fan out from Center Peak 9, opposite winding)
            triangles.AddRange(new int[] { 9, 5, 6 });
            triangles.AddRange(new int[] { 9, 6, 7 });
            triangles.AddRange(new int[] { 9, 7, 8 });
            triangles.AddRange(new int[] { 9, 8, 5 });

            // Connection sides
            // Top Edge: 0 to 1 connecting to 5 and 6
            triangles.AddRange(new int[] { 0, 1, 5 });
            triangles.AddRange(new int[] { 1, 6, 5 });

            // Right Edge: 1 to 2 connecting to 6 and 7
            triangles.AddRange(new int[] { 1, 2, 6 });
            triangles.AddRange(new int[] { 2, 7, 6 });

            // Bottom Edge: 2 to 3 connecting to 7 and 8
            triangles.AddRange(new int[] { 2, 3, 7 });
            triangles.AddRange(new int[] { 3, 8, 7 });

            // Left Edge: 3 to 0 connecting to 8 and 5
            triangles.AddRange(new int[] { 3, 0, 8 });
            triangles.AddRange(new int[] { 0, 5, 8 });

            mesh.vertices = vertices;
            mesh.triangles = triangles.ToArray();
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();

            return mesh;
        }
    }
}
