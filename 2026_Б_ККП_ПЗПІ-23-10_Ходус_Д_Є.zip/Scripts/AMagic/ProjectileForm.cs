using Assets.Scripts.AMagic;
using System;
using System.Collections;
using UnityEngine;

public class ProjectileForm : Shape
{
    [Header("Base Logic")]
    [SerializeField] private float force = 1500f;
    [SerializeField] private float torqueStrength = 2f;

    [Header("Laser Modify Config")]
    [SerializeField] private LinearDistributionConfig laserModifyConfig = new LinearDistributionConfig
    {
        countMultiplier = 20f,
        minCount = 3,
        interval = 5f,
        intervalScalesWithShape = true,
        cascadeDelay = 0f,
        scaleFactorMultiplier = 1f
    };

    [Header("Projectile Modify Config")]
    [SerializeField] private float projectileModifyScaleMultiplier = 2f;

    [Header("Sphere Modify Config")]
    [SerializeField] private SphereDistributionConfig sphereModifyConfig = new SphereDistributionConfig
    {
        countMultiplier = 20f,
        minCount = 3,
        radius = 5f,
        radiusScalesWithShape = true,
        scaleFactorMultiplier = 1f,
        useRandomRotation = false
    };

    [Header("Spray Modify Config")]
    [SerializeField] private FanDistributionConfig sprayModifyConfig = new FanDistributionConfig
    {
        countMultiplier = 12f,
        minCount = 4,
        startAngle = -90f,
        endAngle = 90f,
        distance = 0f,
        useSourcePosition = true,
        cascadeDelay = 0.05f,
        scaleFactorMultiplier = 1f
    };
    [SerializeField] private int sprayRepeatCount = 3;

    public event Action OnDestroy;

    public override void BaseLogic()
    {
        BaseObject = PoolManager.Instanse.CreateObject(BaseObjectPref, Position, Rotation, ScaleFactor);
        Rigidbody rb = BaseObject.GetComponent<Rigidbody>();

        Vector3 direction = BaseObject.transform.forward;

        if (Parent != null)
        {
            direction = (Parent.transform.rotation * Vector3.forward);
        }

        rb.AddTorque(UnityEngine.Random.onUnitSphere * torqueStrength, ForceMode.Impulse);
        rb.AddForce(direction * force);
    }

    public override void LaserModify(Shape shape)
    {
        SpawnInLinePattern(laserModifyConfig, shape);
    }

    public override void ProjectileModify(Shape shape)
    {
        SimpleModify(shape, shape.ScaleFactor * projectileModifyScaleMultiplier);
    }

    public override void SphereModify(Shape shape)
    {
        SpawnInSpherePattern(sphereModifyConfig, shape);
    }

    public override void SprayModify(Shape shape)
    {
        for (int j = 0; j < sprayRepeatCount; j++)
        {
            SpawnInFanPattern(sprayModifyConfig, shape);
        }
    }
}