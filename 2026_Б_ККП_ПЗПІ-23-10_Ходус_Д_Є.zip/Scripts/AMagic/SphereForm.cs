using Assets.Scripts.AMagic;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SphereForm : Shape
{
    [Header("Base Logic")]
    [SerializeField] private Vector3 finalScale;
    [SerializeField] private float duration;

    [Header("Sphere Modify Config")]
    [SerializeField] private SphereDistributionConfig sphereModifyConfig = new SphereDistributionConfig
    {
        countMultiplier = 10f,
        minCount = 3,
        radius = 5f,
        scaleFactorMultiplier = 0.5f,
        useRandomRotation = true
    };

    [Header("Laser Modify Config")]
    [SerializeField] private float laserModifyScaleFactor = 3f;

    [Header("Projectile Modify Config")]
    [SerializeField] private ProjectileLaunchConfig projectileModifyConfig = new ProjectileLaunchConfig
    {
        force = 1500f,
        torqueStrength = 10f,
        scaleFactorMultiplier = 0.2f
    };

    [Header("Spray Modify Config")]
    [SerializeField] private FanDistributionConfig sprayModifyConfig = new FanDistributionConfig
    {
        countMultiplier = 12f,
        minCount = 4,
        startAngle = -90f,
        endAngle = 90f,
        distance = 15f,
        cascadeDelay = 0.1f,
        scaleFactorMultiplier = 0.8f,
        alternateOrder = true
    };

    private Shape previousShape;

    public override void BaseLogic()
    {
        float defaultScale = BaseObjectPref.transform.localScale.x;
        float scale = ScaleFactor > defaultScale ? defaultScale : ScaleFactor;

        BaseObject = PoolManager.Instanse.CreateObject(BaseObjectPref, Position, Rotation, scale);
        var anim = BaseObject.GetComponent<SphereAnimationController>();
        anim.SetUp(scale, duration);
        anim.StartAnimate();

        Grow grow = BaseObject.GetComponent<Grow>();
        CoroutineRunner.Instance.RunCoroutine(grow.StartGrow(finalScale * ScaleFactor, duration));
        PoolManager.Instanse.ReturnObject(BaseObject, duration);

        if (Parent != null)
        {
            BaseObject.transform.SetParent(Parent.transform);
        }
    }

    public override void LaserModify(Shape shape)
    {
        SimpleModify(shape, laserModifyScaleFactor);
    }

    public override void ProjectileModify(Shape shape)
    {
        previousShape = shape;

        GameObject projectileObject = LaunchProjectile(projectileModifyConfig, shape);

        FrictionSensor frictionSensor = projectileObject.GetComponent<FrictionSensor>();
        frictionSensor.OnDestroy += ActivationNextAfterProjectile;
    }

    public void ActivationNextAfterProjectile(GameObject _object)
    {
        FrictionSensor frictionSensor = _object.GetComponent<FrictionSensor>();
        frictionSensor.OnDestroy -= ActivationNextAfterProjectile;

        Position = _object.transform.position;
        Rotation = _object.transform.rotation;
        ScaleFactor = previousShape.ScaleFactor * projectileModifyConfig.scaleFactorMultiplier;
        ShapeLogic();
    }

    public override void SphereModify(Shape shape)
    {
        SpawnInSpherePattern(sphereModifyConfig, shape);
    }

    public override void SprayModify(Shape shape)
    {
        SpawnInFanPattern(sprayModifyConfig, shape);
    }
}
