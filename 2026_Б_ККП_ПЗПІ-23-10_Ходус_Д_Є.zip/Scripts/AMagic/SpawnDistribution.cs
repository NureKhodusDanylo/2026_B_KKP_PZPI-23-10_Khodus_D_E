using System.Collections.Generic;
using UnityEngine;

namespace Assets.Scripts.AMagic
{
    public struct SpawnPoint
    {
        public Vector3 Position;
        public Quaternion Rotation;

        public SpawnPoint(Vector3 position, Quaternion rotation)
        {
            Position = position;
            Rotation = rotation;
        }
    }

    public static class SpawnDistribution
    {
        /// <summary>
        /// Fibonacci sphere distribution — evenly distributes points on a sphere surface.
        /// </summary>
        public static List<SpawnPoint> FibonacciSphere(
            Vector3 center,
            int count,
            float radius,
            bool useRandomRotation = true,
            Quaternion? baseRotation = null)
        {
            var points = new List<SpawnPoint>(count);

            float offset = 2f / count;
            float goldenAngle = Mathf.PI * (3f - Mathf.Sqrt(5f));

            Quaternion rotOffset = useRandomRotation ? Random.rotationUniform : Quaternion.identity;
            if (baseRotation.HasValue)
                rotOffset = baseRotation.Value;

            for (int i = 0; i < count; i++)
            {
                float y = ((i * offset) - 1f) + (offset / 2f);
                float r = Mathf.Sqrt(1f - y * y);
                float phi = i * goldenAngle;
                float x = Mathf.Cos(phi) * r;
                float z = Mathf.Sin(phi) * r;

                Vector3 dir = new Vector3(x, y, z);
                dir = rotOffset * dir;
                Vector3 spawnPos = center + dir * radius;
                Quaternion rot = Quaternion.LookRotation(dir.normalized);

                points.Add(new SpawnPoint(spawnPos, rot));
            }

            return points;
        }

        /// <summary>
        /// Fan (arc) distribution — distributes points in a fan/spray pattern.
        /// </summary>
        public static List<SpawnPoint> Fan(
            Vector3 center,
            Quaternion baseRotation,
            int count,
            float startAngle,
            float endAngle,
            float distance,
            Vector3 rotationAxis,
            bool alternateOrder = false)
        {
            var points = new List<SpawnPoint>(count);

            float angleStep = (count > 1) ? (endAngle - startAngle) / (count - 1) : 0f;

            for (int i = 0; i < count; i++)
            {
                float currentAngle;
                if (alternateOrder)
                {
                    int offsetIdx = (i + 1) / 2;
                    currentAngle = (i % 2 == 0) ? offsetIdx * angleStep : -offsetIdx * angleStep;
                }
                else
                {
                    currentAngle = startAngle + i * angleStep;
                }

                Quaternion rotOffset = Quaternion.AngleAxis(currentAngle, rotationAxis);
                Quaternion finalRotation = baseRotation * rotOffset;

                Vector3 spawnPos = center + (finalRotation * Vector3.forward) * distance;

                points.Add(new SpawnPoint(spawnPos, finalRotation));
            }

            return points;
        }

        /// <summary>
        /// Linear distribution — distributes points along a forward direction.
        /// </summary>
        public static List<SpawnPoint> Linear(
            Vector3 origin,
            Quaternion rotation,
            int count,
            float interval)
        {
            var points = new List<SpawnPoint>(count);

            for (int i = 0; i < count; i++)
            {
                Vector3 pos = origin + (rotation * Vector3.forward) * interval * i;
                points.Add(new SpawnPoint(pos, rotation));
            }

            return points;
        }

        /// <summary>
        /// Calculate spawn count with scale factor and minimum.
        /// </summary>
        public static int CalcCount(float multiplier, float scaleFactor, int minCount)
        {
            int count = (int)(multiplier * scaleFactor);
            return Mathf.Max(count, minCount);
        }
    }
}
