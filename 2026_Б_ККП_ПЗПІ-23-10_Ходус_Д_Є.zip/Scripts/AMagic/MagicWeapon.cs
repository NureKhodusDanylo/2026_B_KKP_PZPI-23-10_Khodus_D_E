using System.Collections;
using System.Collections.Generic;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Assets.Scripts.AMagic {
    public class MagicWeapon : MonoBehaviour
    {
        private List<Element> elements = new List<Element>();

        public List<Shape> shapes;
        public List<Shape> shapes2;

        [Header("Cast Settings")]
        [SerializeField] private PlayerController playerController;
        [SerializeField] private float castTime = 1f;
        [SerializeField] private float castOffset = 0.5f;

        public event System.Action OnCast;

        public void SetPlayerController(PlayerController controller)
        {
            playerController = controller;
        }

        private void Awake()
        {
        }

        public void AddSpell(Element element)
        {
            elements.Add(element);
        }
        public void RemoveSpell(Element element)
        {
            elements.Remove(element);
        }

        public void Update()
        {
            if (Input.GetMouseButtonDown(1))
            {
                StartCast();
            }
        }

        public void StartCast()
        {
            StartCoroutine(CastRoutine());
        }

        private IEnumerator CastRoutine()
        {
            if (playerController != null) playerController.ToggleControl(true);
            
            OnCast?.Invoke();

            yield return new WaitForSeconds(castOffset);

            for (int i = 0; i < shapes.Count - 1; i++)
            {
                shapes[i].NextShape = shapes[i + 1];
            }
            
            if (shapes.Count > 0)
            {
                shapes[0].SetUpForFirst();
                shapes[0].ShapeLogic();
            }

            yield return new WaitForSeconds(castTime - castOffset);

            // Очищаем список заклинаний после каста.
            // Удаляем объекты с задержкой 5 секунд, чтобы корутины (CascadeSpawn) успели отработать.
            foreach (var shape in shapes)
            {
                if (shape != null) 
                {
                    Destroy(shape.gameObject, 5f);
                }
            }
            shapes.Clear();

            if (playerController != null) playerController.ToggleControl(false);
        }
    }

    public class Element
    {

    }
}
