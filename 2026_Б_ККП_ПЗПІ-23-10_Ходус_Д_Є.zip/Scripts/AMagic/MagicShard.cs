using System.Collections;
using UnityEngine;

// ShardType enum is defined in ShardType.cs (global namespace)
// to avoid circular reference between this namespace and ShardInventory.

namespace Assets.Scripts.AMagic
{
    [RequireComponent(typeof(MeshFilter), typeof(MeshRenderer))]
    public class MagicShard : MonoBehaviour
    {
        private enum ShardState { Spawning, Hovering, FlyingToPlayer }

        [Header("Shard Config")]
        [SerializeField] private ShardType shardType;
        [SerializeField] private ShardState state = ShardState.Spawning;

        [Header("Hover Animation")]
        [SerializeField] private float hoverAmplitude = 0.15f;
        [SerializeField] private float hoverFrequency = 2.5f;
        [SerializeField] private float rotateSpeed = 45f;

        [Header("Magnet Config")]
        [SerializeField] private float magnetRadius = 5f;
        [SerializeField] private float initialFlySpeed = 2f;
        [SerializeField] private float flyAcceleration = 18f;

        private MeshFilter meshFilter;
        private MeshRenderer meshRenderer;
        private Material shardMaterial;

        private Vector3 velocity;
        private float groundLevel;
        private Vector3 hoverCenter;
        private float hoverOffset;

        private GameObject playerTarget;
        private float currentFlySpeed;
        private bool isCollected = false;

        // ─── Initialize ────────────────────────────────────────────────────────

        public void Initialize(ShardType type, Vector3 startPos, float shardScale = 1f)
        {
            shardType = type;
            transform.position = startPos;
            transform.localScale = Vector3.one * shardScale;
            hoverOffset = Random.Range(0f, 100f);

            meshFilter = GetComponent<MeshFilter>();
            meshRenderer = GetComponent<MeshRenderer>();

            Mesh generatedMesh = null;
            switch (shardType)
            {
                case ShardType.Laser:      generatedMesh = MagicShardMeshGenerator.GenerateLaserMesh();      break;
                case ShardType.Projectile: generatedMesh = MagicShardMeshGenerator.GenerateProjectileMesh(); break;
                case ShardType.Spray:      generatedMesh = MagicShardMeshGenerator.GenerateSprayMesh();      break;
                case ShardType.Sphere:     generatedMesh = MagicShardMeshGenerator.GenerateSphereMesh();     break;
            }
            if (generatedMesh != null) meshFilter.sharedMesh = generatedMesh;

            Shader shardShader = Shader.Find("URP/Custom/MagicShardShader");
            if (shardShader != null)
            {
                shardMaterial = new Material(shardShader);
            }
            else
            {
                shardShader = Shader.Find("Universal Render Pipeline/Lit");
                shardMaterial = new Material(shardShader);
                shardMaterial.SetFloat("_Surface", 1);
                shardMaterial.EnableKeyword("_EMISSION");
            }

            Color glowColor = Color.cyan;
            switch (shardType)
            {
                case ShardType.Laser:      glowColor = new Color(0.0f, 0.9f, 1.0f); break;
                case ShardType.Projectile: glowColor = new Color(0.8f, 0.1f, 1.0f); break;
                case ShardType.Spray:      glowColor = new Color(1.0f, 0.4f, 0.0f); break;
                case ShardType.Sphere:     glowColor = new Color(1.0f, 0.0f, 0.5f); break;
            }

            if (shardShader.name == "URP/Custom/MagicShardShader")
                shardMaterial.SetColor("_GlowColor", glowColor);
            else
            {
                shardMaterial.SetColor("_Color", glowColor);
                shardMaterial.SetColor("_EmissionColor", glowColor * 2f);
            }

            meshRenderer.sharedMaterial = shardMaterial;

            float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
            float horizontalSpeed = Random.Range(1f, 2.5f);
            velocity = new Vector3(Mathf.Cos(angle) * horizontalSpeed, Random.Range(2.5f, 4.5f), Mathf.Sin(angle) * horizontalSpeed);

            RaycastHit hit;
            groundLevel = Physics.Raycast(startPos + Vector3.up * 0.5f, Vector3.down, out hit, 15f)
                ? hit.point.y
                : startPos.y - 0.8f;

            state = ShardState.Spawning;
        }

        // ─── Update ───────────────────────────────────────────────────────────

        private void Update()
        {
            if (isCollected) return;
            switch (state)
            {
                case ShardState.Spawning:       SimulateSpawningPhysics(); break;
                case ShardState.Hovering:       AnimateHovering(); CheckMagnetDistance(); break;
                case ShardState.FlyingToPlayer: FlyToPlayerTarget(); break;
            }
        }

        private void SimulateSpawningPhysics()
        {
            transform.position += velocity * Time.deltaTime;
            velocity.y -= 9.81f * Time.deltaTime;
            transform.Rotate(Vector3.up * 180f * Time.deltaTime + Vector3.forward * 90f * Time.deltaTime, Space.Self);

            if (transform.position.y <= groundLevel + 0.25f && velocity.y < 0)
            {
                transform.position = new Vector3(transform.position.x, groundLevel + 0.25f, transform.position.z);
                hoverCenter = transform.position + Vector3.up * 0.25f;
                state = ShardState.Hovering;
            }
        }

        private void AnimateHovering()
        {
            float floatY = hoverCenter.y + Mathf.Sin(Time.time * hoverFrequency + hoverOffset) * hoverAmplitude;
            transform.position = new Vector3(transform.position.x, floatY, transform.position.z);
            transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime, Space.Self);
        }

        private void CheckMagnetDistance()
        {
            if (playerTarget == null)
            {
                playerTarget = GameObject.Find("PL");
                if (playerTarget == null)
                {
                    var pc = FindObjectOfType<PlayerController>();
                    if (pc != null) playerTarget = pc.gameObject;
                }
            }

            if (playerTarget != null)
            {
                float distance = Vector3.Distance(transform.position, playerTarget.transform.position + Vector3.up * 0.5f);
                if (distance <= magnetRadius) { state = ShardState.FlyingToPlayer; currentFlySpeed = initialFlySpeed; }
            }
        }

        private void FlyToPlayerTarget()
        {
            if (playerTarget == null) { state = ShardState.Hovering; hoverCenter = transform.position; return; }

            Vector3 targetPos = playerTarget.transform.position + Vector3.up * 0.8f;
            transform.position = Vector3.MoveTowards(transform.position, targetPos, currentFlySpeed * Time.deltaTime);
            transform.Rotate(Vector3.up * rotateSpeed * 3f * Time.deltaTime + Vector3.right * rotateSpeed * Time.deltaTime, Space.Self);
            currentFlySpeed += flyAcceleration * Time.deltaTime;

            if (Vector3.Distance(transform.position, targetPos) < 0.4f)
                CollectShard();
        }

        // ─── Collect ──────────────────────────────────────────────────────────

        private void CollectShard()
        {
            isCollected = true;

            // Add to shard inventory
            if (ShardInventory.Instance != null)
                ShardInventory.Instance.Add(shardType);

            string typeColor = shardType switch
            {
                ShardType.Laser      => "#00E5FF",
                ShardType.Projectile => "#E040FB",
                ShardType.Spray      => "#FF6D00",
                ShardType.Sphere     => "#FF2F92",
                _ => "white"
            };
            Debug.Log($"<b><color={typeColor}>[Magic Shard Collected]</color></b> Player absorbed a <b>{shardType} Shard</b>!");

            StartCoroutine(ShrinkAndDestroyRoutine());
        }

        private IEnumerator ShrinkAndDestroyRoutine()
        {
            Vector3 startScale = transform.localScale;
            float duration = 0.2f, elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                transform.localScale = Vector3.Lerp(startScale, Vector3.zero, elapsed / duration);
                yield return null;
            }
            Destroy(gameObject);
        }

        private void OnDestroy()
        {
            if (shardMaterial != null) Destroy(shardMaterial);
        }
    }
}
