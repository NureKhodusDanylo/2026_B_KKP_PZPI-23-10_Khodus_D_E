﻿using System.Collections.Generic;
using UnityEngine;

public class StatusColor : MonoBehaviour, IInitializable
{
    [SerializeField, ColorUsage(true, true)]
    private Color color = Color.white;

    [SerializeField] private List<MaterialFactor> colorFactors;

    public void Init()
    {
        var block = new MaterialPropertyBlock();

        foreach (var mf in colorFactors)
        {
            if (mf == null || mf.renderer == null || mf.factors == null)
                continue;

            

            mf.renderer.GetPropertyBlock(block);

            foreach (var factor in mf.factors)
            {
                if (string.IsNullOrEmpty(factor.propertyName))
                    continue;

                Color baseColor = new Color(191f/255f, 12f/255f, 0f);
                float intensity = 2f;
                Material matInstance = mf.renderer.material;
                //baseColor.r += factor.value.x;
                //baseColor.g += factor.value.y;
                //baseColor.b += factor.value.z;


                Color emissionColor = baseColor * intensity;
                matInstance.SetColor(factor.propertyName, emissionColor);
                mf.renderer.material = matInstance;
                //block.SetColor(factor.propertyName, baseColor);
            }

            mf.renderer.SetPropertyBlock(block);
        }
    }
}
