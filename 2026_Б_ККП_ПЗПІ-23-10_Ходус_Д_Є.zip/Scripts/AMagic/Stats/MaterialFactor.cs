﻿using System;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class MaterialFactor
{
    public Renderer renderer; 
    public List<Factor> factors; 
}

[Serializable]
public class Factor
{
    public string propertyName;
    public Vector3 value;
}