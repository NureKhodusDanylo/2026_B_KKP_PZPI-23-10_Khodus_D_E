using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;

public class StatusEffect : IInitializable
{
    [SerializeField] private StatusColor effectColor;

    public void Init()
    {
        
    }
}
