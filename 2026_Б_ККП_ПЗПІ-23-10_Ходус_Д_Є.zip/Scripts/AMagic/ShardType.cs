/// <summary>
/// Standalone enum for magic shard types. Lives outside any namespace
/// so it can be referenced freely by both gameplay (Assets.Scripts.AMagic)
/// and inventory scripts (global namespace).
/// </summary>
public enum ShardType
{
    Laser,
    Projectile,
    Spray,
    Sphere
}
