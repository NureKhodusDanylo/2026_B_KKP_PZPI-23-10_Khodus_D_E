using System;
using System.Collections.Generic;
using Assets.Scripts.AMagic;
using UnityEngine;

/// <summary>
/// Creates one off-screen Camera + RenderTexture per ShardType.
/// Shard meshes are on the "ShardPreview" layer — invisible to the main camera.
/// Use GetTexture(type) to retrieve the live RenderTexture for a HUD slot.
/// </summary>
public class ShardPreviewSystem : MonoBehaviour
{
    public static ShardPreviewSystem Instance { get; private set; }

    [Header("Preview Settings")]
    [SerializeField] private int   textureSize    = 128;
    [SerializeField] private float rotationSpeed  = 30f;
    [SerializeField] private float previewScale   = 3.5f;

    private const string PREVIEW_LAYER = "ShardPreview";
    private int _layer;

    private readonly Dictionary<ShardType, RenderTexture> _textures = new();
    private readonly Dictionary<ShardType, Transform>     _pivots   = new();

    public RenderTexture GetTexture(ShardType type) =>
        _textures.TryGetValue(type, out var rt) ? rt : null;

    // ─── Init ──────────────────────────────────────────────────────────────────

    private void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        _layer = LayerMask.NameToLayer(PREVIEW_LAYER);
        if (_layer < 0)
        {
            Debug.LogError($"[ShardPreviewSystem] Layer '{PREVIEW_LAYER}' not found! " +
                           "Add it in Project Settings → Tags and Layers (slot 9).");
            enabled = false;
            return;
        }

        // Exclude preview layer from main camera
        if (Camera.main != null)
            Camera.main.cullingMask &= ~(1 << _layer);

        SpawnPreviews();
    }

    private void SpawnPreviews()
    {
        ShardType[] types = (ShardType[])Enum.GetValues(typeof(ShardType));

        for (int i = 0; i < types.Length; i++)
        {
            ShardType type = types[i];

            // Far from game world, spaced 30 units apart on X
            Vector3 origin = new Vector3(-8000f + i * 30f, 500f, 0f);

            // ── Shard mesh ─────────────────────────────────────────────────────
            GameObject shardGo = new GameObject($"ShardPreview_{type}");
            shardGo.layer = _layer;
            shardGo.transform.position   = origin;
            shardGo.transform.localScale = Vector3.one * previewScale;

            MeshFilter mf   = shardGo.AddComponent<MeshFilter>();
            MeshRenderer mr = shardGo.AddComponent<MeshRenderer>();
            mf.sharedMesh = GetMesh(type);

            Shader sh = Shader.Find("URP/Custom/MagicShardShader");
            if (sh == null) sh = Shader.Find("Universal Render Pipeline/Unlit");
            Material mat = new Material(sh);
            mat.SetColor("_GlowColor", GetColor(type));
            mr.sharedMaterial = mat;

            _pivots[type] = shardGo.transform;

            // ── RenderTexture ──────────────────────────────────────────────────
            var rt = new RenderTexture(textureSize, textureSize, 24, RenderTextureFormat.ARGB32);
            rt.antiAliasing = 4;
            rt.Create();
            _textures[type] = rt;

            // ── Preview Camera ─────────────────────────────────────────────────
            GameObject camGo = new GameObject($"ShardPreviewCam_{type}");
            Camera cam = camGo.AddComponent<Camera>();
            cam.transform.position = origin + new Vector3(0f, 0f, -10f);
            cam.transform.LookAt(origin);
            cam.cullingMask     = 1 << _layer;
            cam.clearFlags      = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0f, 0f, 0f, 0f);
            cam.targetTexture   = rt;
            cam.fieldOfView     = 40f;
            cam.nearClipPlane   = 0.1f;
            cam.farClipPlane    = 60f;
            cam.depth           = -5f;
            cam.allowHDR        = true;
            cam.allowMSAA       = true;
        }
    }

    // ─── Per-frame ─────────────────────────────────────────────────────────────

    private void Update()
    {
        float dt = Time.unscaledDeltaTime;
        foreach (var kv in _pivots)
            kv.Value.Rotate(
                Vector3.up    * rotationSpeed           * dt +
                Vector3.right * (rotationSpeed * 0.3f)  * dt,
                Space.Self);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    private static Mesh GetMesh(ShardType t) => t switch
    {
        ShardType.Laser      => MagicShardMeshGenerator.GenerateLaserMesh(),
        ShardType.Projectile => MagicShardMeshGenerator.GenerateProjectileMesh(),
        ShardType.Spray      => MagicShardMeshGenerator.GenerateSprayMesh(),
        ShardType.Sphere     => MagicShardMeshGenerator.GenerateSphereMesh(),
        _ => MagicShardMeshGenerator.GenerateLaserMesh()
    };

    private static Color GetColor(ShardType t) => t switch
    {
        ShardType.Laser      => new Color(0.0f, 0.9f, 1.0f),
        ShardType.Projectile => new Color(0.8f, 0.1f, 1.0f),
        ShardType.Spray      => new Color(1.0f, 0.4f, 0.0f),
        ShardType.Sphere     => new Color(1.0f, 0.0f, 0.5f),
        _ => Color.white
    };

    private void OnDestroy()
    {
        foreach (var rt in _textures.Values)
            if (rt != null) rt.Release();
    }
}
