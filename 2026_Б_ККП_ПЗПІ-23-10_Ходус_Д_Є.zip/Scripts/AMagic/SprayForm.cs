using Assets.Scripts.AMagic;
using System.Collections;
using UnityEngine;

public class SprayForm : Shape
{
    [Header("Laser Modify Config")]
    [SerializeField] private float laserModifyScaleFactor = 6f;

    [Header("Projectile Modify Config")]
    [SerializeField] private ProjectileLaunchConfig projectileLaunchConfig = new ProjectileLaunchConfig
    {
        force = 1500f,
        torqueStrength = 1f,
        scaleFactorMultiplier = 0.3f
    };
    [SerializeField] private SphereDistributionConfig projectileSphereConfig = new SphereDistributionConfig
    {
        countMultiplier = 6f,
        minCount = 2,
        radius = 0.5f,
        radiusScalesWithShape = true,
        scaleFactorMultiplier = 1f,
        useRandomRotation = false
    };

    [Header("Sphere Modify Config")]
    [SerializeField] private SphereDistributionConfig sphereModifyConfig = new SphereDistributionConfig
    {
        countMultiplier = 20f,
        minCount = 5,
        radius = 5f,
        scaleFactorMultiplier = 0.3f,
        useRandomRotation = false
    };

    [Header("Spray Modify Config")]
    [SerializeField] private FanDistributionConfig sprayModifyConfig = new FanDistributionConfig
    {
        countMultiplier = 12f,
        minCount = 4,
        startAngle = -90f,
        endAngle = 90f,
        distance = 0f,
        cascadeDelay = 0.1f,
        scaleFactorMultiplier = 1f
    };

    public override void BaseLogic()
    {
        BaseObject = PoolManager.Instanse.CreateObject(BaseObjectPref, Position, Rotation, ScaleFactor);
        if (Parent != null)
        {
            BaseObject.transform.SetParent(Parent.transform);
        }
    }

    public override void LaserModify(Shape shape)
    {
        SimpleModify(shape, laserModifyScaleFactor);
    }

    public override void ProjectileModify(Shape shape)
    {
        GameObject projectileObject = LaunchProjectile(projectileLaunchConfig, shape);
        Parent = projectileObject;

        // Spawn sphere pattern around projectile
        SpawnInSpherePattern(projectileSphereConfig, shape, projectileObject);
    }

    public override void SphereModify(Shape shape)
    {
        SpawnInSpherePattern(sphereModifyConfig, shape);
    }

    public override void SprayModify(Shape shape)
    {
        SpawnInFanPattern(sprayModifyConfig, shape);
    }
}