using UnityEngine;

public class TerrainNoise : MonoBehaviour, IInitializable
{
    public float scale = 0.1f;
    public float heightMultiplier = 10f;
    public int terrainWidth = 512;
    public int terrainHeight = 512;

    public Vector2 offsetRange = new Vector2(0f, 9999f);

    public static float GlobalXOffset;
    public static float GlobalYOffset;
    public static bool OffsetsInitialized = false;

    public void Init()
    {
        InitWithGridCoordinates(0, 0);
    }

    public void InitWithGridCoordinates(int chunkGridX, int chunkGridZ)
    {
        Terrain terrain = GetComponent<Terrain>();
        TerrainData terrainData = terrain.terrainData;

        int res = terrainData.heightmapResolution;
        float[,] heights = new float[res, res];

        if (!OffsetsInitialized)
        {
            GlobalXOffset = Random.Range(offsetRange.x, offsetRange.y);
            GlobalYOffset = Random.Range(offsetRange.x, offsetRange.y);
            OffsetsInitialized = true;
        }

        for (int x = 0; x < res; x++) // x represents rows (world Z index)
        {
            for (int y = 0; y < res; y++) // y represents columns (world X index)
            {
                // Global pixel coordinates calculated purely with integers to prevent float drift
                int globalX = chunkGridX * (res - 1) + y;
                int globalZ = chunkGridZ * (res - 1) + x;

                // Seamless coordinates mapping matching the original frequency/scale exactly
                float xCoord = GlobalXOffset + ((float)globalZ / terrainWidth) * scale;
                float yCoord = GlobalYOffset + ((float)globalX / terrainHeight) * scale;

                float noise = Mathf.PerlinNoise(xCoord, yCoord);
                heights[x, y] = noise * heightMultiplier / terrainData.size.y;
            }
        }

        terrainData.SetHeights(0, 0, heights);
    }
}
