//using UnityEngine;

//public class TerrainNoise_Dungeon : MonoBehaviour, IInitializable
//{
//    [Header("Base Settings")]
//    public float heightMultiplier = 50f;
//    public int terrainWidth = 512;
//    public int terrainHeight = 512;

//    [Header("Randomization Ranges (Min / Max)")]
//    [Tooltip("Начальный масштаб. Меньше - крупнее горы.")]
//    public Vector2 scaleRange = new Vector2(1f, 10f);
//    [Tooltip("Количество слоев шума.")]
//    public Vector2Int octavesRange = new Vector2Int(3, 7);
//    [Tooltip("Насколько сильно влияет каждый следующий мелкий слой (0-1).")]
//    public Vector2 persistenceRange = new Vector2(0.3f, 0.6f);
//    [Tooltip("Как быстро мельчают детали с каждым слоем (обычно > 1).")]
//    public Vector2 lacunarityRange = new Vector2(1.5f, 3f);
//    [Tooltip("Степень возведения. >1 делает долины плоскими, а горы резкими.")]
//    public Vector2 heightExponentRange = new Vector2(0.5f, 3f);

//    public void Init()
//    {
//        Terrain terrain = GetComponent<Terrain>();
//        TerrainData terrainData = terrain.terrainData;

//        // 1. Рандомизируем настройки для текущей генерации
//        float scale = Random.Range(scaleRange.x, scaleRange.y);
//        int octaves = Random.Range(octavesRange.x, octavesRange.y);
//        float persistence = Random.Range(persistenceRange.x, persistenceRange.y);
//        float lacunarity = Random.Range(lacunarityRange.x, lacunarityRange.y);
//        float heightExponent = Random.Range(heightExponentRange.x, heightExponentRange.y);

//        // Случайный шанс сгенерировать "острые" горы вместо обычных
//        bool isRidged = Random.value > 0.5f;

//        // Генерируем уникальные оффсеты для каждой октавы, чтобы слои не совпадали
//        Vector2[] octaveOffsets = new Vector2[octaves];
//        for (int i = 0; i < octaves; i++)
//        {
//            octaveOffsets[i] = new Vector2(Random.Range(-10000f, 10000f), Random.Range(-10000f, 10000f));
//        }

//        int res = terrainData.heightmapResolution;
//        float[,] heights = new float[res, res];

//        float minNoiseHeight = float.MaxValue;
//        float maxNoiseHeight = float.MinValue;

//        // 2. Генерация сырой карты высот
//        for (int x = 0; x < res; x++)
//        {
//            for (int y = 0; y < res; y++)
//            {
//                float amplitude = 1f;
//                float frequency = 1f;
//                float noiseHeight = 0f;

//                for (int i = 0; i < octaves; i++)
//                {
//                    float xCoord = (float)x / terrainWidth * scale * frequency + octaveOffsets[i].x;
//                    float yCoord = (float)y / terrainHeight * scale * frequency + octaveOffsets[i].y;

//                    // Получаем значение шума
//                    float perlinValue = Mathf.PerlinNoise(xCoord, yCoord);

//                    if (isRidged)
//                    {
//                        // Математика для острых горных хребтов
//                        perlinValue = 1f - Mathf.Abs(perlinValue * 2f - 1f);
//                        perlinValue *= perlinValue;
//                    }
//                    else
//                    {
//                        // Классический шум переводим в диапазон от -1 до 1
//                        perlinValue = perlinValue * 2f - 1f;
//                    }

//                    noiseHeight += perlinValue * amplitude;
//                    amplitude *= persistence;
//                    frequency *= lacunarity;
//                }

//                heights[x, y] = noiseHeight;

//                // Запоминаем мин и макс для нормализации
//                if (noiseHeight > maxNoiseHeight) maxNoiseHeight = noiseHeight;
//                if (noiseHeight < minNoiseHeight) minNoiseHeight = noiseHeight;
//            }
//        }

//        // 3. Нормализация и применение математики
//        for (int x = 0; x < res; x++)
//        {
//            for (int y = 0; y < res; y++)
//            {
//                // Приводим все высоты строго к диапазону от 0 до 1
//                float normalizedHeight = Mathf.InverseLerp(minNoiseHeight, maxNoiseHeight, heights[x, y]);

//                // Возводим в степень (формирует характер ландшафта)
//                normalizedHeight = Mathf.Pow(normalizedHeight, heightExponent);

//                // Применяем итоговую высоту в зависимости от настроек Terrain
//                heights[x, y] = normalizedHeight * heightMultiplier / terrainData.size.y;
//            }
//        }

//        terrainData.SetHeights(0, 0, heights);
//    }
//}
using UnityEngine;

public class TerrainNoise_Dungeon : MonoBehaviour, IInitializable
{
    [Header("Dimensions")]
    public float heightMultiplier = 40f;
    public int terrainWidth = 512;
    public int terrainHeight = 512;

    [Header("Castle Layout")]
    [Tooltip("Насколько стены будут кривыми и неровными. Если 0 - замок будет идеальным квадратом.")]
    public float distortionAmount = 0.15f;
    public float castleScale = 5f;
    public int castleLayers = 4;
    [Range(0f, 0.5f)]
    public float moatWidth = 0.15f;

    [Header("Architecture & Stairs (Стены и Лестницы)")]
    [Tooltip("Ширина ровного пола по отношению к перепаду высот (0.7 = 70% пол, 30% край).")]
    [Range(0.1f, 0.95f)]
    public float platformWidth = 0.8f;

    [Tooltip("Количество лестничных пролетов, отходящих от центра во все стороны.")]
    public int staircaseCount = 8;
    [Tooltip("Ширина самих лестниц (чем меньше, тем уже лестничные проемы).")]
    [Range(0.01f, 0.99f)]
    public float stairWidth = 0.15f;
    public int stairsPerRamp = 40;

    [Header("Ruins")]
    public float stoneRoughness = 0.001f;

    public void Init()
    {
        Terrain terrain = GetComponent<Terrain>();
        TerrainData terrainData = terrain.terrainData;
        int res = terrainData.heightmapResolution;
        float[,] heights = new float[res, res];

        float seedX = Random.Range(-5000f, 5000f);
        float seedY = Random.Range(-5000f, 5000f);

        for (int x = 0; x < res; x++)
        {
            for (int y = 0; y < res; y++)
            {
                // Нормализованные координаты (от 0 до 1)
                float nx = (float)x / (res - 1);
                float ny = (float)y / (res - 1);

                // Координаты относительно центра (от -0.5 до 0.5)
                float dx = nx - 0.5f;
                float dy = ny - 0.5f;

                // 1. БАЗОВАЯ ФОРМА (Зиккурат)
                // Расстояние Чебышева генерирует квадрат, который всегда идет вниз от центра к краям.
                // Это ГАРАНТИРУЕТ, что ям не будет — путь всегда ведет либо по кругу, либо вверх к центру.
                float squareDist = Mathf.Max(Mathf.Abs(dx), Mathf.Abs(dy)) * 2f;

                // Искажаем квадрат шумом, чтобы стены были похожи на старую кладку, а не на идеальную коробку
                float distortion = (Mathf.PerlinNoise(nx * castleScale + seedX, ny * castleScale + seedY) * 2f - 1f) * distortionAmount;
                float baseHeight = Mathf.Clamp01(1f - (squareDist + distortion));

                // 2. ВЫЧИСЛЕНИЕ ЯРУСОВ
                float scaledHeight = baseHeight * castleLayers;
                float currentLayer = Mathf.Floor(scaledHeight);
                float localHeight = scaledHeight - currentLayer;

                float finalLayerHeight = currentLayer;

                // 3. РАДИАЛЬНЫЕ ЛЕСТНИЦЫ
                if (localHeight > platformWidth)
                {
                    // Вычисляем угол текущей точки относительно центра (от -PI до PI)
                    float angle = Mathf.Atan2(dy, dx);

                    // Добавляем чуть-чуть шума к углу, чтобы лестницы шли не по идеальной прямой линейке
                    float angleNoise = Mathf.PerlinNoise(nx * 10f, ny * 10f) * 0.2f;

                    // Синусоида по кругу создает "лучи" от центра.
                    float stairMask = Mathf.Sin(angle * staircaseCount + angleNoise);

                    // Если мы попали в "луч", строим лестницу
                    if (stairMask > (1f - stairWidth))
                    {
                        float stairProgress = (localHeight - platformWidth) / (1f - platformWidth);
                        float stepOffset = Mathf.Floor(stairProgress * stairsPerRamp) / stairsPerRamp;
                        finalLayerHeight += stepOffset;
                    }
                    // Иначе — возводим наклонную, легко проходимую стену
                    else
                    {
                        // Плавный переход: высота увеличивается линейно по мере приближения к следующему этажу
                        float wallProgress = (localHeight - platformWidth) / (1f - platformWidth);
                        finalLayerHeight += wallProgress;
                    }
                }

                // 4. РОВ И КАМЕННАЯ КРОШКА
                if (squareDist > (1f - moatWidth))
                {
                    finalLayerHeight = 0f; // Край карты всегда опускается под воду/лаву
                }

                // Мелкие шероховатости на полах, не нарушающие общую геометрию
                float stoneNoise = Mathf.PerlinNoise(nx * 50f + seedX, ny * 50f + seedY) * stoneRoughness;

                float finalHeight = Mathf.Clamp01((finalLayerHeight / castleLayers) + stoneNoise);
                heights[x, y] = finalHeight * heightMultiplier / terrainData.size.y;
            }
        }

        terrainData.SetHeights(0, 0, heights);
    }
}