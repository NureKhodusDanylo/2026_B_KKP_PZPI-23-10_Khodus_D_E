using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PoolManager : MonoBehaviour
{
    public static PoolManager Instanse;

    // O(1) Performance: Using Stacks for instant retrieval.
    private Dictionary<GameObject, Stack<GameObject>> pools = new();
    
    // Reverse mapping: InstanceID -> Pool Stack for O(1) returns.
    private Dictionary<int, Stack<GameObject>> instanceToPool = new();

    // Garbage-Free Timers: Using a list/struct instead of Coroutines/new WaitForSeconds.
    private struct DelayedReturnItem
    {
        public GameObject obj;
        public float returnTime;
    }
    private List<DelayedReturnItem> delayedReturns = new List<DelayedReturnItem>(64);

    private void Awake()
    {
        if (Instanse == null)
            Instanse = this;
        else
            Destroy(gameObject);
    }

    private void Update()
    {
        // Process delayed returns without creating ANY garbage.
        if (delayedReturns.Count > 0)
        {
            float currentTime = Time.time;
            for (int i = delayedReturns.Count - 1; i >= 0; i--)
            {
                if (currentTime >= delayedReturns[i].returnTime)
                {
                    GameObject obj = delayedReturns[i].obj;
                    delayedReturns.RemoveAt(i);
                    ReturnObject(obj);
                }
            }
        }
    }

    public GameObject CreateObject(GameObject prefab, Vector3 position, Quaternion rotation, float scaleFactor = 1)
    {
        if (!pools.TryGetValue(prefab, out var stack))
        {
            stack = new Stack<GameObject>();
            pools[prefab] = stack;
        }

        GameObject obj = null;
        
        // O(1) Pop
        while (stack.Count > 0)
        {
            var potential = stack.Pop();
            if (potential != null)
            {
                obj = potential;
                break;
            }
        }

        if (obj == null)
        {
            obj = Instantiate(prefab);
            // Link this specific instance to this prefab's stack.
            instanceToPool[obj.GetInstanceID()] = stack;
        }

        if (obj.TryGetComponent<Rigidbody>(out Rigidbody rb))
        {
            rb.velocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        obj.transform.position = position;
        obj.transform.rotation = rotation;
        obj.transform.localScale = prefab.transform.localScale * scaleFactor;
        
        // Using activeSelf is faster than activeInHierarchy check.
        obj.SetActive(true);
        return obj;
    }

    public void ReturnObject(GameObject obj, bool leaveParent = false)
    {
        if (obj == null) return;

        if (leaveParent)
            obj.transform.SetParent(null);

        obj.SetActive(false);

        // Instant return using the mapping created at instantiation.
        if (instanceToPool.TryGetValue(obj.GetInstanceID(), out var stack))
        {
            stack.Push(obj);
        }
    }

    public void ReturnObject(GameObject obj, float delay)
    {
        if (obj == null) return;

        // Add to our specialized timer list instead of starting a Coroutine.
        delayedReturns.Add(new DelayedReturnItem { 
            obj = obj, 
            returnTime = Time.time + delay 
        });
    }
}
