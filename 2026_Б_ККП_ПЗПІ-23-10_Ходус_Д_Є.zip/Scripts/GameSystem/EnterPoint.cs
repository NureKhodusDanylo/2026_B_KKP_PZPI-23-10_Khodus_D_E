using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnterPoint : MonoBehaviour
{
    public List<Player> Players = new List<Player>();

    public List <MonoBehaviour> InitializableObjects = new List<MonoBehaviour>();

    private void Awake()
    {
        foreach (Player p in Players)
        {
            p.Init();
        }

        foreach (MonoBehaviour o in InitializableObjects)
        {
            if (o == null)
            {
                Debug.LogWarning("Found a null object reference in InitializableObjects list. Skipping.");
                continue;
            }

            if (o is IInitializable initializable)
            {
                initializable.Init();
            }
            else
            {
                Debug.LogWarning($"Object {o.name} does not implement IInitializable interface.");
            }
        }

        // Dynamically instantiate TerrainChunkManager for surface chunk terrain loading
        Terrain[] terrains = FindObjectsOfType<Terrain>();
        bool hasSurfaceTerrain = false;
        foreach (Terrain t in terrains)
        {
            if (t.GetComponent<TerrainNoise>() != null && t.transform.position.y > -500f)
            {
                hasSurfaceTerrain = true;
                break;
            }
        }

        if (hasSurfaceTerrain && FindObjectOfType<TerrainChunkManager>() == null)
        {
            GameObject managerObj = new GameObject("TerrainChunkManager");
            TerrainChunkManager manager = managerObj.AddComponent<TerrainChunkManager>();
            manager.Init();
        }
    }
}
