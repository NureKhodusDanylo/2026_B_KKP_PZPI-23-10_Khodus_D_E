using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IHaveState
{
    public State CurrentState { get; set; }

    protected abstract void GoToNextState();
}
public interface IInteractable
{
    public InteractMenuAnimManager interactMenuAnimManager { get; protected set; }
    public void Interact();
}
public interface IDamageable
{
    public float HP { get; }

    public void TakeDamage(float damage);
}

public interface ISpeedModifiable
{
    float Speed { get; }
    public void SetSpeed(float speed);
}

public interface IBlindable
{
    public void Blind(float seconds);
}

public interface ISusceptible : IDamageable, ISpeedModifiable, IBlindable
{

}

public interface IWeapon
{
    float Damage { get; }
    void Attack(IDamageable target = null);
}

public interface IRangeWeapon : IWeapon
{
    GameObject ProjectilePrefab { get; }
    Transform ShootPoint { get; set; }
}