# Enemy Combat Architecture Documentation

This document explains the core architecture of the enemy system in the project, detailing how logic, states, and physical components are connected. It also provides a step-by-step guide on how to integrate new enemy types (e.g., Ripper, Mage, Artillery) using the same pattern.

## Core Architecture Overview

The enemy behavior relies on a combination of Unity Components, State Machines, and Event-driven attack triggers. Checkers provide data on when to switch states, whilst the State Manager instantiates states and routes the logic.

### 1. The State Manager (`EnemyStateManager`)
This is the heart of the enemy logic. It inherits from `StateManager` and handles broad behaviors (Stay, Follow, Attack).
- Holds references to the `Rigidbody`, `Model`, `Target` (Player), and active state.
- Exposes Unity Events (`Run`, `Stay`, `AttackStart`, `AttackEnd`) that can be mapped to Animator parameters.
- Uses **ColliderChekers** (`followCheker`, `attackCheker`) to detect the player. Entering the `followCheker` transitions the enemy to `FollowState`. Entering the `attackCheker` pauses movement and transitions to `AttackState`.
- Implements an "Omni State" called `LookAtState` that ticks periodically to ensure the enemy constantly rotates towards the target.

### 2. Weapons (`Weapon.cs`, `MeleeWeapon.cs`, `RangeWeapon.cs`)
Weapons are components attached to the enemy model that define parameters: `Damage`, `Cooldown`, `Delay`, and `Duration`.
- **MeleeWeapon**: Uses another `ColliderCheker` (the Blade Hitbox). When `ActivateBlade()` is called by the state, the hitbox becomes active. If it hits an `IDamageable`, it applies damage.
- **RangeWeapon**: Holds a `Projectile` prefab. When `Attack()` is triggered, it instantiates the projectile at a defined `ShootPoint`.

### 3. Attack States (`AttackState.cs`)
`AttackState` serves as the abstract blueprint for attacking. It uses a Coroutine to continuously attack while the player is inside the `attackCheker`.
- The attack loop sequence is strictly defined by the weapon properties:
  1. Wait for `Delay`
  2. Invoke `StartAttack()` -> Triggers the Weapon
  3. Wait for `Duration`
  4. Invoke `StopAttack()` -> Disables the Weapon/Hitbox
  5. Wait for `Cooldown`

## Creating a New Enemy

To create a new enemy class (e.g., a "Ripper" that runs up and explodes, or a "Mage" that casts spells), follow these structured steps:

### Step 1: Create the Weapon Class
If the enemy deals damage in a new way, inherit from `Weapon`.
```csharp
public class RipperExplosionWeapon : Weapon
{
    [SerializeField] private float explosionRadius = 5f;
    [SerializeField] private GameObject explosionVFX;

    public override void Attack()
    {
        // 1. Play Explosion VFX
        // 2. Perform Physics.OverlapSphere to detect IDamageable targets
        // 3. Apply Damage
        // 4. Destroy the Ripper GameObject
    }
}
```

### Step 2: Create a Specific Attack State (Optional)
If your enemy's attack phase needs distinct logic during its `Delay` or `Duration` (like the `MeleeAttackState` turning a hitbox on and off), create a new state inheriting from `AttackState`.

```csharp
public class ChargeAttackState : AttackState
{
    private RipperExplosionWeapon explosionWeapon;

    public ChargeAttackState(State previousState, List<State> availableStates, RipperExplosionWeapon weapon) 
        : base(previousState, availableStates, weapon)
    {
        explosionWeapon = weapon;
    }

    protected override void StartAttack()
    {
        explosionWeapon.Attack();
    }
}
```

### Step 3: Create the Specific State Manager
Create a class inheriting from `EnemyStateManager` to piece it all together. Override `InitStates()` to initialize your specific Weapon and assign your specific Attack State.

```csharp
public class RipperStateManager : EnemyStateManager
{
    [SerializeField] private RipperExplosionWeapon explodeWeapon;

    protected override void InitStates()
    {
        followState = new FollowState(null, null, this);
        stayState = new StayState(null, null);
        
        // Pass the weapon to the custom attack state
        attackState = new ChargeAttackState(null, null, explodeWeapon);

        base.InitStates();
    }
}
```

### Step 4: Setup the Prefab Assembly
Constructing the new enemy logic in the Unity Editor based on existing templates (MeleeEnemy/RangeEnemy):

1. **Root GameObject**: Create the base GameObject (e.g., `RipperEnemy`). Attach the following components:
   - `RipperStateManager` (your newly created manager)
   - `Enemy` (base script)
   - `Rigidbody` (for physics)
   - `RipperAnimationController` (specific animator controller script for this enemy type, inheriting or implementing animator logic)

2. **Children Structure**: The standard enemy prefab has 5 main child objects:
   - **Model**: Contains the graphical representation (SkinnedMeshRenderer) and the Armature/Skeleton hierarchy.
   - **Collider**: Contains the `CapsuleCollider` for the enemy's physical boundary.
   - **GroundCheker**: Contains a `SphereCollider`, `MeshFilter`/`MeshRenderer` (optional), and the `GravityFixer` component.
   - **FollowCheker**: Contains a `SphereCollider` (isTrigger = true) and the `ColliderCheker` component.
   - **AttackCheker**: Contains a `SphereCollider` (isTrigger = true) and the `ColliderCheker` component.

3. **Setup Weapon**:
   - Add your `RipperExplosionWeapon` script somewhere on the prefab (e.g., an empty object within the Model's bone structure, or directly underneath the Model child).
   - Drag this Weapon into the `explodeWeapon` slot on the `RipperStateManager`.

4. **Link References in State Manager**:
   - `Transform` & `_transform`: Assign the root `RipperEnemy`.
   - `Model`: Assign the child `Model` transform.
   - `Rb`: Assign the root's `Rigidbody`.
   - `followCheker`: Assign the `ColliderCheker` script from the `FollowCheker` child.
   - `attackCheker`: Assign the `ColliderCheker` script from the `AttackCheker` child.

5. **Set Parameters**: Adjust the Weapon's `Damage`, `Delay`, `Duration`, and `Cooldown`, along with the State Manager's rotation speeds to define the feel of the enemy.

By following this pattern, you ensure all future enemies correctly hook into the state events, respect the omni states (like looking at the player), and maintain strict architectural consistency with existing entities like the `MeleeEnemy` and `RangeEnemy`.

## Common Errors & Best Practices

When creating new enemies or refactoring existing ones, keep the following gotchas in mind:

### 1. NullReferenceException in Animation Controllers
**The Problem**: After duplicating a prefab (e.g., `MeleeEnemy`) and swapping its `EnemyStateManager` with a new one (e.g., `RipperStateManager`), you may encounter a `NullReferenceException` at runtime in the Animation Controller's `Init()` method.
**The Cause**: The animation controller (e.g., `MeleeEnemyAnimationController`) has a serialized reference to the old state manager type. When the old manager is deleted, this reference becomes `null`. Additionally, hardcoded generic controllers may expect specific state manager implementations.
**The Fix**: 
- Create a specific Animation Controller script for your new enemy type (e.g., `RipperAnimationController`) that listens to the events exposed by `EnemyStateManager` (e.g., `AttackStart`, `Run`, `Stay`).
- Remove the old animation controller component from the prefab.
- Attach the new animation controller component.
- Re-assign the `Enemy State Manager` and `Animation Controller` (Animator) references in the inspector.

### 2. Violating Modular HitBox Architecture
**The Problem**: Writing `Physics.OverlapSphere` directly inside the `Weapon.cs` component (e.g., trying to hardcode an explosion radius directly in the script).
**The Cause**: It breaks the established modular architecture where hit detection is cleanly decoupled into an event-driven `ColliderCheker`. The base pattern uses a separate child GameObject containing a standard Unity Collider and a `ColliderCheker` script to detect `IDamageable` targets.
**The Fix**:
- Always create a separate child GameObject (e.g., `ExplosionHitBox`).
- Attach a primitive `Collider` (IsTrigger = true) to define the hit area.
- Attach the `ColliderCheker` component.
- Deactivate the child object by default in the hierarchy.
- In your Weapon script, hold references to both the `GameObject` and the `ColliderCheker`, and toggle `GameObject.SetActive(true)` only during the attack frame/duration.
