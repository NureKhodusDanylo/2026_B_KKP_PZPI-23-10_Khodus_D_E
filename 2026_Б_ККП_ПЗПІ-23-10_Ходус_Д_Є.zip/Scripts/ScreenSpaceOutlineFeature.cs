using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.Collections.Generic;

public class ScreenSpaceOutlineFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class OutlineSettings
    {
        public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRenderingTransparents;
        public Material outlineMaterial;
        
        [Range(0.0f, 10.0f)] public float outlineScale = 1.0f;
        public Color outlineColor = Color.black;
        
        [Range(0.0f, 100.0f)] public float depthThreshold = 1.5f;
        [Range(0.0f, 1.0f)] public float normalThreshold = 0.5f;
        
        [Header("Distance Fading")]
        public bool useDistanceFade = true;
        public float fadeStart = 20.0f;
        public float fadeEnd = 100.0f;

        [Header("Selective Outlining")]
        public bool useLayerMask = false;
        public LayerMask outlineLayerMask = -1;
        public bool debugShowMask = false;
        public bool pureSilhouette = false;
    }

    public OutlineSettings settings = new OutlineSettings();
    
    private OutlineMaskPass m_OutlineMaskPass;
    private OutlinePass m_OutlinePass;
    private Material m_MaskMaterial;

    public override void Create()
    {
        m_OutlineMaskPass = new OutlineMaskPass(settings);
        m_OutlinePass = new OutlinePass(settings, m_OutlineMaskPass);
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        if (settings.outlineMaterial == null)
        {
#if UNITY_EDITOR
            // Try auto-loading default outline material in the Editor
            settings.outlineMaterial = UnityEditor.AssetDatabase.LoadAssetAtPath<Material>("Assets/Shaders/ScreenSpaceOutline.mat");
#endif
            if (settings.outlineMaterial == null)
            {
                Debug.LogError("[ScreenSpaceOutlineFeature] settings.outlineMaterial is NULL!");
                return;
            }
        }

        // Lazy-create the mask material using the dedicated Hidden/OutlineMask shader
        if (m_MaskMaterial == null)
        {
#if UNITY_EDITOR
            // Try direct asset load in Editor first to be 100% reliable
            var maskShader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Assets/Shaders/OutlineMask.shader");
#else
            Shader maskShader = null;
#endif
            if (maskShader == null)
            {
                maskShader = Shader.Find("Hidden/OutlineMask");
            }

            if (maskShader != null)
            {
                m_MaskMaterial = CoreUtils.CreateEngineMaterial(maskShader);
                Debug.Log($"[ScreenSpaceOutlineFeature] m_MaskMaterial successfully created! Shader: {maskShader.name}");
            }
            else
            {
                Debug.LogError("[ScreenSpaceOutlineFeature] Failed to find OutlineMask shader!");
            }
        }

        m_OutlineMaskPass.SetMaskMaterial(m_MaskMaterial);

        // Configure input - ensure depth input is requested for both passes so depth-testing is guaranteed to work
        m_OutlineMaskPass.ConfigureInput(ScriptableRenderPassInput.Depth);
        m_OutlinePass.ConfigureInput(ScriptableRenderPassInput.Color | ScriptableRenderPassInput.Depth | ScriptableRenderPassInput.Normal);

        if (settings.useLayerMask && m_MaskMaterial != null)
        {
            renderer.EnqueuePass(m_OutlineMaskPass);
        }
        renderer.EnqueuePass(m_OutlinePass);
    }

    protected override void Dispose(bool disposing)
    {
        m_OutlineMaskPass?.Dispose();
        m_OutlinePass?.Dispose();
        
        if (m_MaskMaterial != null)
        {
            CoreUtils.Destroy(m_MaskMaterial);
            m_MaskMaterial = null;
        }
    }

    // 1. Pass to render selected layers as solid white mask into _OutlineMask texture
    class OutlineMaskPass : ScriptableRenderPass
    {
        private OutlineSettings settings;
        private RTHandle m_MaskTexture;
        private Material m_MaskMaterial;
        private FilteringSettings m_FilteringSettings;

        public OutlineMaskPass(OutlineSettings settings)
        {
            this.settings = settings;
            this.renderPassEvent = settings.renderPassEvent;
        }

        public void SetMaskMaterial(Material mat)
        {
            m_MaskMaterial = mat;
        }

        public RTHandle GetMaskTexture()
        {
            return m_MaskTexture;
        }

        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            RenderTextureDescriptor desc = renderingData.cameraData.cameraTargetDescriptor;
            desc.colorFormat = RenderTextureFormat.R8; // Single channel 8-bit texture is high-performance and sufficient
            desc.depthBufferBits = 0; // No depth buffer needed (we use manual depth testing in fragment shader)
            
            RenderingUtils.ReAllocateIfNeeded(ref m_MaskTexture, desc, name: "_OutlineMask");
            
            if (m_MaskTexture != null)
            {
                ConfigureTarget(m_MaskTexture);
                ConfigureClear(ClearFlag.Color, Color.clear);
            }
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (m_MaskMaterial == null)
            {
                Debug.LogError("[OutlineMaskPass] m_MaskMaterial is NULL!");
                return;
            }
            if (m_MaskTexture == null)
            {
                Debug.LogError("[OutlineMaskPass] m_MaskTexture is NULL!");
                return;
            }

            CommandBuffer cmd = CommandBufferPool.Get("Outline Mask Pass");
            
            // Explicitly set the render target using CoreUtils to be 100% sure URP binds it.
            CoreUtils.SetRenderTarget(cmd, m_MaskTexture);
            
            // Clear only the color buffer of the mask texture to black (clear) before rendering
            CoreUtils.ClearRenderTarget(cmd, ClearFlag.Color, Color.clear);
            
            // Execute target binding and clear commands immediately
            context.ExecuteCommandBuffer(cmd);
            cmd.Clear();
            
            // Set up sorting and drawing settings using URP-compatible single ShaderTagId method chain
            var sortingCriteria = renderingData.cameraData.defaultOpaqueSortFlags;
            var drawingSettings = CreateDrawingSettings(new ShaderTagId("UniversalForward"), ref renderingData, sortingCriteria);
            drawingSettings.SetShaderPassName(1, new ShaderTagId("UniversalForwardOnly"));
            drawingSettings.SetShaderPassName(2, new ShaderTagId("LightweightForward"));
            drawingSettings.SetShaderPassName(3, new ShaderTagId("SRPDefaultUnlit"));
            
            // Use our dedicated unlit white override material
            drawingSettings.overrideMaterial = m_MaskMaterial;
            drawingSettings.overrideMaterialPassIndex = 0;

            // Set up layer filtering (matches all queues for safety)
            m_FilteringSettings = new FilteringSettings(RenderQueueRange.all, settings.outlineLayerMask);

            // Draw the renderers matching the layer mask into the active target
            context.DrawRenderers(renderingData.cullResults, ref drawingSettings, ref m_FilteringSettings);

            // Submit empty cmd (or any remaining commands)
            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }

        public void Dispose()
        {
            m_MaskTexture?.Release();
        }
    }

    // 2. Main outline blit pass
    class OutlinePass : ScriptableRenderPass
    {
        private OutlineSettings settings;
        private OutlineMaskPass m_OutlineMaskPass;
        private RTHandle m_ColorBuffer;
        private RTHandle m_TemporaryColorBuffer;

        public OutlinePass(OutlineSettings settings, OutlineMaskPass maskPass)
        {
            this.settings = settings;
            this.m_OutlineMaskPass = maskPass;
            this.renderPassEvent = settings.renderPassEvent;
        }

        public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
        {
            m_ColorBuffer = renderingData.cameraData.renderer.cameraColorTargetHandle;
            if (m_ColorBuffer != null)
            {
                ConfigureTarget(m_ColorBuffer); // Explicitly ensure camera color target is bound as the active target
            }
            
            RenderTextureDescriptor desc = renderingData.cameraData.cameraTargetDescriptor;
            desc.depthBufferBits = 0; // No depth buffer needed for color target copy
            
            RenderingUtils.ReAllocateIfNeeded(ref m_TemporaryColorBuffer, desc, name: "_ScreenSpaceOutlineTemporaryColor");
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (settings.outlineMaterial == null) return;
            if (m_ColorBuffer == null || m_TemporaryColorBuffer == null) return;

            CommandBuffer cmd = CommandBufferPool.Get("Screen Space Outline");
            
            // Set material properties
            settings.outlineMaterial.SetFloat("_OutlineScale", settings.outlineScale);
            settings.outlineMaterial.SetColor("_OutlineColor", settings.outlineColor);
            settings.outlineMaterial.SetFloat("_DepthThreshold", settings.depthThreshold);
            settings.outlineMaterial.SetFloat("_NormalThreshold", settings.normalThreshold);
            settings.outlineMaterial.SetFloat("_UseDistanceFade", settings.useDistanceFade ? 1.0f : 0.0f);
            settings.outlineMaterial.SetFloat("_FadeStart", settings.fadeStart);
            settings.outlineMaterial.SetFloat("_FadeEnd", settings.fadeEnd);
            settings.outlineMaterial.SetFloat("_UseLayerMask", settings.useLayerMask ? 1.0f : 0.0f);
            settings.outlineMaterial.SetFloat("_DebugShowMask", (settings.debugShowMask && settings.useLayerMask) ? 1.0f : 0.0f);
            settings.outlineMaterial.SetFloat("_PureSilhouette", (settings.pureSilhouette && settings.useLayerMask) ? 1.0f : 0.0f);

            // Bind the mask texture directly to the material and globally via CommandBuffer if Layer Mask mode is enabled
            if (settings.useLayerMask && m_OutlineMaskPass != null)
            {
                var maskTex = m_OutlineMaskPass.GetMaskTexture();
                if (maskTex != null)
                {
                    settings.outlineMaterial.SetTexture("_OutlineMask", maskTex.rt);
                    cmd.SetGlobalTexture("_OutlineMask", maskTex);
                }
            }
            
            cmd.SetGlobalFloat("_UseLayerMask", settings.useLayerMask ? 1.0f : 0.0f);
            cmd.SetGlobalFloat("_DebugShowMask", (settings.debugShowMask && settings.useLayerMask) ? 1.0f : 0.0f);
            cmd.SetGlobalFloat("_PureSilhouette", (settings.pureSilhouette && settings.useLayerMask) ? 1.0f : 0.0f);

            // Double-buffer blit to avoid feedback loop:
            // 1. Blit camera color target into temporary buffer with our outline material
            Blitter.BlitCameraTexture(cmd, m_ColorBuffer, m_TemporaryColorBuffer, settings.outlineMaterial, 0);

            // 2. Blit temporary buffer back into camera color target (standard copy blit)
            Blitter.BlitCameraTexture(cmd, m_TemporaryColorBuffer, m_ColorBuffer);

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }

        public void Dispose()
        {
            m_TemporaryColorBuffer?.Release();
        }
    }
}
