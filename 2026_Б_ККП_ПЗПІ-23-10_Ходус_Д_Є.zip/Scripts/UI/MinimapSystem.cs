using UnityEngine;
using UnityEngine.UI;

public class MinimapSystem : MonoBehaviour
{
    public static MinimapSystem Instance { get; private set; }

    [Header("Settings")]
    public Transform playerTransform;
    public float worldSize = 250f; // Total world units covered by the map

    [Header("Palette Settings")]
    public float ringDensity = 0.1f;
    public float speed = 1.0f;
    [Tooltip("If checked, will try to sync settings from the world generator automatically")]
    public bool syncWithWorldGenerator = true;

    [Header("UI References")]
    public RectTransform mapContainer;
    public Image backgroundImage;
    public GameObject playerMarkerPrefab;
    public GameObject enemyMarkerPrefab;

    private Material _bgMaterial;
    private GenerateEnvironmental _worldGen;
    
    // Shader property IDs
    private static readonly int PlayerPosID = Shader.PropertyToID("_PlayerPos");
    private static readonly int WorldSizeID = Shader.PropertyToID("_WorldSize");
    private static readonly int TimeOffsetID = Shader.PropertyToID("_TimeOffset");
    private static readonly int RingDensityID = Shader.PropertyToID("_RingDensity");
    private static readonly int SpeedID = Shader.PropertyToID("_Speed");

    void Awake()
    {
        Instance = this;
        
        if (backgroundImage != null)
        {
            _bgMaterial = backgroundImage.material;
            if (_bgMaterial != null)
            {
                _bgMaterial.SetFloat(WorldSizeID, worldSize);
                _bgMaterial.SetFloat(RingDensityID, ringDensity);
                _bgMaterial.SetFloat(SpeedID, speed);
            }
        }
        
        if (syncWithWorldGenerator)
        {
            _worldGen = Object.FindAnyObjectByType<GenerateEnvironmental>();
            if (_worldGen != null)
            {
                ringDensity = _worldGen.ringDensity;
                speed = _worldGen.speed;
                if (_bgMaterial != null)
                {
                    _bgMaterial.SetFloat(RingDensityID, ringDensity);
                    _bgMaterial.SetFloat(SpeedID, speed);
                }
            }
        }
    }

    void Start()
    {
        if (playerTransform == null)
            playerTransform = GameObject.FindGameObjectWithTag("Player")?.transform;
            
        // Markers will register themselves via MinimapMarker component
    }

    void LateUpdate()
    {
        if (playerTransform == null) return;

        Vector3 pPos = playerTransform.position;

        // 1. Update Shader Background
        if (_bgMaterial != null)
        {
            _bgMaterial.SetVector(PlayerPosID, new Vector4(pPos.x, pPos.y, pPos.z, 0));
            
            // Sync time with world generator or use system time
            float currentTime = _worldGen != null ? _worldGen.time : Time.time;
            _bgMaterial.SetFloat(TimeOffsetID, currentTime); 
        }
    }

    public Vector2 WorldToMapPos(Vector3 targetWorldPos)
    {
        if (playerTransform == null) return Vector2.zero;

        Vector3 diff = targetWorldPos - playerTransform.position;
        float mapSizePixels = mapContainer.rect.width;
        
        float x = (diff.x / worldSize) * mapSizePixels;
        float y = (diff.z / worldSize) * mapSizePixels;

        return new Vector2(x, y);
    }
}
