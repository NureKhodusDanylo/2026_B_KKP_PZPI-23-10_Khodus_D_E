using UnityEngine;

[ExecuteAlways]
public class MinimapFollow : MonoBehaviour
{
    public Transform target;
    public float height = 50f;

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 newPos = target.position;
        newPos.y = height;
        transform.position = newPos;
        
        // Keep rotation looking down
        transform.rotation = Quaternion.Euler(90f, 0f, 0f);
    }
}
