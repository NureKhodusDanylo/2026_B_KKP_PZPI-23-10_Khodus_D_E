using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// A single HUD slot that shows a live rotating 3D shard preview (via RenderTexture)
/// and a count badge. Reacts to ShardInventory.OnChanged with a pop animation.
/// </summary>
[RequireComponent(typeof(CanvasGroup))]
public class ShardHUDSlot : MonoBehaviour
{
    [Header("Shard")]
    public ShardDefinition definition;

    [Header("UI References")]
    [SerializeField] private RawImage        previewImage;
    [SerializeField] private Image           backgroundImage;
    [SerializeField] private Image           glowRingImage;
    [SerializeField] private TextMeshProUGUI countText;

    private CanvasGroup _cg;
    private bool _textureAssigned;
    private Vector3 _baseScale;

    // ─── Unity ─────────────────────────────────────────────────────────────────

    private void Awake() => _cg = GetComponent<CanvasGroup>();

    private void Start()
    {
        _baseScale = transform.localScale;
        ApplyColors();
        TryAssignTexture();
        Refresh(ShardInventory.Instance != null ? ShardInventory.Instance.Get(definition.shardType) : 0);

        if (ShardInventory.Instance != null)
            ShardInventory.Instance.OnChanged += HandleChanged;
    }

    private void Update()
    {
        if (!_textureAssigned) TryAssignTexture();
    }

    private void OnDestroy()
    {
        if (ShardInventory.Instance != null)
            ShardInventory.Instance.OnChanged -= HandleChanged;
    }

    // ─── Logic ─────────────────────────────────────────────────────────────────

    private void TryAssignTexture()
    {
        if (ShardPreviewSystem.Instance == null || definition == null) return;
        RenderTexture rt = ShardPreviewSystem.Instance.GetTexture(definition.shardType);
        if (rt == null) return;
        if (previewImage != null) previewImage.texture = rt;
        _textureAssigned = true;
    }

    private void HandleChanged(ShardType type, int newCount)
    {
        if (type == definition.shardType) Refresh(newCount);
    }

    private void Refresh(int count)
    {
        if (countText != null) countText.text = count.ToString();
        _cg.alpha = count > 0 ? 1f : 0.45f;
        StopAllCoroutines();
        if (count > 0) StartCoroutine(PopRoutine());
    }

    private void ApplyColors()
    {
        if (definition == null) return;

        if (backgroundImage != null)
        {
            Color bg = definition.glowColor * 0.18f;
            bg.a = 0.85f;
            backgroundImage.color = bg;
        }

        if (glowRingImage != null)
        {
            Color ring = definition.glowColor;
            ring.a = 0.55f;
            glowRingImage.color = ring;
        }

        if (countText != null)
            countText.color = definition.glowColor;
    }

    private IEnumerator PopRoutine()
    {
        Vector3 orig = _baseScale;
        Vector3 big  = orig * 1.28f;
        float half = 0.1f, t = 0f;
        while (t < half) { t += Time.unscaledDeltaTime; transform.localScale = Vector3.Lerp(orig, big, t / half); yield return null; }
        t = 0f;
        while (t < half) { t += Time.unscaledDeltaTime; transform.localScale = Vector3.Lerp(big, orig, t / half); yield return null; }
        transform.localScale = orig;
    }
}
