using UnityEngine;
using UnityEngine.UI;

[ExecuteAlways]
public class MinimapController : MonoBehaviour
{
    public RawImage displayImage;
    public int resolution = 256;
    
    private RenderTexture _rt;

    void OnEnable()
    {
        Setup();
    }

    void Update()
    {
        if (_rt == null || !_rt.IsCreated()) Setup();
    }

    private void Setup()
    {
        if (displayImage == null)
        {
            GameObject go = GameObject.Find("MapImage");
            if (go != null) displayImage = go.GetComponent<RawImage>();
        }

        if (displayImage != null)
        {
            if (_rt != null) _rt.Release();
            _rt = new RenderTexture(resolution, resolution, 16, RenderTextureFormat.ARGB32);
            _rt.Create();
            
            Camera cam = GetComponent<Camera>();
            if (cam != null) cam.targetTexture = _rt;
            
            displayImage.texture = _rt;
        }
    }

    void OnDisable()
    {
        if (_rt != null)
        {
            _rt.Release();
            if (Application.isPlaying) Destroy(_rt);
            else DestroyImmediate(_rt);
        }
    }
}
