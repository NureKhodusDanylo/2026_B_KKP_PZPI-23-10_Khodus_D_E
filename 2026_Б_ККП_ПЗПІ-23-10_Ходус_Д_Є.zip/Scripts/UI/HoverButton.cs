using UnityEngine;
using UnityEngine.EventSystems; // Обязательно для работы с мышью
using UnityEngine.UI; // Обязательно для работы с картинками и UI
using System.Collections;

// Добавляем интерфейсы IPointerEnterHandler и IPointerExitHandler, чтобы Unity понимал, что мы следим за мышкой
public class ButtonGlow : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Настройки свечения")]
    [Tooltip("Перетащи сюда картинку свечения из иерархии")]
    public Image glowImage;

    [Tooltip("Скорость появления и затухания свечения")]
    public float fadeSpeed = 5f;

    private Coroutine fadeCoroutine;

    // Этот метод Unity вызывает автоматически, когда курсор НАВОДИТСЯ на кнопку
    public void OnPointerEnter(PointerEventData eventData)
    {
        if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
        // Запускаем плавное появление (целевая прозрачность 1 - полностью видно)
        fadeCoroutine = StartCoroutine(FadeGlow(1f));
    }

    // Этот метод Unity вызывает автоматически, когда курсор УХОДИТ с кнопки
    public void OnPointerExit(PointerEventData eventData)
    {
        if (fadeCoroutine != null) StopCoroutine(fadeCoroutine);
        // Запускаем плавное затухание (целевая прозрачность 0 - невидимо)
        fadeCoroutine = StartCoroutine(FadeGlow(0f));
    }

    // Это "корутина" — специальная функция, которая растягивает действие во времени (для плавности)
    private IEnumerator FadeGlow(float targetAlpha)
    {
        if (glowImage == null) yield break; // Защита от ошибки, если картинку забыли привязать

        Color currentColor = glowImage.color;

        // Пока текущая прозрачность не станет равна нужной...
        while (!Mathf.Approximately(currentColor.a, targetAlpha))
        {
            // ...плавно меняем значение прозрачности
            currentColor.a = Mathf.MoveTowards(currentColor.a, targetAlpha, fadeSpeed * Time.deltaTime);
            glowImage.color = currentColor;

            // Ждем следующий кадр игры и продолжаем цикл
            yield return null;
        }
    }
}