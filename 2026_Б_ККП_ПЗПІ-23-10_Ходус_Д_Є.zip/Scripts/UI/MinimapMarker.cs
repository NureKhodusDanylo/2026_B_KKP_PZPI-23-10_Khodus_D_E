using UnityEngine;

public class MinimapMarker : MonoBehaviour
{
    public enum MarkerType { Player, Enemy, Shard }
    public MarkerType type;
    
    private RectTransform _markerUI;

    void Start()
    {
        CreateMarkerUI();
    }

    void OnEnable()
    {
        if (_markerUI != null) _markerUI.gameObject.SetActive(true);
        else CreateMarkerUI();
    }

    void OnDisable()
    {
        if (_markerUI != null) _markerUI.gameObject.SetActive(false);
    }

    void OnDestroy()
    {
        if (_markerUI != null) Destroy(_markerUI.gameObject);
    }

    public void CreateMarkerUI()
    {
        if (_markerUI != null) return;
        
        var system = MinimapSystem.Instance;
        if (system == null) system = Object.FindAnyObjectByType<MinimapSystem>();
        
        if (system == null || system.mapContainer == null) return;
        
        GameObject prefab = type == MarkerType.Player ? system.playerMarkerPrefab : system.enemyMarkerPrefab;
        if (prefab == null) return;

        GameObject go = Instantiate(prefab, system.mapContainer);
        go.SetActive(true);
        _markerUI = go.GetComponent<RectTransform>();
        _markerUI.localScale = Vector3.one;
        _markerUI.localPosition = Vector3.zero;
        
        Debug.Log($"[MinimapMarker] Created UI for {gameObject.name} ({type}) at container {system.mapContainer.name}");
    }

    void LateUpdate()
    {
        if (_markerUI == null) 
        {
            CreateMarkerUI();
            return;
        }

        var system = MinimapSystem.Instance;
        if (system == null) system = Object.FindAnyObjectByType<MinimapSystem>();
        if (system == null) return;

        _markerUI.anchoredPosition = system.WorldToMapPos(transform.position);
        
        if (type == MarkerType.Player)
        {
            _markerUI.localRotation = Quaternion.Euler(0, 0, -transform.eulerAngles.y);
            // Ensure player marker is always on top
            _markerUI.SetAsLastSibling();
        }
    }
}
