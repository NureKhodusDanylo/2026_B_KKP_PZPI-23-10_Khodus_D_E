using System.Collections;
using UnityEngine;
using TMPro;

public class DamagePopup : MonoBehaviour
{
    [SerializeField] private TextMeshPro textMesh;
    [SerializeField] private float lifetime = 0.8f;
    [SerializeField] private float floatSpeed = 2f;
    [SerializeField] private float fadeSpeed = 2f;
    [SerializeField] private float scaleStart = 1f;
    [SerializeField] private float scaleEnd = 0.5f;
    [SerializeField] private Vector3 randomOffset = new Vector3(0.5f, 0f, 0f);

    public void Setup(float damage)
    {
        damage *= -1;
        textMesh.text = Mathf.RoundToInt(damage).ToString();

        Vector3 offset = new Vector3(
            Random.Range(-randomOffset.x, randomOffset.x),
            Random.Range(0f, randomOffset.y),
            Random.Range(-randomOffset.z, randomOffset.z)
        );
        transform.position += offset;

        StartCoroutine(Animate());
    }

    private IEnumerator Animate()
    {
        float elapsed = 0f;
        Color color = textMesh.color;
        Vector3 startScale = Vector3.one * scaleStart;
        Vector3 endScale = Vector3.one * scaleEnd;

        while (elapsed < lifetime)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / lifetime;

            // Float up
            transform.position += Vector3.up * floatSpeed * Time.deltaTime;

            // Billboard — face camera
            if (Camera.main != null)
            {
                transform.rotation = Camera.main.transform.rotation;
            }

            // Fade out
            color.a = Mathf.Lerp(1f, 0f, t * fadeSpeed);
            textMesh.color = color;

            // Scale down
            transform.localScale = Vector3.Lerp(startScale, endScale, t);

            yield return null;
        }

        Destroy(gameObject);
    }
}
