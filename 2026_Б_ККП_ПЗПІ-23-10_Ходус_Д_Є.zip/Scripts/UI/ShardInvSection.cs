using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Panel displayed INSIDE the inventory (when E is pressed).
/// Shows 4 shard-type slots with live 3D RenderTexture previews and counts.
/// Positioned above the item grid.
/// </summary>
public class ShardInvSection : MonoBehaviour
{
    // Auto-wired by SetupTool; each element maps to one ShardHUDSlot child
    // No extra logic needed here – ShardHUDSlot handles all subscription/refresh.

    private void Start()
    {
        // Nothing – ShardHUDSlot children handle themselves
    }
}
