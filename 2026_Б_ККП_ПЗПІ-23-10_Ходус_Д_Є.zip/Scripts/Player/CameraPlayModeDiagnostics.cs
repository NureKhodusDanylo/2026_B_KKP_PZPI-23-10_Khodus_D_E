#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using Cinemachine;
using System.Collections;
using System.Reflection;
using System.Text;
using System.IO;

public class CameraPlayModeDiagnostics : MonoBehaviour
{
    private static CameraPlayModeDiagnostics instance;

    // [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    private static void OnSceneLoad()
    {
        Debug.Log("CameraPlayModeDiagnostics: Scene loaded. Starting runner...");
        GameObject go = new GameObject("CameraDiagnosticsRunner");
        instance = go.AddComponent<CameraPlayModeDiagnostics>();
        instance.StartCoroutine(instance.DiagnosticsRoutine());
    }

    [MenuItem("Tools/Run Play Mode Diagnostics")]
    public static void RunDiagnostics()
    {
        Debug.Log("Starting Play Mode Diagnostics...");
        EditorApplication.isPlaying = true;
    }

    private IEnumerator DiagnosticsRoutine()
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("=== Play Mode Diagnostics Log ===");

        // Wait for player and scene initialization
        yield return new WaitForSeconds(2.0f);

        GameObject playerGo = GameObject.Find("PL");
        if (playerGo == null)
        {
            sb.AppendLine("ERROR: Player GO 'PL' not found!");
            WriteLog(sb.ToString());
            EditorApplication.isPlaying = false;
            yield break;
        }

        PlayerController pc = playerGo.GetComponent<PlayerController>();
        if (pc == null)
        {
            sb.AppendLine("ERROR: PlayerController not found on PL!");
            WriteLog(sb.ToString());
            EditorApplication.isPlaying = false;
            yield break;
        }

        GameObject freeLookGo = GameObject.Find("FreeLook Camera");
        if (freeLookGo == null)
        {
            sb.AppendLine("ERROR: FreeLook Camera not found!");
            WriteLog(sb.ToString());
            EditorApplication.isPlaying = false;
            yield break;
        }

        CinemachineFreeLook freeLook = freeLookGo.GetComponent<CinemachineFreeLook>();
        if (freeLook == null)
        {
            sb.AppendLine("ERROR: CinemachineFreeLook component not found!");
            WriteLog(sb.ToString());
            EditorApplication.isPlaying = false;
            yield break;
        }

        var moveInputField = typeof(PlayerController).GetField("moveInput", BindingFlags.NonPublic | BindingFlags.Instance);
        if (moveInputField == null)
        {
            sb.AppendLine("ERROR: 'moveInput' field not found on PlayerController!");
            WriteLog(sb.ToString());
            EditorApplication.isPlaying = false;
            yield break;
        }

        // Phase 1: Stationary state
        sb.AppendLine("\n--- Phase 1: Stationary ---");
        LogState(sb, playerGo, pc, freeLook);

        // Phase 2: Simulate moving right (moveInput = Vector2(1, 0))
        sb.AppendLine("\n--- Phase 2: Simulating Moving Right (Input = [1, 0]) ---");
        moveInputField.SetValue(pc, new Vector2(1f, 0f));

        // Wait and log over 2 seconds of movement
        for (int i = 0; i < 10; i++)
        {
            yield return new WaitForSeconds(0.2f);
            LogState(sb, playerGo, pc, freeLook);
        }

        // Phase 3: Stop moving
        sb.AppendLine("\n--- Phase 3: Stopping Movement (Input = [0, 0]) ---");
        moveInputField.SetValue(pc, Vector2.zero);
        yield return new WaitForSeconds(1.0f);
        LogState(sb, playerGo, pc, freeLook);

        // Final output and stop play mode
        WriteLog(sb.ToString());
        EditorApplication.isPlaying = false;
    }

    private void LogState(StringBuilder sb, GameObject playerGo, PlayerController pc, CinemachineFreeLook freeLook)
    {
        var modelField = typeof(PlayerController).GetField("model", BindingFlags.NonPublic | BindingFlags.Instance);
        GameObject modelGo = modelField != null ? (GameObject)modelField.GetValue(pc) : null;

        string modelRot = modelGo != null ? modelGo.transform.eulerAngles.ToString() : "null";
        
        sb.AppendLine($"Time: {Time.time:F2}s");
        sb.AppendLine($"  Player Position: {playerGo.transform.position}, Rotation: {playerGo.transform.eulerAngles}");
        sb.AppendLine($"  Player Model Rotation: {modelRot}");
        sb.AppendLine($"  Camera Position: {Camera.main.transform.position}, Rotation: {Camera.main.transform.eulerAngles}");
        sb.AppendLine($"  FreeLook XAxis: {freeLook.m_XAxis.Value:F4}, YAxis: {freeLook.m_YAxis.Value:F4}");
    }

    private void WriteLog(string content)
    {
        try
        {
            string path = Path.Combine(Application.dataPath, "diagnostics_log.txt");
            File.WriteAllText(path, content);
            Debug.Log($"Diagnostics log written to: {path}");
        }
        catch (System.Exception ex)
        {
            Debug.LogError($"Failed to write diagnostics log: {ex.Message}");
        }
    }
}
#endif
