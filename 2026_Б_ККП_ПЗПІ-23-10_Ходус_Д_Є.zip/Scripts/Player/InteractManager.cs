using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InteractManager : MonoBehaviour
{
    [SerializeField] private ActionPLController actionPLController;


    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.TryGetComponent(out IInteractable inter))
        {
            if (actionPLController.ActiveInteractObject != null)
                actionPLController.LostObject(actionPLController.ActiveInteractObject);

            actionPLController.ActiveInteractObject = inter;
            actionPLController.ReceivedObject(actionPLController.ActiveInteractObject);
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.TryGetComponent(out IInteractable inter) 
            && inter == actionPLController.ActiveInteractObject)
        {
            actionPLController.LostObject(actionPLController.ActiveInteractObject);
            actionPLController.ActiveInteractObject = null;
        }
    }
}
