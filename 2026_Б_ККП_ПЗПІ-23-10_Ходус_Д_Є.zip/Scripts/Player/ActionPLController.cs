using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ActionPLController : MonoBehaviour
{
    private PL_Controls inputActions;

    public IInteractable ActiveInteractObject;

    public event Action<IInteractable> ReceivedInteractObject;
    public event Action<IInteractable> LostInteractObject;

    private void OnDisable()
    {
        inputActions.Actions.Disable();
    }

    public void Init()
    {
        inputActions = new PL_Controls();

        inputActions.Actions.Enable();
        inputActions.Actions.Interct.started += ctx => PlayerInterction();
    }

    public void PlayerInterction()
    {
        if (ActiveInteractObject == null) return;

        ActiveInteractObject.Interact();
    }

    public void ReceivedObject(IInteractable interObject)
    {
        interObject.interactMenuAnimManager.StartAnimation();
        ReceivedInteractObject?.Invoke(interObject);
    }

    public void LostObject(IInteractable interObject)
    {
        interObject.interactMenuAnimManager.ReverseAnimation();
        LostInteractObject?.Invoke(interObject);
    }
}
