using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PLWalkState : State
{
    public PLWalkState( State previousState, List<State> avalibleStates) : 
        base( previousState, avalibleStates)
    {
        Name = "Player_Walk";
        Type = StateType.Data;
    }
    public override void OnStart()
    {
        //Debug.Log("I Walk");
    }

}
