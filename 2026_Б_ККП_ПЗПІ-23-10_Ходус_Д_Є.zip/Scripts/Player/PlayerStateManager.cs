using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static State;

public class PlayerStateManager : MonoBehaviour
{
    [SerializeField] private State initState; 
    [SerializeField] private List<State> playerStates;

    public State CurrentState { get; set; }

    public void Init(State _initstate)
    {
        initState = _initstate;
        CurrentState = initState;
    }
    public void Init()
    {
        GoToNextState(new PLWalkState(null, null));
    }

    void FixedUpdate()
    {
        CurrentState.EveryTick();
    }

    protected virtual void GoToNextState()
    {
        CurrentState?.OnEnd();

        State newState = CurrentState.NextState;
        if (newState == null) return;
        CurrentState = newState;

        CurrentState.OnStart();

        CheckTypeUpdate();
    }

    protected void GoToNextState(State newState)
    {
        CurrentState?.OnEnd();

        CurrentState = newState;
        CheckTypeUpdate();

        CurrentState.OnStart();
    }

    protected void CheckTypeUpdate()
    {
        if (CurrentState.Type == StateType.EveryTick) 
            enabled = true;
        else 
            enabled = false;
    }
}
