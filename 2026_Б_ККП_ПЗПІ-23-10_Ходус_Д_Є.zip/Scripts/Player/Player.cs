using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Assets.Scripts.AMagic;

public class Player : MonoBehaviour, IDamageable
{
    [Header("Refs")]
    [SerializeField] private PlayerController playerController;
    [SerializeField] private ActionPLController actionplayerController;
    [SerializeField] private PlayerStateManager playerStateManager;
    [SerializeField] private PlayerAnimationController playerAnimationController;
    [SerializeField] private MagicWeapon magicWeapon;

    [Header("Stats")]
    [SerializeField] private float MaxHP;
    [SerializeField] private float currentHp;

    [Header("Feedback")]
    [SerializeField] private DamageFeedback damageFeedback;

    private void Start()
    {
        // ... Start logic if needed
    }

    public float HP { get => currentHp; protected set => currentHp = value; }

    public void Init()
    {
        playerController.Init();
        playerStateManager.Init();
        actionplayerController.Init();
        playerAnimationController.Init();
        
        if (damageFeedback != null)
            damageFeedback.Init();

        if (magicWeapon != null)
            magicWeapon.SetPlayerController(playerController);

        HP = MaxHP;
    }

    public void TakeDamage(float damage)
    {
        HP -= damage;

        if (damageFeedback != null)
        {
            damageFeedback.PlayFeedback(damage);
        }
    }
}
