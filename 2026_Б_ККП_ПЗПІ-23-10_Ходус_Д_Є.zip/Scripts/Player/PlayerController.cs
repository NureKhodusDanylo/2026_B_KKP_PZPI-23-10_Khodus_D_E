using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.InputSystem;
using static UnityEngine.InputSystem.InputAction;

public class PlayerController : MonoBehaviour
{
    [Header("Movement Parameters")]
    [SerializeField] private float smoothTime = 0.1f;
    [SerializeField] private float maxSpeed = 5f;
    [SerializeField] private float rotationSpeed = 1f;
    [SerializeField] private float runSpeed = 7f;

    [SerializeField] private float dashDuration = 0.2f;
    [SerializeField] private float dashFactor = 2.5f;
    [SerializeField] private float dashCoolDownTime = 3f;
    //[SerializeField] private Vector3 offsetRotation;
    [SerializeField] private float raycastDistance = 1f;
    [SerializeField] private LayerMask layerMask;
    [SerializeField] private float jumpForce = 7f;

    [Header("Refs")]
    [SerializeField] private GameObject model;

    private PL_Controls inputActions;
    private Vector2 moveInput;
    private Rigidbody rb;
    private Vector3 currentVelocity = Vector3.zero;

    private bool isGrounded = false;
    private bool jumpRequested = false;

    public bool IsGrounded => isGrounded;

    public float currentMaxSpeed = 0f;
    private bool isDashing = false;   
    private bool enableDash = true;
    private bool isRuning = false;
    private bool isControlFrozen = false;

    //Events 
    public event Action OnWalk;
    public event Action OnStop;
    public event Action OnRun;
    public event Action OnDash;

    public void ToggleControl(bool freeze)
    {
        isControlFrozen = freeze;
        if (isControlFrozen)
        {
            moveInput = Vector2.zero;
            rb.velocity = Vector3.zero;
            OnStop?.Invoke();
        }
    }

    private void OnDisable()
    {
        inputActions.Move.Disable();

        inputActions.Move.Movement.started -= ctx => StartMove(ctx);
        inputActions.Move.Movement.performed -= ctx => moveInput = ctx.ReadValue<Vector2>();
        inputActions.Move.Movement.canceled -= ctx => StopMove(ctx);

        inputActions.Move.Dash.performed -= ctx => StartCoroutine(DashCoroutine());
    }

    private void EnsureFrictionlessMaterial()
    {
        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            PhysicMaterial frictionlessMat = new PhysicMaterial("Frictionless");
            frictionlessMat.dynamicFriction = 0f;
            frictionlessMat.staticFriction = 0f;
            frictionlessMat.frictionCombine = PhysicMaterialCombine.Minimum;
            frictionlessMat.bounciness = 0f;
            frictionlessMat.bounceCombine = PhysicMaterialCombine.Minimum;
            col.sharedMaterial = frictionlessMat;
        }
    }

    private void Update()
    {
        if (isControlFrozen) return;

        bool spacePressed = false;
        if (Keyboard.current != null)
        {
            spacePressed = Keyboard.current.spaceKey.wasPressedThisFrame;
        }
        else
        {
            spacePressed = Input.GetKeyDown(KeyCode.Space);
        }

        if (spacePressed)
        {
            jumpRequested = true;
        }
    }

    private void FixedUpdate()
    {
        if (isControlFrozen)
        {
            rb.velocity = Vector3.zero;
            return;
        }

        Vector3 cameraForward = Camera.main.transform.forward;
        cameraForward.y = 0f;
        cameraForward.Normalize();

        Vector3 cameraRight = Camera.main.transform.right;
        cameraRight.y = 0f;
        cameraRight.Normalize();

        Vector3 targetMovement = (cameraForward * moveInput.y) + (cameraRight * moveInput.x);

        Vector3 horizontalVelocity = new Vector3(rb.velocity.x, 0f, rb.velocity.z);
        Vector3 targetHorizontalVelocity = targetMovement * currentMaxSpeed;

        Vector3 smoothedHorizontal = Vector3.SmoothDamp(
            horizontalVelocity,
            targetHorizontalVelocity,
            ref currentVelocity,
            smoothTime
        );

        // Ground check using SphereCast
        CapsuleCollider capsule = GetComponent<CapsuleCollider>();
        float radius = capsule != null ? capsule.radius : 0.3f;
        float height = capsule != null ? capsule.height : 2.0f;
        Vector3 center = capsule != null ? capsule.center : new Vector3(0f, 1f, 0f);
        float castDistance = 0.3f;

        float bottomYOffset = center.y - (height / 2f);
        Vector3 castOrigin = transform.position + Vector3.up * (bottomYOffset + radius + 0.1f);
        RaycastHit hit;

        isGrounded = Physics.SphereCast(
            castOrigin,
            radius * 0.9f, // slightly smaller sphere to prevent wall friction
            Vector3.down,
            out hit,
            0.1f + castDistance,
            layerMask
        );

        if (isGrounded)
        {
            // Grounded: Project the smoothed horizontal velocity onto the slope normal
            Vector3 movementOnSurface = Vector3.ProjectOnPlane(smoothedHorizontal, hit.normal);
            
            // Crucial step: Preserve full horizontal movement speed on steep slopes/stairs
            if (smoothedHorizontal.magnitude > 0.01f)
            {
                movementOnSurface = movementOnSurface.normalized * smoothedHorizontal.magnitude;
            }
            
            rb.velocity = movementOnSurface;
        }
        else
        {
            // In air: preserve gravity Y-velocity
            rb.velocity = new Vector3(smoothedHorizontal.x, rb.velocity.y, smoothedHorizontal.z);
        }

        // Apply jump velocity if requested and grounded
        if (jumpRequested)
        {
            jumpRequested = false;
            if (isGrounded)
            {
                rb.velocity = new Vector3(rb.velocity.x, jumpForce, rb.velocity.z);
                isGrounded = false;
            }
        }

        if (smoothedHorizontal.magnitude > 0.1f && moveInput != Vector2.zero)
        {
            Quaternion targetRotation = Quaternion.LookRotation(smoothedHorizontal);
            model.transform.rotation = Quaternion.Slerp(
                model.transform.rotation,
                targetRotation,
                rotationSpeed * Time.fixedDeltaTime
            );
        }
    }

    public void Init()
    {
        inputActions = new PL_Controls();
        rb = GetComponent<Rigidbody>();
        currentMaxSpeed = maxSpeed;

        if (layerMask.value == 0)
        {
            layerMask = LayerMask.GetMask("Ground");
            if (layerMask.value == 0)
            {
                layerMask = 128; // Fallback to Layer 7 (Ground)
            }
        }
        if (raycastDistance <= 0.1f || raycastDistance == 1f)
        {
            raycastDistance = 1.5f;
        }

        EnsureFrictionlessMaterial();

        inputActions.Move.Enable();
        inputActions.Move.Movement.started += ctx => StartMove(ctx);
        inputActions.Move.Movement.performed += ctx => moveInput = ctx.ReadValue<Vector2>();
        inputActions.Move.Movement.canceled += ctx => StopMove(ctx);

        inputActions.Move.Dash.performed += ctx => StartCoroutine(DashCoroutine());
    }

    private void StartMove(CallbackContext ctx)
    {
        currentMaxSpeed = maxSpeed;
        OnWalk?.Invoke();
    }
    private void StopMove(CallbackContext ctx)
    {
        moveInput = Vector2.zero;
        OnStop?.Invoke();
    }

    private IEnumerator DashCoroutine()
    {
        if (isDashing || !enableDash) yield break;
        StartCoroutine(DashCoolDown());

        isDashing = true;
        float dashSpeed = currentMaxSpeed * dashFactor;
        OnDash?.Invoke();

        Vector3 dashDirection = model.transform.forward;
        if (moveInput.magnitude > 0)
        {
            Vector3 camF = Camera.main.transform.forward;
            camF.y = 0f;
            camF.Normalize();

            Vector3 camR = Camera.main.transform.right;
            camR.y = 0f;
            camR.Normalize();

            dashDirection = (camF * moveInput.y + camR * moveInput.x).normalized;
        }

        float dashStartTime = Time.time;

        while (Time.time < dashStartTime + dashDuration)
        {
            rb.velocity = dashDirection * dashSpeed;
            yield return new WaitForFixedUpdate();
        }

        currentMaxSpeed = runSpeed;
        isDashing = false;
        
        if (moveInput == Vector2.zero)
            OnStop?.Invoke();
        else
            OnRun?.Invoke();

    }
    private IEnumerator DashCoolDown()
    {
        enableDash = false;
        yield return new WaitForSeconds(dashCoolDownTime);
        enableDash = true;
    }
}