﻿using UnityEngine;
using Cinemachine;

[RequireComponent(typeof(CinemachineFreeLook))]
public class CinemachineFreeLookZoom : MonoBehaviour
{
    private CinemachineFreeLook freeLook;

    [Header("Lens FOV Zoom Settings")]
    [SerializeField] private float zoomSpeed = 8f;      // Швидкість плавного наближення
    [SerializeField] private float minFOV = 20f;         // Максимальний зум (наближення до гравця)
    [SerializeField] private float maxFOV = 60f;         // Мінімальний зум (віддалення камери)
    [SerializeField] private float sensitivity = 5f;     // Чутливість коліщатка миші

    private float targetFOV;

    private void Awake()
    {
        freeLook = GetComponent<CinemachineFreeLook>();
        // Запам'ятовуємо початковий кут огляду камери
        targetFOV = freeLook.m_Lens.FieldOfView;
    }

    private void Update()
    {
        // Зчитуємо скрол миші напрямую
        float scrollInput = Input.GetAxis("Mouse ScrollWheel");

        if (Mathf.Abs(scrollInput) > 0.001f)
        {
            // Міняємо цільовий кут огляду (FOV)
            targetFOV -= scrollInput * sensitivity * 10f;
            // Обмежуємо зум, щоб не заходити за рамки
            targetFOV = Mathf.Clamp(targetFOV, minFOV, maxFOV);
        }

        // Плавно наближаємо поточний FOV лінзи до цільового
        freeLook.m_Lens.FieldOfView = Mathf.Lerp(freeLook.m_Lens.FieldOfView, targetFOV, Time.deltaTime * zoomSpeed);
    }
}