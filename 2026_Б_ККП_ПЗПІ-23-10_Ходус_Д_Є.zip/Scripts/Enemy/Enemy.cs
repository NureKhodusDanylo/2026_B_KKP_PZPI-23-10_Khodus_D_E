using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour, IInitializable, IDamageable
{
    [SerializeField] private List<MonoBehaviour> _components;
    [SerializeField] private EnemyStateManager enemyStateManager;

    [Header("Stats")]
    [SerializeField] private float maxHP = 100f;
    [SerializeField] private float currentHp;

    [Header("Feedback")]
    [SerializeField] private DamageFeedback damageFeedback;

    private bool isDead = false;

    public float HP { get => currentHp; }

    public void Init()
    {
        // Якщо є EnemyLevelData — застосовуємо масштабовані характеристики
        EnemyLevelData levelData = GetComponent<EnemyLevelData>();
        if (levelData != null)
        {
            maxHP = levelData.ScaledHP;

            // Прокачуємо урон зброї
            Weapon weapon = GetComponentInChildren<Weapon>();
            if (weapon != null)
            {
                weapon.Damage = levelData.ScaledDamage;
            }
        }

        currentHp = maxHP;

        if (damageFeedback != null)
            damageFeedback.Init();

        if (GetComponent<EnemyDropper>() == null)
        {
            gameObject.AddComponent<EnemyDropper>();
        }

        foreach (var component in _components)
        {
            if (component is IInitializable initializable)
            {
                initializable.Init();
            }
        }
    }

    public void TakeDamage(float damage)
    {
        if (isDead) return;

        currentHp -= damage;

        if (damageFeedback != null)
        {
            damageFeedback.PlayFeedback(damage);
        }

        if (currentHp <= 0f)
        {
            currentHp = 0f;
            isDead = true;
            enemyStateManager.TriggerDie();
        }
    }
}
