using UnityEngine;

/// <summary>
/// Компонент прокачки ворога — зберігає рівень та масштабовані характеристики.
/// Додається автоматично при спавні через EnemySpawner.
/// </summary>
public class EnemyLevelData : MonoBehaviour
{
    [Header("===== РІВЕНЬ =====")]
    [SerializeField] private int level = 1;
    [SerializeField] private float scaledHP = 50f;
    [SerializeField] private float scaledDamage = 10f;

    public int Level => level;
    public float ScaledHP => scaledHP;
    public float ScaledDamage => scaledDamage;

    /// <summary>
    /// Встановити рівень та характеристики (викликається EnemySpawner при спавні)
    /// </summary>
    public void SetLevel(int newLevel, float hp, float damage)
    {
        level = newLevel;
        scaledHP = hp;
        scaledDamage = damage;
    }
}
