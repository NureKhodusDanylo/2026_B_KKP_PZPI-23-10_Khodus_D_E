using System;
using Assets.Scripts.AMagic;
using UnityEngine;

public class EnemyDropper : MonoBehaviour
{
    [Header("Drop Settings")]
    [SerializeField, Range(0f, 1f)] private float dropChance = 1f;
    [SerializeField] private int minDropCount = 2;
    [SerializeField] private int maxDropCount = 5;

    [Header("Shard Visuals")]
    [SerializeField, Tooltip("Uniform scale of each shard. Default is 1. Increase to make bigger shards.")]
    private float shardScale = 3f;

    private EnemyStateManager stateManager;
    private bool hasDropped = false;

    private void Start()
    {
        stateManager = GetComponent<EnemyStateManager>()
                    ?? GetComponentInParent<EnemyStateManager>();

        if (stateManager != null)
            stateManager.Die += HandleEnemyDeath;
        else
            Debug.LogWarning($"[EnemyDropper] EnemyStateManager not found on {gameObject.name} or its parents!");
    }

    private void OnDestroy()
    {
        if (stateManager != null)
            stateManager.Die -= HandleEnemyDeath;
    }

    private void HandleEnemyDeath()
    {
        if (hasDropped) return;
        hasDropped = true;

        if (UnityEngine.Random.value > dropChance) return;

        int dropCount = UnityEngine.Random.Range(minDropCount, maxDropCount + 1);
        Array shardTypes = Enum.GetValues(typeof(ShardType));
        Vector3 spawnPos = transform.position + Vector3.up * 0.5f;

        for (int i = 0; i < dropCount; i++)
        {
            ShardType randomType = (ShardType)shardTypes.GetValue(UnityEngine.Random.Range(0, shardTypes.Length));
            GameObject shardGo = new GameObject($"MagicShard_{randomType}_{i}");
            MagicShard shard = shardGo.AddComponent<MagicShard>();
            shard.Initialize(randomType, spawnPos, shardScale);
        }
    }
}
