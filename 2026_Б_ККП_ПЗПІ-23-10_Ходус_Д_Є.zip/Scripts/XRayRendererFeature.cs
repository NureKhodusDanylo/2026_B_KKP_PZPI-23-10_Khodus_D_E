using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using System.Collections.Generic;

public class XRayRendererFeature : ScriptableRendererFeature
{
    [System.Serializable]
    public class XRaySettings
    {
        public RenderPassEvent renderPassEvent = RenderPassEvent.AfterRenderingTransparents;
        
        [Header("Filtering")]
        public LayerMask xrayLayerMask = -1; // Default to everything

        [Header("Aesthetics")]
        [ColorUsage(true, true)]
        public Color xrayColor = new Color(0.0f, 0.4f, 0.8f, 0.2f);
        
        [ColorUsage(true, true)]
        public Color fresnelColor = new Color(0.0f, 0.8f, 1.0f, 0.8f);
        
        [Range(0.1f, 10.0f)]
        public float fresnelPower = 3.0f;
    }

    public XRaySettings settings = new XRaySettings();
    private Material m_Material;
    private XRayStencilPass m_StencilPass;
    private XRayPass m_XRayPass;

    public override void Create()
    {
        m_StencilPass = null;
        m_XRayPass = null;
    }

    public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
    {
        // Eagerly resolve/load the shader and instantiate material
        if (m_Material == null)
        {
#if UNITY_EDITOR
            var shader = UnityEditor.AssetDatabase.LoadAssetAtPath<Shader>("Assets/Shaders/XRaySilhouette.shader");
#else
            Shader shader = null;
#endif
            if (shader == null)
            {
                shader = Shader.Find("Hidden/XRaySilhouette");
            }

            if (shader != null)
            {
                m_Material = CoreUtils.CreateEngineMaterial(shader);
                Debug.Log($"[XRayRendererFeature] m_Material successfully created! Shader: {shader.name}");
            }
            else
            {
                Debug.LogError("[XRayRendererFeature] Failed to find Hidden/XRaySilhouette shader!");
                return;
            }
        }

        // Recreate passes to ensure settings are always fresh
        m_StencilPass = new XRayStencilPass(settings, m_Material);
        m_XRayPass = new XRayPass(settings, m_Material);
        
        // Enqueue the stencil pre-pass first to mark visible pixels
        renderer.EnqueuePass(m_StencilPass);
        
        // Enqueue the X-Ray pass second to draw silhouettes only on unmarked (occluded) pixels
        renderer.EnqueuePass(m_XRayPass);
    }

    protected override void Dispose(bool disposing)
    {
        if (m_Material != null)
        {
            CoreUtils.Destroy(m_Material);
            m_Material = null;
        }
    }

    // 1. Pre-Pass to mark visible pixels of the filtered layers in the Stencil Buffer
    class XRayStencilPass : ScriptableRenderPass
    {
        private XRaySettings settings;
        private Material material;
        private FilteringSettings filteringSettings;
        private List<ShaderTagId> shaderTagIds = new List<ShaderTagId>();
        private readonly ProfilingSampler m_ProfilingSampler = new ProfilingSampler("XRayStencilPrePass");

        public XRayStencilPass(XRaySettings settings, Material material)
        {
            this.settings = settings;
            this.material = material;
            this.renderPassEvent = settings.renderPassEvent;
            
            this.filteringSettings = new FilteringSettings(RenderQueueRange.all, settings.xrayLayerMask);

            shaderTagIds.Add(new ShaderTagId("UniversalForward"));
            shaderTagIds.Add(new ShaderTagId("UniversalForwardOnly"));
            shaderTagIds.Add(new ShaderTagId("LightweightForward"));
            shaderTagIds.Add(new ShaderTagId("SRPDefaultUnlit"));
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (material == null) return;

            CommandBuffer cmd = CommandBufferPool.Get();

            using (new ProfilingScope(cmd, m_ProfilingSampler))
            {
                context.ExecuteCommandBuffer(cmd);
                cmd.Clear();

                var sortingCriteria = renderingData.cameraData.defaultOpaqueSortFlags;
                var drawingSettings = CreateDrawingSettings(shaderTagIds, ref renderingData, sortingCriteria);
                
                // Use Pass 1 (Stencil Mask) of the shader
                drawingSettings.overrideMaterial = material;
                drawingSettings.overrideMaterialPassIndex = 1;

                // Configure RenderStateBlock to write '2' to the stencil buffer where objects are visible
                RenderStateBlock stateBlock = new RenderStateBlock(RenderStateMask.Stencil);
                stateBlock.stencilReference = 2;
                stateBlock.stencilState = new StencilState(
                    enabled: true,
                    readMask: 0xFF,
                    writeMask: 0xFF,
                    compareFunction: CompareFunction.Always,
                    passOperation: StencilOp.Replace,
                    failOperation: StencilOp.Keep,
                    zFailOperation: StencilOp.Keep
                );

                context.DrawRenderers(renderingData.cullResults, ref drawingSettings, ref filteringSettings, ref stateBlock);
            }

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }
    }

    // 2. Pass to draw occluded objects, masked out of the visible stencil pixels
    class XRayPass : ScriptableRenderPass
    {
        private XRaySettings settings;
        private Material material;
        private FilteringSettings filteringSettings;
        private List<ShaderTagId> shaderTagIds = new List<ShaderTagId>();
        private readonly ProfilingSampler m_ProfilingSampler = new ProfilingSampler("XRaySilhouette");

        public XRayPass(XRaySettings settings, Material material)
        {
            this.settings = settings;
            this.material = material;
            this.renderPassEvent = settings.renderPassEvent;
            
            this.filteringSettings = new FilteringSettings(RenderQueueRange.all, settings.xrayLayerMask);

            shaderTagIds.Add(new ShaderTagId("UniversalForward"));
            shaderTagIds.Add(new ShaderTagId("UniversalForwardOnly"));
            shaderTagIds.Add(new ShaderTagId("LightweightForward"));
            shaderTagIds.Add(new ShaderTagId("SRPDefaultUnlit"));
        }

        public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
        {
            if (material == null) return;

            CommandBuffer cmd = CommandBufferPool.Get();

            using (new ProfilingScope(cmd, m_ProfilingSampler))
            {
                context.ExecuteCommandBuffer(cmd);
                cmd.Clear();

                // Apply dynamic settings from the Inspector
                material.SetColor("_XRayColor", settings.xrayColor);
                material.SetColor("_FresnelColor", settings.fresnelColor);
                material.SetFloat("_FresnelPower", settings.fresnelPower);

                var sortingCriteria = renderingData.cameraData.defaultOpaqueSortFlags;
                var drawingSettings = CreateDrawingSettings(shaderTagIds, ref renderingData, sortingCriteria);
                
                // Use Pass 0 (Fresnel Glow) of the shader
                drawingSettings.overrideMaterial = material;
                drawingSettings.overrideMaterialPassIndex = 0;

                // Configure RenderStateBlock to only draw where the Stencil is NOT '2'
                RenderStateBlock stateBlock = new RenderStateBlock(RenderStateMask.Stencil);
                stateBlock.stencilReference = 2;
                stateBlock.stencilState = new StencilState(
                    enabled: true,
                    readMask: 0xFF,
                    writeMask: 0xFF,
                    compareFunction: CompareFunction.NotEqual,
                    passOperation: StencilOp.Keep,
                    failOperation: StencilOp.Keep,
                    zFailOperation: StencilOp.Keep
                );

                context.DrawRenderers(renderingData.cullResults, ref drawingSettings, ref filteringSettings, ref stateBlock);
            }

            context.ExecuteCommandBuffer(cmd);
            CommandBufferPool.Release(cmd);
        }
    }
}
