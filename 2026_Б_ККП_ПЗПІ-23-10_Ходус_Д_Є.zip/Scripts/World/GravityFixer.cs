using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GravityFixer : MonoBehaviour
{
    public Rigidbody rb;

    public bool isGrounded = false;

    public float gravity = 1f;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Ground") 
        {
            isGrounded = true;
            enabled = false;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.tag == "Ground")
        {
            isGrounded = false;
            enabled = true;
        }
    }

    private void FixedUpdate()
    {
        if (!isGrounded)
        {
            Vector3 gravityForce = new Vector3(0, -gravity, 0);
            rb.AddForce(gravityForce, ForceMode.Acceleration);
        }
    }
}
