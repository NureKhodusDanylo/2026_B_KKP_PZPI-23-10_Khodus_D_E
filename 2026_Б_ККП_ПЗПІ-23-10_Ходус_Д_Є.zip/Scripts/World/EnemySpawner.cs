using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour, IInitializable
{
    [Header("===== ПРЕФАБИ ВОРОГІВ ЗА ЛОКАЦІЯМИ =====")]
    public List<GameObject> EnemyPrefabs = new List<GameObject>();
    public List<GameObject> EnemyPrefabsRed = new List<GameObject>();
    public List<GameObject> EnemyPrefabsOrange = new List<GameObject>();
    public List<GameObject> EnemyPrefabsYellow = new List<GameObject>();
    public List<GameObject> EnemyPrefabsGreen = new List<GameObject>();
    public List<GameObject> EnemyPrefabsLightBlue = new List<GameObject>();
    public List<GameObject> EnemyPrefabsBlue = new List<GameObject>();
    public List<GameObject> EnemyPrefabsPurple = new List<GameObject>();

    [Header("===== НАЛАШТУВАННЯ СПАВНУ =====")]
    [Tooltip("Кількість ворогів на один чанк")]
    [Range(1, 30)]
    public int enemiesPerChunk = 3;

    [Tooltip("Інтервал респавну в секундах")]
    [Range(5f, 120f)]
    public float respawnInterval = 30f;

    [Range(30f, 250f)]
    public float spawnRadius = 80f;

    public LayerMask groundLayer = ~0;

    [Range(20f, 80f)]
    public float chunkSize = 40f;

    [Header("===== ПРОКАЧКА ВОРОГІВ =====")]
    [Tooltip("Центр світу — точка відліку для рівня ворогів")]
    public Vector3 worldCenter = Vector3.zero;

    [Tooltip("Кожні N одиниць від центру = +1 рівень")]
    [Range(10f, 200f)]
    public float distancePerLevel = 100f;

    [Tooltip("Множник HP за рівень")]
    [Range(1f, 50f)]
    public float hpPerLevel = 20f;

    [Tooltip("Множник урону за рівень")]
    [Range(0.5f, 20f)]
    public float damagePerLevel = 5f;

    [Tooltip("Базовий HP ворогів")]
    [Range(10f, 500f)]
    public float baseHP = 100f;

    [Tooltip("Базовий урон ворогів")]
    [Range(1f, 100f)]
    public float baseDamage = 15f;

    [Header("===== КОЛЬОРОВА СХЕМА (ЛОКАЦІЇ) =====")]
    public float speed = 37.73f;
    public float ringDensity = 0.01f;
    public float time = -0.41f;

    [Header("===== ЛІМІТИ ТА ЗОНИ =====")]
    [Tooltip("Максимальна кількість живих ворогів одночасно")]
    [Range(5, 200)]
    public int maxAliveEnemies = 50;

    [Range(0.1f, 1f)]
    public float updateInterval = 0.5f;

    public List<Transform> exclusionZones = new List<Transform>();
    [Range(0f, 50f)]
    public float exclusionRadius = 100f;

    [Header("===== ПОСИЛАННЯ =====")]
    public Transform playerTransform;

    private class EnemyChunkData
    {
        public List<GameObject> aliveEnemies = new List<GameObject>();
        public bool isGenerated = false;
        public float lastSpawnTime = 0f;
    }

    private Dictionary<Vector2Int, EnemyChunkData> chunks = new Dictionary<Vector2Int, EnemyChunkData>();
    private Transform parentObject;
    private Vector3 lastPlayerPosition;
    private int currentAliveCount = 0;
    private Vector2 noiseOffset;

    public void Init()
    {
        if (playerTransform == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
                playerTransform = player.transform;
        }

        if (playerTransform == null)
        {
            Debug.LogError("❌ EnemySpawner: Player not found!");
            return;
        }

        noiseOffset = new Vector2(Random.Range(0f, 10000f), Random.Range(0f, 10000f));

        GameObject parent = GameObject.Find("Spawned Enemies");
        if (parent == null)
            parent = new GameObject("Spawned Enemies");
        parentObject = parent.transform;

        lastPlayerPosition = playerTransform.position;

        SpawnInitialArea();
        StartCoroutine(ContinuousSpawnLoop());

        Debug.Log("✅ Система спавну ворогів запущена (чанкова, за кольором)");
    }

    private void SpawnInitialArea()
    {
        Vector2Int centerChunk = WorldToChunk(playerTransform.position);
        int radius = Mathf.CeilToInt(spawnRadius / chunkSize);

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                Vector2Int chunkCoord = new Vector2Int(centerChunk.x + x, centerChunk.y + z);
                if (!chunks.ContainsKey(chunkCoord))
                {
                    SpawnChunk(chunkCoord);
                }
            }
        }
    }

    private IEnumerator ContinuousSpawnLoop()
    {
        while (true)
        {
            if (playerTransform != null)
            {
                float distanceMoved = Vector3.Distance(playerTransform.position, lastPlayerPosition);

                if (distanceMoved > chunkSize * 0.3f)
                {
                    SpawnNewChunks();
                    CleanupDistantChunks();
                    lastPlayerPosition = playerTransform.position;
                }

                RespawnInExistingChunks();
            }

            yield return new WaitForSeconds(updateInterval);
        }
    }

    private void SpawnNewChunks()
    {
        Vector2Int centerChunk = WorldToChunk(playerTransform.position);
        int radius = Mathf.CeilToInt(spawnRadius / chunkSize);

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                Vector2Int chunkCoord = new Vector2Int(centerChunk.x + x, centerChunk.y + z);
                if (!chunks.ContainsKey(chunkCoord))
                {
                    SpawnChunk(chunkCoord);
                }
            }
        }
    }

    private void SpawnChunk(Vector2Int chunkCoord)
    {
        EnemyChunkData chunkData = new EnemyChunkData();

        float chunkStartX = chunkCoord.x * chunkSize;
        float chunkStartZ = chunkCoord.y * chunkSize;
        float chunkEndX = chunkStartX + chunkSize;
        float chunkEndZ = chunkStartZ + chunkSize;

        int spawned = 0;
        int attempts = 0;
        int maxAttempts = enemiesPerChunk * 5;

        while (spawned < enemiesPerChunk && attempts < maxAttempts)
        {
            if (currentAliveCount >= maxAliveEnemies)
                break;

            float randomX = Random.Range(chunkStartX, chunkEndX);
            float randomZ = Random.Range(chunkStartZ, chunkEndZ);

            if (IsInExclusionZone(randomX, randomZ))
            {
                attempts++;
                continue;
            }

            Vector3 groundPos = GetGroundPosition(randomX, randomZ);

            if (groundPos != Vector3.zero)
            {
                GameObject enemy = SpawnEnemy(groundPos);
                if (enemy != null)
                {
                    chunkData.aliveEnemies.Add(enemy);
                    spawned++;
                }
            }

            attempts++;
        }

        chunkData.isGenerated = true;
        chunkData.lastSpawnTime = Time.time;
        chunks[chunkCoord] = chunkData;
    }

    private GameObject SpawnEnemy(Vector3 position)
    {
        GameObject prefab = SelectRandomPrefab(position);
        if (prefab == null) return null;

        int level = CalculateLevel(position);
        Quaternion rotation = Quaternion.Euler(0, Random.Range(0f, 360f), 0);

        GameObject instance = Instantiate(prefab, position, rotation);
        instance.transform.SetParent(parentObject);

        ApplyLevelScaling(instance, level);

        Enemy enemyComponent = instance.GetComponent<Enemy>();
        if (enemyComponent != null)
        {
            enemyComponent.Init();
        }

        currentAliveCount++;
        return instance;
    }

    private int CalculateLevel(Vector3 position)
    {
        float dist = Vector3.Distance(position, worldCenter);
        return 1 + Mathf.FloorToInt(dist / distancePerLevel);
    }

    private GameObject SelectRandomPrefab(Vector3 position)
    {
        Color calculatedColor = ShaderColorCalculator.GetColorAtWorldPosition(
            position.x, position.z, time, speed, ringDensity
        );

        Color.RGBToHSV(calculatedColor, out float h, out float s, out float v);

        List<GameObject> selectedList = GetColorList(h);

        if (selectedList != null && selectedList.Count > 0)
        {
            float noise = Mathf.PerlinNoise(
                position.x * 0.05f + noiseOffset.x,
                position.z * 0.05f + noiseOffset.y
            );
            int index = Mathf.FloorToInt(noise * selectedList.Count);
            index = Mathf.Clamp(index, 0, selectedList.Count - 1);
            return selectedList[index];
        }

        return EnemyPrefabs.Count > 0 ? EnemyPrefabs[Random.Range(0, EnemyPrefabs.Count)] : null;
    }

    private List<GameObject> GetColorList(float h)
    {
        if (h < 0.1f) return EnemyPrefabsRed;
        if (h < 0.2f) return EnemyPrefabsOrange;
        if (h < 0.4f) return EnemyPrefabsYellow;
        if (h < 0.6f) return EnemyPrefabsGreen;
        if (h < 0.7f) return EnemyPrefabsLightBlue;
        if (h < 0.85f) return EnemyPrefabsBlue;
        return EnemyPrefabsPurple;
    }

    private void ApplyLevelScaling(GameObject enemyObj, int level)
    {
        EnemyLevelData levelData = enemyObj.GetComponent<EnemyLevelData>();
        if (levelData == null)
            levelData = enemyObj.AddComponent<EnemyLevelData>();

        float scaledHP = baseHP + (level - 1) * hpPerLevel;
        float scaledDamage = baseDamage + (level - 1) * damagePerLevel;

        levelData.SetLevel(level, scaledHP, scaledDamage);
    }

    private void RespawnInExistingChunks()
    {
        if (currentAliveCount >= maxAliveEnemies) return;

        Vector2Int playerChunk = WorldToChunk(playerTransform.position);
        float maxDist = spawnRadius / chunkSize;

        foreach (var kvp in chunks)
        {
            float chunkDist = Vector2.Distance(
                new Vector2(kvp.Key.x, kvp.Key.y),
                new Vector2(playerChunk.x, playerChunk.y)
            );
            if (chunkDist > maxDist) continue;

            EnemyChunkData chunkData = kvp.Value;

            for (int i = chunkData.aliveEnemies.Count - 1; i >= 0; i--)
            {
                if (chunkData.aliveEnemies[i] == null)
                {
                    chunkData.aliveEnemies.RemoveAt(i);
                    currentAliveCount = Mathf.Max(0, currentAliveCount - 1);
                }
            }

            if (chunkData.aliveEnemies.Count < enemiesPerChunk)
            {
                float timeSinceLastSpawn = Time.time - chunkData.lastSpawnTime;
                if (timeSinceLastSpawn >= respawnInterval)
                {
                    Vector3 spawnPos = FindSpawnPosInChunk(kvp.Key);
                    if (spawnPos != Vector3.zero)
                    {
                        GameObject enemy = SpawnEnemy(spawnPos);
                        if (enemy != null)
                        {
                            chunkData.aliveEnemies.Add(enemy);
                            chunkData.lastSpawnTime = Time.time;
                        }
                    }
                }
            }
        }
    }

    private Vector3 FindSpawnPosInChunk(Vector2Int chunkCoord)
    {
        float chunkStartX = chunkCoord.x * chunkSize;
        float chunkStartZ = chunkCoord.y * chunkSize;
        float chunkEndX = chunkStartX + chunkSize;
        float chunkEndZ = chunkStartZ + chunkSize;

        for (int i = 0; i < 5; i++)
        {
            float x = Random.Range(chunkStartX, chunkEndX);
            float z = Random.Range(chunkStartZ, chunkEndZ);

            if (!IsInExclusionZone(x, z))
            {
                Vector3 pos = GetGroundPosition(x, z);
                if (pos != Vector3.zero) return pos;
            }
        }
        return Vector3.zero;
    }

    private void CleanupDistantChunks()
    {
        Vector2Int playerChunk = WorldToChunk(playerTransform.position);
        List<Vector2Int> toRemove = new List<Vector2Int>();
        float cleanupDistance = spawnRadius + chunkSize;

        foreach (var kvp in chunks)
        {
            float distance = Vector2.Distance(
                new Vector2(kvp.Key.x, kvp.Key.y),
                new Vector2(playerChunk.x, playerChunk.y)
            ) * chunkSize;

            if (distance > cleanupDistance)
                toRemove.Add(kvp.Key);
        }

        foreach (var chunkCoord in toRemove)
        {
            EnemyChunkData chunk = chunks[chunkCoord];
            foreach (GameObject obj in chunk.aliveEnemies)
            {
                if (obj != null)
                {
                    currentAliveCount = Mathf.Max(0, currentAliveCount - 1);
                    if (Application.isPlaying) Destroy(obj);
                    else DestroyImmediate(obj);
                }
            }
            chunks.Remove(chunkCoord);
        }
    }

    private bool IsInExclusionZone(float x, float z)
    {
        foreach (Transform zone in exclusionZones)
        {
            if (zone != null)
            {
                float dist = Vector2.Distance(new Vector2(x, z), new Vector2(zone.position.x, zone.position.z));
                if (dist < exclusionRadius) return true;
            }
        }
        return false;
    }

    private Vector3 GetGroundPosition(float x, float z)
    {
        Vector3 rayStart = new Vector3(x, 500f, z);
        RaycastHit hit;
        if (Physics.Raycast(rayStart, Vector3.down, out hit, 1000f, groundLayer))
            return hit.point;
        return Vector3.zero; // Or return a point on player plane
    }

    private Vector2Int WorldToChunk(Vector3 worldPosition)
    {
        return new Vector2Int(
            Mathf.FloorToInt(worldPosition.x / chunkSize),
            Mathf.FloorToInt(worldPosition.z / chunkSize)
        );
    }

    [ContextMenu("Clear All Enemies")]
    public void ClearAllEnemies()
    {
        foreach (var chunk in chunks.Values)
        {
            foreach (GameObject obj in chunk.aliveEnemies)
            {
                if (obj != null)
                {
                    if (Application.isPlaying) Destroy(obj);
                    else DestroyImmediate(obj);
                }
            }
        }
        chunks.Clear();
        currentAliveCount = 0;
    }

    void OnDrawGizmosSelected()
    {
        if (playerTransform != null)
        {
            Gizmos.color = new Color(1, 0, 0, 0.15f);
            Gizmos.DrawWireSphere(playerTransform.position, spawnRadius);
        }
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(worldCenter, 2f);
    }
}
