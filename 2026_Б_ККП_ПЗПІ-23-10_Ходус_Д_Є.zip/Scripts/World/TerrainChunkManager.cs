using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TerrainChunkManager : MonoBehaviour, IInitializable
{
    [Header("Player Settings")]
    public Transform playerTransform;

    [Header("Chunk Settings")]
    public Terrain templateTerrain;
    [Tooltip("Distance from player to spawn new chunks.")]
    public float viewDistance = 1200f;
    [Tooltip("Distance from player to cleanup old chunks (should be larger than viewDistance).")]
    public float cleanupDistance = 1400f;
    [Tooltip("Interval in seconds to check player position.")]
    public float checkInterval = 0.5f;

    private float chunkSize = 1000f;
    private float gridOriginX;
    private float gridOriginZ;

    private Dictionary<Vector2Int, GameObject> activeChunks = new Dictionary<Vector2Int, GameObject>();
    private bool isRunning = false;
    private Transform chunkParent;
    private bool wasUnderground = false;

    public void Init()
    {
        if (playerTransform == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                playerTransform = player.transform;
            }
        }

        if (playerTransform == null)
        {
            Debug.LogError("❌ [TerrainChunkManager] Player not found! Cannot manage terrain chunks.");
            return;
        }

        if (templateTerrain == null)
        {
            // Find the active surface terrain in the scene
            Terrain[] terrains = FindObjectsOfType<Terrain>();
            foreach (Terrain t in terrains)
            {
                // Surface terrain has TerrainNoise and is at y = 0
                if (t.GetComponent<TerrainNoise>() != null && t.transform.position.y > -500f)
                {
                    templateTerrain = t;
                    break;
                }
            }
        }

        if (templateTerrain == null)
        {
            Debug.LogError("❌ [TerrainChunkManager] Template surface Terrain not found in scene!");
            return;
        }

        // Set up parent transform for generated terrain chunks
        GameObject parentObj = GameObject.Find("Generated Terrains");
        if (parentObj == null)
        {
            parentObj = new GameObject("Generated Terrains");
        }
        chunkParent = parentObj.transform;

        // Initialize grid sizes and origins based on the template terrain
        chunkSize = templateTerrain.terrainData.size.x;
        gridOriginX = templateTerrain.transform.position.x;
        gridOriginZ = templateTerrain.transform.position.z;

        // Register the template terrain as the (0,0) chunk
        activeChunks[Vector2Int.zero] = templateTerrain.gameObject;
        templateTerrain.transform.SetParent(chunkParent);

        // Ensure template terrain noise is generated
        TerrainNoise templateNoise = templateTerrain.GetComponent<TerrainNoise>();
        if (templateNoise != null && !TerrainNoise.OffsetsInitialized)
        {
            templateNoise.Init();
        }

        wasUnderground = playerTransform.position.y <= -500f;

        isRunning = true;
        StartCoroutine(ManageChunksCoroutine());
        Debug.Log($"✅ [TerrainChunkManager] Initialized for Surface Only. Chunk Size: {chunkSize}, Origin: ({gridOriginX}, {gridOriginZ})");
    }

    private IEnumerator ManageChunksCoroutine()
    {
        while (isRunning)
        {
            if (playerTransform != null)
            {
                bool isUnderground = playerTransform.position.y <= -500f;

                if (isUnderground)
                {
                    // If player went underground (dungeon), unload surface chunks to clear surface world
                    if (!wasUnderground)
                    {
                        UnloadAllSurfaceChunks();
                        wasUnderground = true;
                        Debug.Log("💤 [TerrainChunkManager] Player is underground. Pausing surface chunk generation.");
                    }
                }
                else
                {
                    // Player is on the surface, update/generate chunks
                    if (wasUnderground)
                    {
                        wasUnderground = false;
                        Debug.Log("⏰ [TerrainChunkManager] Player returned to surface. Resuming surface chunk generation.");
                    }
                    UpdateChunks();
                }
            }
            yield return new WaitForSeconds(checkInterval);
        }
    }

    private void UnloadAllSurfaceChunks()
    {
        List<Vector2Int> keys = new List<Vector2Int>(activeChunks.Keys);
        foreach (Vector2Int coord in keys)
        {
            if (coord == Vector2Int.zero) continue; // Keep original surface terrain template
            DestroyChunk(coord);
        }
        UpdateNeighbors();
    }

    private void UpdateChunks()
    {
        Vector3 playerPos = playerTransform.position;

        // Determine player's current grid position
        int playerGridX = Mathf.FloorToInt((playerPos.x - gridOriginX) / chunkSize);
        int playerGridZ = Mathf.FloorToInt((playerPos.z - gridOriginZ) / chunkSize);

        // Define search range based on view distance
        int range = Mathf.CeilToInt(viewDistance / chunkSize);
        List<Vector2Int> chunksToSpawn = new List<Vector2Int>();

        for (int x = -range; x <= range; x++)
        {
            for (int z = -range; z <= range; z++)
            {
                Vector2Int coord = new Vector2Int(playerGridX + x, playerGridZ + z);

                // Calculate center of this chunk
                Vector3 chunkCenter = new Vector3(
                    gridOriginX + coord.x * chunkSize + chunkSize / 2f,
                    templateTerrain.transform.position.y,
                    gridOriginZ + coord.y * chunkSize + chunkSize / 2f
                );

                // Calculate horizontal distance to player
                float distance = Vector2.Distance(new Vector2(playerPos.x, playerPos.z), new Vector2(chunkCenter.x, chunkCenter.z));

                if (distance <= viewDistance)
                {
                    if (!activeChunks.ContainsKey(coord))
                    {
                        chunksToSpawn.Add(coord);
                    }
                }
            }
        }

        // Spawn chunks sequentially to prevent frame rate drops
        if (chunksToSpawn.Count > 0)
        {
            StartCoroutine(SpawnChunksQueue(chunksToSpawn));
        }

        // Identify and clean up distant chunks
        List<Vector2Int> chunksToRemove = new List<Vector2Int>();
        foreach (var kvp in activeChunks)
        {
            Vector2Int coord = kvp.Key;
            // Never remove the starting (0, 0) chunk
            if (coord == Vector2Int.zero) continue;

            Vector3 chunkCenter = new Vector3(
                gridOriginX + coord.x * chunkSize + chunkSize / 2f,
                templateTerrain.transform.position.y,
                gridOriginZ + coord.y * chunkSize + chunkSize / 2f
            );

            float distance = Vector2.Distance(new Vector2(playerPos.x, playerPos.z), new Vector2(chunkCenter.x, chunkCenter.z));

            if (distance > cleanupDistance)
            {
                chunksToRemove.Add(coord);
            }
        }

        if (chunksToRemove.Count > 0)
        {
            foreach (Vector2Int coord in chunksToRemove)
            {
                DestroyChunk(coord);
            }
            UpdateNeighbors();
        }
    }

    private IEnumerator SpawnChunksQueue(List<Vector2Int> coords)
    {
        foreach (Vector2Int coord in coords)
        {
            // Re-verify that it wasn't spawned already
            if (!activeChunks.ContainsKey(coord))
            {
                SpawnChunk(coord);
                yield return null; // Wait 1 frame before spawning the next chunk to keep gameplay smooth
            }
        }
        UpdateNeighbors();
    }

    private void SpawnChunk(Vector2Int coord)
    {
        // 1. Instantiate the template terrain
        GameObject chunkObj = Instantiate(templateTerrain.gameObject);
        chunkObj.name = $"Terrain_Chunk_{coord.x}_{coord.y}";
        chunkObj.transform.SetParent(chunkParent);

        // 2. Set the position of the new chunk
        float worldX = gridOriginX + coord.x * chunkSize;
        float worldZ = gridOriginZ + coord.y * chunkSize;
        chunkObj.transform.position = new Vector3(worldX, templateTerrain.transform.position.y, worldZ);

        // 3. IMPORTANT: Instantiate TerrainData asset to make a unique, non-shared copy of heightmap
        Terrain terrain = chunkObj.GetComponent<Terrain>();
        terrain.terrainData = Instantiate(terrain.terrainData);

        // 4. Update the TerrainCollider with the new unique TerrainData
        TerrainCollider collider = chunkObj.GetComponent<TerrainCollider>();
        if (collider != null)
        {
            collider.terrainData = terrain.terrainData;
        }

        // 5. Generate matching seamless noise based on integer grid coordinates
        TerrainNoise noise = chunkObj.GetComponent<TerrainNoise>();
        if (noise != null)
        {
            noise.InitWithGridCoordinates(coord.x, coord.y);
        }

        activeChunks[coord] = chunkObj;
        Debug.Log($"🌲 [TerrainChunkManager] Spawned surface chunk {coord}");
    }

    private void DestroyChunk(Vector2Int coord)
    {
        if (activeChunks.TryGetValue(coord, out GameObject chunkObj))
        {
            if (chunkObj != null)
            {
                // Clean up dynamic TerrainData to prevent memory and asset leaks in Unity
                Terrain terrain = chunkObj.GetComponent<Terrain>();
                if (terrain != null && terrain.terrainData != null)
                {
                    Destroy(terrain.terrainData);
                }
                Destroy(chunkObj);
            }
            activeChunks.Remove(coord);
            Debug.Log($"🗑️ [TerrainChunkManager] Destroyed chunk {coord}");
        }
    }

    private void UpdateNeighbors()
    {
        foreach (var kvp in activeChunks)
        {
            Vector2Int coord = kvp.Key;
            Terrain terrain = kvp.Value.GetComponent<Terrain>();
            if (terrain == null) continue;

            Terrain left = GetActiveTerrain(coord + new Vector2Int(-1, 0));
            Terrain right = GetActiveTerrain(coord + new Vector2Int(1, 0));
            Terrain top = GetActiveTerrain(coord + new Vector2Int(0, 1));
            Terrain bottom = GetActiveTerrain(coord + new Vector2Int(0, -1));

            // Set neighbors: Left (-X), Top (+Z), Right (+X), Bottom (-Z)
            terrain.SetNeighbors(left, top, right, bottom);
            
            // Force Unity to immediately rebuild boundary LOD meshes and physics colliders
            terrain.Flush();
        }
    }

    private Terrain GetActiveTerrain(Vector2Int coord)
    {
        if (activeChunks.TryGetValue(coord, out GameObject obj))
        {
            if (obj != null)
            {
                return obj.GetComponent<Terrain>();
            }
        }
        return null;
    }

    private void OnDestroy()
    {
        isRunning = false;
        // Clean up instantiated terrain data of all generated chunks on exit
        foreach (var kvp in activeChunks)
        {
            if (kvp.Key == Vector2Int.zero) continue; // Don't destroy original template's data
            if (kvp.Value != null)
            {
                Terrain terrain = kvp.Value.GetComponent<Terrain>();
                if (terrain != null && terrain.terrainData != null)
                {
                    Destroy(terrain.terrainData);
                }
            }
        }
    }
}
