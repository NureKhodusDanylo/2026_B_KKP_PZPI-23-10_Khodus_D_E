using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// --- Example Usage (e.g., in a MonoBehaviour) ---
public class ColorTester : MonoBehaviour
{
    public float speed = 0.4f; // Default value from your "X -0.4" which seems to be for Speed
    public float ringDensity = 5.0f; // Example value, adjust as needed
    public Transform objectToColor; // Assign an object in the inspector

    void Update()
    {
        if (objectToColor != null)
        {
            // Get world coordinates of the object
            float worldX = objectToColor.position.x;
            float worldZ = objectToColor.position.z;

            // Get current time
            float currentTime = -0.41f;

            // Calculate the color
            Color calculatedColor = ShaderColorCalculator.GetColorAtWorldPosition(
                worldX,
                worldZ,
                currentTime,
                speed,
                ringDensity
            );

            // Apply it (e.g., to a material, a light, or log it)
            // For example, if the object has a Renderer and Material:
            Renderer rend = objectToColor.GetComponent<Renderer>();
            if (rend != null && rend.material != null)
            {
                // Note: This will change the shared material if you don't instance it.
                // For testing, it's okay. For unique colors per object, use rend.material (creates instance).
                rend.sharedMaterial.color = calculatedColor;
            }
        }
    }

    // Example of how to use it for a specific point:
    void Start()
    {
        // Test with specific coordinates and parameters
        float testWorldX = 0.5f;
        float testWorldZ = 0.5f;
        float testTime = 0f;
        float testSpeed = 0.1f;
        float testRingDensity = 10f;

        Color colorAtPoint = ShaderColorCalculator.GetColorAtWorldPosition(
            testWorldX, testWorldZ, testTime, testSpeed, testRingDensity
        );
        Debug.Log($"Test color at ({testWorldX},{testWorldZ}) with T={testTime}, Spd={testSpeed}, Dens={testRingDensity}: {colorAtPoint}");
        // At (0.5, 0.5), dist is 0, animated = -time*speed. hue = frac(-time*speed*0.1)

        testWorldX = 1.0f;
        testWorldZ = 0.5f;
        colorAtPoint = ShaderColorCalculator.GetColorAtWorldPosition(
            testWorldX, testWorldZ, testTime, testSpeed, testRingDensity
        );
        Debug.Log($"Test color at ({testWorldX},{testWorldZ}) with T={testTime}, Spd={testSpeed}, Dens={testRingDensity}: {colorAtPoint}");
        // At (1.0, 0.5), centeredUV = (0.5, 0), dist = 0.5. animated = 0.5*RingDensity - Time*Speed.
    }
}
