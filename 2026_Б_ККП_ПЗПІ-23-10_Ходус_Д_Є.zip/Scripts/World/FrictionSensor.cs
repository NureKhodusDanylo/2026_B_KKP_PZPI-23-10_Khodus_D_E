using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrictionSensor : MonoBehaviour
{
    public float damagePerHit = 10f;             
    public float maxDamage = 100f;                
    public float minVelocity = 5f;                
    public float frictionThreshold = 0.5f;        

    private float accumulatedDamage = 0f;
    private Rigidbody rb;

    [SerializeField] Collider Collider;

    public event Action<GameObject> OnDestroy;


    private bool active;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void OnEnable()
    {
        active = false;

        //float delay = transform.localScale.x * 0.0f;
        Invoke("EnableFriction", 0.3f);
    }

    public void EnableFriction()
    {
        active = true;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (!active) return;

        var material = collision.collider.sharedMaterial;

        float speed = rb.velocity.magnitude;
        if (speed >= minVelocity)
        {
            accumulatedDamage += damagePerHit;

            if (accumulatedDamage >= maxDamage)
            {
                Destroy();
            }
        }
    }

    public void Destroy()
    {
        var children = new List<Transform>();
        foreach (Transform ch in gameObject.transform)
        {
            children.Add(ch);
        }

        foreach (var ch in children)
        {
            if (ch.name != "Components")
                //PoolManager.Instanse.ReturnObject(ch.gameObject);
                ch.transform.SetParent(null);
        }

        PoolManager.Instanse.ReturnObject(gameObject);
        OnDestroy?.Invoke(gameObject);
    }
}

