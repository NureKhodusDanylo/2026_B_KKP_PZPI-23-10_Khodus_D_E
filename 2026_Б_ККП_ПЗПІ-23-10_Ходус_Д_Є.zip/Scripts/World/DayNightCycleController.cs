using UnityEngine;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace MagicUniverse.World
{
    [ExecuteAlways]
    public class DayNightCycleController : MonoBehaviour
    {
        [Header("Time Settings")]
        [Range(0f, 24f)]
        [Tooltip("Current hour of the day (0 to 24)")]
        public float timeOfDay = 12f;

        [Tooltip("How long a full day-night cycle lasts in real-world seconds")]
        public float dayDurationInSeconds = 120f;

        [Tooltip("Is time currently flowing?")]
        public bool isTimeFlowing = true;

        [Header("Sun Settings")]
        [Tooltip("Primary Directional Light representing the Sun")]
        public Light sunLight;
        public Gradient sunColor;
        public AnimationCurve sunIntensity;
        [Range(0f, 2f)]
        public float sunIntensityMultiplier = 0.55f; // Softened day brightness
        [Tooltip("Yaw (horizontal angle) of the sun's trajectory")]
        public float sunYaw = 45f;

        [Header("Moon Settings")]
        [Tooltip("Secondary Directional Light representing the Moon")]
        public Light moonLight;
        public Gradient moonColor;
        public AnimationCurve moonIntensity;
        [Tooltip("Yaw (horizontal angle) of the moon's trajectory")]
        public float moonYaw = 225f;

        [Header("Ambient Settings")]
        public Gradient ambientColor;
        public AnimationCurve ambientIntensityMultiplier;
        [Range(0f, 2f)]
        public float ambientIntensityMultiplierVal = 0.7f; // Soft shadows premium default

        [Header("Variable Fog Settings")]
        public bool enableFogControl = true;
        public Gradient fogColorGradient;
        public AnimationCurve baseFogDensity;
        [Range(0f, 2f)]
        public float fogDensityMultiplier = 1.0f; // Increased default multiplier for beautiful, visible fog
        [Range(0f, 1f)]
        public float fogDriftSpeed = 0.08f;
        [Range(0f, 0.05f)]
        public float fogDriftScale = 0.006f;

        [System.Serializable]
        public struct SkyboxPreset
        {
            public string name;
            public float hour;
            [Tooltip("Front (+Z)")] public Texture2D front;
            [Tooltip("Back (-Z)")] public Texture2D back;
            [Tooltip("Left (+X)")] public Texture2D left;
            [Tooltip("Right (-X)")] public Texture2D right;
            [Tooltip("Up (+Y)")] public Texture2D up;
            [Tooltip("Down (-Y)")] public Texture2D down;
        }

        [Header("Skybox presets")]
        public SkyboxPreset[] skyboxPresets;
        [Range(0f, 4f)]
        public float skyboxExposure = 1.0f;
        [Tooltip("Dynamic skybox exposure curve based on time of day")]
        public AnimationCurve skyboxExposureCurve;
        [Tooltip("Dynamic skybox tint color gradient")]
        public Gradient skyboxTint;

        [Header("Performance Optimization")]
        [Tooltip("Time interval in seconds between updating dynamic Global Illumination / Reflections")]
        public float giUpdateInterval = 0.4f;

        private Material runtimeMaterial;
        private int lastCurrentIdx = -1;
        private int lastNextIdx = -1;
        private float lastGIUpdateTime = 0f;

        private void Start()
        {
            InitializeMaterial();
            UpdateCycle();
        }

        private void OnValidate()
        {
            if (skyboxExposureCurve == null || skyboxExposureCurve.length == 0)
            {
                skyboxExposureCurve = new AnimationCurve(
                    new Keyframe(0f, 0.8f),       // Midnight
                    new Keyframe(0.25f, 1.1f),     // Dawn
                    new Keyframe(0.5f, 1.8f),      // Noon (Makes LDR textures glow beautifully!)
                    new Keyframe(0.8f, 1.1f),      // Sunset
                    new Keyframe(1f, 0.8f)        // Midnight
                );
            }

            if (skyboxTint == null || skyboxTint.colorKeys == null || skyboxTint.colorKeys.Length == 0)
            {
                GradientColorKey[] tintColors = new GradientColorKey[] {
                    new GradientColorKey(new Color(0.2f, 0.15f, 0.35f), 0f),       // Midnight
                    new GradientColorKey(new Color(0.7f, 0.3f, 0.5f), 0.25f),      // Dawn
                    new GradientColorKey(new Color(0.44f, 0.18f, 0.72f), 0.5f),     // Noon
                    new GradientColorKey(new Color(0.7f, 0.3f, 0.5f), 0.75f),      // Sunset
                    new GradientColorKey(new Color(0.2f, 0.15f, 0.35f), 1f)        // Midnight
                };
                GradientAlphaKey[] tintAlphas = new GradientAlphaKey[] {
                    new GradientAlphaKey(1f, 0f),
                    new GradientAlphaKey(1f, 1f)
                };
                skyboxTint = new Gradient();
                skyboxTint.SetKeys(tintColors, tintAlphas);
            }
        }

        public static bool IsInDungeon = false;

        private void Update()
        {
            if (Application.isPlaying && IsInDungeon)
            {
                if (sunLight != null && sunLight.enabled) sunLight.enabled = false;
                if (moonLight != null && moonLight.enabled) moonLight.enabled = false;
                RenderSettings.fog = false;
                RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
                RenderSettings.ambientLight = new Color(0.12f, 0.10f, 0.18f);
                return;
            }

            if (Application.isPlaying && isTimeFlowing)
            {
                // Advance time based on deltaTime
                timeOfDay += (Time.deltaTime / dayDurationInSeconds) * 24f;
                if (timeOfDay >= 24f)
                {
                    timeOfDay -= 24f;
                }
            }

            UpdateCycle();
        }

        private void InitializeMaterial()
        {
            if (runtimeMaterial == null)
            {
                Shader blendShader = Shader.Find("Skybox/Blended 6 Sided");
                if (blendShader != null)
                {
                    runtimeMaterial = new Material(blendShader);
                    runtimeMaterial.name = "SkyboxBlenderRuntime";
                }
                else
                {
                    Debug.LogWarning("Could not find 'Skybox/Blended 6 Sided' shader! Make sure the shader is compiled and in the project.");
                }
            }

            if (runtimeMaterial != null && RenderSettings.skybox != runtimeMaterial)
            {
                RenderSettings.skybox = runtimeMaterial;
            }
        }

        public void UpdateCycle()
        {
            float timeFactor = timeOfDay / 24f;

            // 1. Update Directional Lights (Sun and Moon)
            UpdateLights(timeFactor);

            // 2. Update Ambient Lighting
            UpdateAmbient(timeFactor);

            // 3. Update Skybox
            UpdateSkybox();

            // 4. Update Fog Settings
            if (enableFogControl)
            {
                UpdateFog(timeFactor);
            }

            // 5. Update GI reflection probes periodically
            if (Application.isPlaying && Time.time - lastGIUpdateTime > giUpdateInterval)
            {
                DynamicGI.UpdateEnvironment();
                lastGIUpdateTime = Time.time;
            }
        }

        private void UpdateLights(float timeFactor)
        {
            // Auto-find lights if null
            if (sunLight == null || moonLight == null)
            {
                FindLightsInScene();
            }

            // Sun rotation: East (0 at 6 AM) to West (180 at 6 PM)
            // At 6 AM (hour = 6), angle should be 0.
            // Formula: sunAngle = ((hour - 6) / 24) * 360
            float sunAngle = ((timeOfDay - 6f) / 24f) * 360f;
            
            if (sunLight != null)
            {
                sunLight.transform.rotation = Quaternion.Euler(sunAngle, sunYaw, 0f);
                Color sunColorVal = sunColor.Evaluate(timeFactor);
                
                // Warm, soft golden sun tint to contrast beautifully with the purple sky
                Color warmSun = new Color(1.0f, 0.92f, 0.82f);
                sunColorVal = Color.Lerp(sunColorVal, warmSun, 0.6f);
                
                sunLight.color = sunColorVal;
                sunLight.intensity = sunIntensity.Evaluate(timeFactor) * sunIntensityMultiplier;
                
                // Toggle shadows and active state to prevent underground lighting artifacts
                bool sunActive = (sunIntensity.Evaluate(timeFactor) * sunIntensityMultiplier) > 0.01f;
                sunLight.enabled = sunActive;
            }

            // Moon rotation is opposite to the Sun
            if (moonLight != null)
            {
                float moonAngle = sunAngle + 180f;
                moonLight.transform.rotation = Quaternion.Euler(moonAngle, moonYaw, 0f);
                moonLight.color = moonColor.Evaluate(timeFactor);
                moonLight.intensity = moonIntensity.Evaluate(timeFactor) * 1.3f; // Brighter moon light for night readability
                
                bool moonActive = (moonIntensity.Evaluate(timeFactor) * 1.3f) > 0.01f;
                moonLight.enabled = moonActive;
            }
        }

        private Color GetCosmicSkyTint(float timeFactor)
        {
            if (timeFactor < 0.25f)
            {
                float t = timeFactor / 0.25f;
                return Color.Lerp(new Color(0.05f, 0.04f, 0.18f), new Color(0.48f, 0.15f, 0.78f), t); // Night -> Dawn
            }
            else if (timeFactor < 0.5f)
            {
                float t = (timeFactor - 0.25f) / 0.25f;
                return Color.Lerp(new Color(0.48f, 0.15f, 0.78f), new Color(0.0f, 0.78f, 1.0f), t); // Dawn -> Noon
            }
            else if (timeFactor < 0.75f)
            {
                float t = (timeFactor - 0.5f) / 0.25f;
                return Color.Lerp(new Color(0.0f, 0.78f, 1.0f), new Color(0.42f, 0.1f, 0.7f), t); // Noon -> Sunset
            }
            else
            {
                float t = (timeFactor - 0.75f) / 0.25f;
                return Color.Lerp(new Color(0.42f, 0.1f, 0.7f), new Color(0.05f, 0.04f, 0.18f), t); // Sunset -> Night
            }
        }

        private Color GetCosmicAmbientColor(float timeFactor)
        {
            if (timeFactor < 0.25f)
            {
                float t = timeFactor / 0.25f;
                return Color.Lerp(new Color(0.12f, 0.12f, 0.28f), new Color(0.48f, 0.12f, 0.6f), t); // Brightened midnight ambient color
            }
            else if (timeFactor < 0.5f)
            {
                float t = (timeFactor - 0.25f) / 0.25f;
                return Color.Lerp(new Color(0.48f, 0.12f, 0.6f), new Color(0.34f, 0.22f, 0.65f), t);
            }
            else if (timeFactor < 0.75f)
            {
                float t = (timeFactor - 0.5f) / 0.25f;
                return Color.Lerp(new Color(0.34f, 0.22f, 0.65f), new Color(0.38f, 0.1f, 0.55f), t);
            }
            else
            {
                float t = (timeFactor - 0.75f) / 0.25f;
                return Color.Lerp(new Color(0.38f, 0.1f, 0.55f), new Color(0.12f, 0.12f, 0.28f), t); // Brightened midnight ambient color
            }
        }

        private Color GetCosmicFogColor(float timeFactor)
        {
            if (timeFactor < 0.25f)
            {
                float t = timeFactor / 0.25f;
                return Color.Lerp(new Color(0.06f, 0.03f, 0.14f), new Color(0.94f, 0.45f, 0.42f), t); // Night -> Sunrise Pink-Magenta
            }
            else if (timeFactor < 0.5f)
            {
                float t = (timeFactor - 0.25f) / 0.25f;
                return Color.Lerp(new Color(0.94f, 0.45f, 0.42f), new Color(0.85f, 0.93f, 0.65f), t); // Sunrise -> Midday Soft Pastel Yellow-Lime
            }
            else if (timeFactor < 0.75f)
            {
                float t = (timeFactor - 0.5f) / 0.25f;
                return Color.Lerp(new Color(0.85f, 0.93f, 0.65f), new Color(0.88f, 0.3f, 0.58f), t); // Midday -> Sunset Pink-Magenta
            }
            else
            {
                float t = (timeFactor - 0.75f) / 0.25f;
                return Color.Lerp(new Color(0.88f, 0.3f, 0.58f), new Color(0.06f, 0.03f, 0.14f), t); // Sunset -> Night
            }
        }

        private void UpdateAmbient(float timeFactor)
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            
            // Programmatically interpolate gorgeous cosmic ambient sky color
            Color skyAmb = GetCosmicAmbientColor(timeFactor);
            
            // Derive beautiful equatorial and ground colors from the ambient sky color
            // Lower multipliers to ensure rich, deep shadows instead of washing out the scene
            Color equatorAmb = Color.Lerp(skyAmb, new Color(0.5f, 0.08f, 0.38f), 0.5f); // Rich, darker magenta-purple equator
            Color groundAmb = Color.Lerp(equatorAmb, new Color(0.1f, 0.02f, 0.2f), 0.6f); // Deep, dark, rich violet-purple ground shadows
 
            RenderSettings.ambientSkyColor = skyAmb * 0.75f; // Scale down ambient sky to ensure nice shading contrast
            RenderSettings.ambientEquatorColor = equatorAmb * 0.75f;
            RenderSettings.ambientGroundColor = groundAmb * 0.75f;
            RenderSettings.ambientIntensity = ambientIntensityMultiplier.Evaluate(timeFactor) * ambientIntensityMultiplierVal;
        }

        private void UpdateSkybox()
        {
            if (skyboxPresets == null || skyboxPresets.Length < 2)
            {
                return;
            }

            InitializeMaterial();
            if (runtimeMaterial == null) return;

            // Find current and next presets based on timeOfDay
            int currentIdx = 0;
            for (int i = 0; i < skyboxPresets.Length; i++)
            {
                if (timeOfDay >= skyboxPresets[i].hour)
                {
                    currentIdx = i;
                }
            }

            int nextIdx = (currentIdx + 1) % skyboxPresets.Length;

            float currentHour = skyboxPresets[currentIdx].hour;
            float nextHour = skyboxPresets[nextIdx].hour;

            if (nextHour < currentHour)
            {
                nextHour += 24f;
            }

            float t = timeOfDay;
            if (t < currentHour)
            {
                t += 24f;
            }

            float blend = 0f;
            float duration = nextHour - currentHour;
            if (duration > 0f)
            {
                blend = (t - currentHour) / duration;
            }

            // Assign textures only if the active slot indices changed
            if (currentIdx != lastCurrentIdx || nextIdx != lastNextIdx)
            {
                SkyboxPreset currentPreset = skyboxPresets[currentIdx];
                SkyboxPreset nextPreset = skyboxPresets[nextIdx];

                runtimeMaterial.SetTexture("_FrontTex", currentPreset.front);
                runtimeMaterial.SetTexture("_BackTex", currentPreset.back);
                runtimeMaterial.SetTexture("_LeftTex", currentPreset.left);
                runtimeMaterial.SetTexture("_RightTex", currentPreset.right);
                runtimeMaterial.SetTexture("_UpTex", currentPreset.up);
                runtimeMaterial.SetTexture("_DownTex", currentPreset.down);

                runtimeMaterial.SetTexture("_FrontTex2", nextPreset.front);
                runtimeMaterial.SetTexture("_BackTex2", nextPreset.back);
                runtimeMaterial.SetTexture("_LeftTex2", nextPreset.left);
                runtimeMaterial.SetTexture("_RightTex2", nextPreset.right);
                runtimeMaterial.SetTexture("_UpTex2", nextPreset.up);
                runtimeMaterial.SetTexture("_DownTex2", nextPreset.down);

                lastCurrentIdx = currentIdx;
                lastNextIdx = nextIdx;
            }

            runtimeMaterial.SetFloat("_Blend", blend);
            
            // Programmatically tint the skybox using a dynamic cosmic color palette
            Color tintColor = GetCosmicSkyTint(timeOfDay / 24f);
            runtimeMaterial.SetColor("_Tint", tintColor);
            
            float exp = skyboxExposure;
            if (skyboxExposureCurve != null && skyboxExposureCurve.length > 0)
            {
                exp *= skyboxExposureCurve.Evaluate(timeOfDay / 24f);
            }
            runtimeMaterial.SetFloat("_Exposure", exp * 1.35f); // Breathtaking and vibrant cosmic skybox visible even under heavy fog
        }

        private void UpdateFog(float timeFactor)
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            
            // Programmatically interpolate gorgeous cosmic fog color
            Color fogColor = GetCosmicFogColor(timeFactor);
            RenderSettings.fogColor = fogColor;

            // Highly visible dynamic fog - pulled closer to wrap the terrain beautifully
            float sinTime = Mathf.Sin(timeFactor * Mathf.PI);
            float multiplier = Mathf.Clamp(fogDensityMultiplier, 0.05f, 3.0f);
            RenderSettings.fogStartDistance = Mathf.Lerp(12f, 35f, sinTime) / multiplier;
            RenderSettings.fogEndDistance = Mathf.Lerp(65f, 160f, sinTime) / multiplier;
        }

        private void FindLightsInScene()
        {
            Light[] lights = Object.FindObjectsOfType<Light>();
            foreach (Light l in lights)
            {
                if (l.type == LightType.Directional)
                {
                    if (sunLight == null)
                    {
                        sunLight = l;
                    }
                    else if (moonLight == null && l != sunLight)
                    {
                        moonLight = l;
                    }
                }
            }

            // Create lights if still missing
            if (sunLight == null)
            {
                GameObject sunObj = new GameObject("Sun Light (Dynamic)");
                sunLight = sunObj.AddComponent<Light>();
                sunLight.type = LightType.Directional;
                sunObj.transform.parent = transform;
            }

            if (moonLight == null)
            {
                GameObject moonObj = new GameObject("Moon Light (Dynamic)");
                moonLight = moonObj.AddComponent<Light>();
                moonLight.type = LightType.Directional;
                moonObj.transform.parent = transform;
            }
        }

        private void OnDestroy()
        {
            // Restore standard skybox if runtime material is destroyed to prevent pink sky artifacts
            if (runtimeMaterial != null)
            {
                if (RenderSettings.skybox == runtimeMaterial)
                {
                    RenderSettings.skybox = null;
                }
                DestroyImmediate(runtimeMaterial);
            }
        }

        private void Reset()
        {
            // Initialize beautiful dynamic lighting profiles automatically!
            
            // 1. Sun Color Gradient (golden dawn, white noon, orange sunset, indigo dusk)
            GradientColorKey[] sunColors = new GradientColorKey[] {
                new GradientColorKey(new Color(0.1f, 0.05f, 0.1f), 0f),       // Midnight
                new GradientColorKey(new Color(0.95f, 0.55f, 0.2f), 0.22f),    // Sunrise (5.28h)
                new GradientColorKey(new Color(1f, 0.96f, 0.88f), 0.35f),     // Morning (8.4h)
                new GradientColorKey(new Color(1f, 1f, 1f), 0.5f),            // Noon
                new GradientColorKey(new Color(1f, 0.93f, 0.8f), 0.65f),      // Afternoon
                new GradientColorKey(new Color(0.96f, 0.42f, 0.15f), 0.78f),   // Sunset (18.72h)
                new GradientColorKey(new Color(0.35f, 0.2f, 0.45f), 0.85f),   // Dusk (20.4h)
                new GradientColorKey(new Color(0.1f, 0.05f, 0.1f), 1f)        // Midnight
            };
            GradientAlphaKey[] sunAlphas = new GradientAlphaKey[] {
                new GradientAlphaKey(1f, 0f),
                new GradientAlphaKey(1f, 1f)
            };
            sunColor = new Gradient();
            sunColor.SetKeys(sunColors, sunAlphas);

            // Sun Intensity Curve
            sunIntensity = new AnimationCurve(
                new Keyframe(0f, 0f),
                new Keyframe(0.2f, 0f),
                new Keyframe(0.26f, 0.6f),
                new Keyframe(0.5f, 1.4f), // Golden sun strength
                new Keyframe(0.74f, 1.0f),
                new Keyframe(0.8f, 0.3f),
                new Keyframe(0.85f, 0f),
                new Keyframe(1f, 0f)
            );

            // 2. Moon Color Gradient (cool pale blue-silver light)
            GradientColorKey[] moonColors = new GradientColorKey[] {
                new GradientColorKey(new Color(0.6f, 0.75f, 0.95f), 0f),      // Soft silver-blue
                new GradientColorKey(new Color(0.6f, 0.75f, 0.95f), 1f)
            };
            moonColor = new Gradient();
            moonColor.SetKeys(moonColors, sunAlphas);

            // Moon Intensity Curve
            moonIntensity = new AnimationCurve(
                new Keyframe(0f, 0.45f),       // Midnight peak
                new Keyframe(0.18f, 0.45f),    // Late night
                new Keyframe(0.25f, 0f),       // Fade at dawn
                new Keyframe(0.78f, 0f),       // Inactive daytime
                new Keyframe(0.85f, 0.45f),     // Rise at dusk
                new Keyframe(1f, 0.45f)
            );

            // 3. Ambient Color Gradient (highly realistic environmental skylight coloring)
            GradientColorKey[] ambColors = new GradientColorKey[] {
                new GradientColorKey(new Color(0.08f, 0.09f, 0.14f), 0f),     // Midnight (cool shadows)
                new GradientColorKey(new Color(0.65f, 0.45f, 0.42f), 0.22f),   // Dawn (warm sky wash)
                new GradientColorKey(new Color(0.65f, 0.72f, 0.85f), 0.4f),    // Midday sky light (clear skies)
                new GradientColorKey(new Color(0.65f, 0.72f, 0.85f), 0.65f),
                new GradientColorKey(new Color(0.58f, 0.35f, 0.48f), 0.78f),   // Sunset orange-purple tint
                new GradientColorKey(new Color(0.08f, 0.09f, 0.14f), 1f)
            };
            ambientColor = new Gradient();
            ambientColor.SetKeys(ambColors, sunAlphas);

            ambientIntensityMultiplier = new AnimationCurve(
                new Keyframe(0f, 0.4f),        // Moonlight ambient level
                new Keyframe(0.2f, 0.4f),
                new Keyframe(0.35f, 1.0f),     // Midday high ambient
                new Keyframe(0.65f, 1.0f),
                new Keyframe(0.8f, 0.6f),      // sunset twilight ambient
                new Keyframe(1f, 0.4f)
            );

            // 4. Beautiful dynamic fog colors (fog coordinates with day/night)
            GradientColorKey[] fogColors = new GradientColorKey[] {
                new GradientColorKey(new Color(0.02f, 0.02f, 0.05f), 0f),     // Deep dark navy midnight
                new GradientColorKey(new Color(0.85f, 0.52f, 0.3f), 0.22f),    // Radiant orange sunrise mist
                new GradientColorKey(new Color(0.52f, 0.64f, 0.78f), 0.4f),    // Airy daylight mist
                new GradientColorKey(new Color(0.52f, 0.64f, 0.78f), 0.65f),
                new GradientColorKey(new Color(0.62f, 0.3f, 0.28f), 0.78f),    // Sunset warm glow mist
                new GradientColorKey(new Color(0.1f, 0.06f, 0.14f), 0.85f),    // Dusk purple mist
                new GradientColorKey(new Color(0.02f, 0.02f, 0.05f), 1f)
            };
            fogColorGradient = new Gradient();
            fogColorGradient.SetKeys(fogColors, sunAlphas);

            // Thick morning mist, clearing to clean day, then heavy dusk mist
            baseFogDensity = new AnimationCurve(
                new Keyframe(0f, 0.012f),      // Quiet night fog
                new Keyframe(0.22f, 0.024f),    // Thick, rolling morning mist
                new Keyframe(0.4f, 0.006f),     // High midday visibility
                new Keyframe(0.7f, 0.006f),
                new Keyframe(0.78f, 0.016f),    // Evening condensation
                new Keyframe(1f, 0.012f)
            );

            // Dynamic skybox exposure curve (bright skies at day, subtle rich skies at night)
            skyboxExposureCurve = new AnimationCurve(
                new Keyframe(0f, 0.8f),       // Midnight
                new Keyframe(0.25f, 1.1f),     // Dawn
                new Keyframe(0.5f, 1.8f),      // Noon (Makes the LDR skybox pop!)
                new Keyframe(0.8f, 1.1f),      // Sunset
                new Keyframe(1f, 0.8f)        // Midnight
            );
            skyboxExposure = 1.0f;

            // Try to find skybox textures automatically when first added in Editor!
            #if UNITY_EDITOR
            AutoFindSkyboxTextures();
            #endif
        }

        #if UNITY_EDITOR
        [ContextMenu("Auto Find Skybox Textures")]
        public void AutoFindSkyboxTextures()
        {
            string[] prefixes = new string[] {
                "SkyMidNight", "SkyMorning", "SkyBrightMorning", "SkyNoon", "SkyAfterNoon", "SkySunSet", "SkyEarlyDusk", "SkyNight"
            };
            float[] hours = new float[] {
                0f, 6f, 9f, 12f, 15f, 18f, 20f, 22f
            };
            
            skyboxPresets = new SkyboxPreset[8];
            for (int i = 0; i < 8; i++)
            {
                skyboxPresets[i] = new SkyboxPreset
                {
                    name = prefixes[i],
                    hour = hours[i]
                };
                
                string folderPath = "Assets/Day-Night Skyboxes/Textures/";
                
                // Read texture assets
                skyboxPresets[i].front = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Front.png");
                skyboxPresets[i].back = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Back.png");
                skyboxPresets[i].left = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Left.png");
                skyboxPresets[i].right = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Right.png");
                skyboxPresets[i].up = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Top.png");
                skyboxPresets[i].down = AssetDatabase.LoadAssetAtPath<Texture2D>(folderPath + prefixes[i] + "_Bottom.png");
            }
            
            Debug.Log("MagicUniverse Day-Night Cycle: Automatically loaded all 8 custom skybox texture presets from project assets!");
        }
        #endif
    }
}
