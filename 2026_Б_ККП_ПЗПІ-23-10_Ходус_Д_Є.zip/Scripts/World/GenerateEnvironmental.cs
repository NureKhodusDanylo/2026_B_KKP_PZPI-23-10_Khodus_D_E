using System.Collections.Generic;
using UnityEngine;
using System.Collections;

public class GenerateEnvironmental : MonoBehaviour, IInitializable
{
    [Header("===== ОБ'ЄКТИ ДЛЯ ГЕНЕРАЦІЇ =====")]
    public List<GameObject> EnvironmentalObjects = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsRed = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsOrange = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsYellow = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsGreen = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsLightBlue = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsBlue = new List<GameObject>();
    public List<GameObject> EnvironmentalObjectsPurple = new List<GameObject>();

    [Header("===== НАЛАШТУВАННЯ ГЕНЕРАЦІЇ =====")]
    [Range(30f, 250f)]
    public float generationRadius = 80f;

    public LayerMask groundLayer = ~0;

    [Range(0.1f, 2f)]
    public float density = 0.6f;

    [Range(20f, 80f)]
    public float chunkSize = 40f;

    [Header("===== НАЛАШТУВАННЯ ШВИДКОСТІ =====")]
    [Range(10, 1000)]
    public int objectsPerFrame = 50;

    [Range(0.05f, 0.5f)]
    public float updateInterval = 0.15f;

    [Header("===== НАЛАШТУВАННЯ ОБ'ЄКТІВ =====")]
    public bool useRandomScale = true;
    [Range(0.3f, 5f)]
    public float minScale = 0.7f;
    [Range(0.3f, 5f)]
    public float maxScale = 1.3f;

    public bool useRandomRotation = true;

    public bool avoidOverlapping = true;
    [Range(0.5f, 10f)]
    public float minDistanceBetweenObjects = 1.5f;

    [Header("===== ПОСИЛАННЯ =====")]
    public Transform playerTransform;

    [Header("===== ІСКЛЮЧЕННЯ ОБЛАСТІ =====")]
    public List<Transform> exclusionZones = new List<Transform>();
    [Range(0f, 50f)]
    public float exclusionRadius = 5f;

    [Header("===== ТРАВА (АДОН) =====")]
    public bool generateGrass = true;
    [Range(0.1f, 10f)]
    public float grassDensity = 2.0f;
    public GrassComputeScript grassAddon;
    public SO_GrassSettings grassSettings;

    [Header("===== НАЛАШТУВАННЯ КОЛЬОРУ (ДЛЯ ТРАВИ) =====")]
    public float time = 0f;
    public float speed = 1f;
    public float ringDensity = 0.1f;

    [Header("===== НАЛАШТУВАННЯ ШУМУ ТРАВИ =====")]
    public bool useGrassNoise = true;
    [Range(0.01f, 1f)]
    public float grassNoiseScale = 0.15f;
    [Range(0f, 1f)]
    public float grassNoiseCutoff = 0.4f;
    [Range(0f, 1f)]
    public float grassNoiseThreshold = 0.5f;

    [Header("===== ПАРАМЕТРИ ТРАВИ =====")]
    [Range(0.1f, 5f)]
    public float grassMinScale = 0.8f;
    [Range(0.1f, 5f)]
    public float grassMaxScale = 1.2f;
    [Range(0f, 1f)]
    public float grassColorBlend = 0.8f;

    // Системи зберігання
    private Dictionary<Vector2Int, ChunkData> chunks = new Dictionary<Vector2Int, ChunkData>();
    private Transform parentObject;
    private Vector3 lastPlayerPosition;
    private bool isGenerating = false;
    private Queue<Vector2Int> generationQueue = new Queue<Vector2Int>();
    private Vector2 noiseOffset;
    private bool grassNeedsUpdate = false;
    private Vector3 lastGrassUpdatePosition;
    private float lastGrassUpdateTime;
    private List<GrassData> masterGrassList = new List<GrassData>();

    private class ChunkData
    {
        public List<GameObject> objects = new List<GameObject>();
        public List<Vector3> positions = new List<Vector3>();
        public List<GrassData> grassPoints = new List<GrassData>();
        public bool isGenerated = false;
        public List<GameObject> grassObjects = new List<GameObject>();
    }

    private int totalGeneratedObjects = 0;

    public void Init()
    {
        if (playerTransform == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
                playerTransform = player.transform;
        }

        if (playerTransform == null)
        {
            Debug.LogError("❌ Не знайдено гравця!");
            return;
        }

        noiseOffset = new Vector2(Random.Range(0f, 10000f), Random.Range(0f, 10000f));

        // Створюємо батьківський об'єкт
        GameObject parent = GameObject.Find("Generated World");
        if (parent == null)
            parent = new GameObject("Generated World");
        parentObject = parent.transform;

        lastPlayerPosition = playerTransform.position;

        // Початкова генерація
        GenerateInitialArea();

        StartCoroutine(ContinuousGeneration());

        if (grassAddon == null)
        {
            grassAddon = FindObjectOfType<GrassComputeScript>();
        }

        Debug.Log("✅ Система генерації запущена (чанкова)");
    }

    void GenerateInitialArea()
    {
        Vector2Int centerChunk = WorldToChunk(playerTransform.position);
        int radius = Mathf.CeilToInt(generationRadius / chunkSize);

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                Vector2Int chunkCoord = new Vector2Int(centerChunk.x + x, centerChunk.y + z);
                if (!chunks.ContainsKey(chunkCoord))
                {
                    GenerateChunk(chunkCoord);
                }
            }
        }

        if (generateGrass) UpdateGrassAddon();
    }

    IEnumerator ContinuousGeneration()
    {
        while (true)
        {
            if (playerTransform != null)
            {
                float distanceMoved = Vector3.Distance(playerTransform.position, lastPlayerPosition);

                if (distanceMoved > chunkSize * 0.3f)
                {
                    GenerateNewChunks();
                    CleanupDistantChunks();
                    lastPlayerPosition = playerTransform.position;
                }
            }

            // Тільки оновлюємо траву, якщо пройшло достатньо часу або ми відійшли далеко
            bool movedEnough = Vector3.Distance(playerTransform.position, lastGrassUpdatePosition) > chunkSize * 0.8f;
            bool timeElapsed = Time.time - lastGrassUpdateTime > 2.0f;

            if (grassNeedsUpdate && !isGenerating && generationQueue.Count == 0 && (movedEnough || timeElapsed))
            {
                UpdateGrassAddon();
                grassNeedsUpdate = false;
                lastGrassUpdatePosition = playerTransform.position;
                lastGrassUpdateTime = Time.time;
            }

            yield return new WaitForSeconds(updateInterval);
        }
    }

    void GenerateNewChunks()
    {
        Vector2Int centerChunk = WorldToChunk(playerTransform.position);
        int radius = Mathf.CeilToInt(generationRadius / chunkSize);

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                Vector2Int chunkCoord = new Vector2Int(centerChunk.x + x, centerChunk.y + z);

                if (!chunks.ContainsKey(chunkCoord) && !generationQueue.Contains(chunkCoord))
                {
                    generationQueue.Enqueue(chunkCoord);
                }
            }
        }

        if (!isGenerating)
        {
            StartCoroutine(ProcessGenerationQueue());
        }
    }

    IEnumerator ProcessGenerationQueue()
    {
        isGenerating = true;
        int processedThisFrame = 0;

        while (generationQueue.Count > 0)
        {
            Vector2Int chunkCoord = generationQueue.Dequeue();

            if (!chunks.ContainsKey(chunkCoord))
            {
                GenerateChunk(chunkCoord);
            }

            processedThisFrame++;

            if (processedThisFrame >= 10) // Process more chunks per frame
            {
                processedThisFrame = 0;
                yield return null;
            }
        }

        if (generateGrass) UpdateGrassAddon();
        isGenerating = false;
    }

    void GenerateChunk(Vector2Int chunkCoord)
    {
        ChunkData chunkData = new ChunkData();

        float chunkStartX = chunkCoord.x * chunkSize;
        float chunkStartZ = chunkCoord.y * chunkSize;
        float chunkEndX = chunkStartX + chunkSize;
        float chunkEndZ = chunkStartZ + chunkSize;

        float chunkArea = chunkSize * chunkSize;
        int objectCount = Mathf.RoundToInt(chunkArea * density * 0.02f);
        objectCount = Mathf.Clamp(objectCount, 5, 200);

        List<Vector3> positions = new List<Vector3>();
        int attempts = 0;
        int maxAttempts = objectCount * 3;

        if (generateGrass)
        {
            GenerateGrassForChunk(chunkData, chunkStartX, chunkStartZ, chunkEndX, chunkEndZ, chunkCoord);
        }

        while (positions.Count < objectCount && attempts < maxAttempts)
        {
            float randomX = Random.Range(chunkStartX, chunkEndX);
            float randomZ = Random.Range(chunkStartZ, chunkEndZ);

            // Перевірка на зони виключення
            bool inExclusionZone = false;
            Vector3 targetPos = new Vector3(randomX, 0, randomZ);
            foreach (Transform zone in exclusionZones)
            {
                if (zone != null)
                {
                    float dist = Vector2.Distance(new Vector2(randomX, randomZ), new Vector2(zone.position.x, zone.position.z));
                    if (dist < exclusionRadius)
                    {
                        inExclusionZone = true;
                        break;
                    }
                }
            }

            if (inExclusionZone)
            {
                attempts++;
                continue;
            }

            // Автоматичне визначення висоти поверхні
            Vector3 groundPosition = GetGroundPosition(randomX, randomZ);

            if (groundPosition != Vector3.zero)
            {
                bool valid = true;

                // Перевірка на перетин з існуючими об'єктами в цьому чанку
                if (avoidOverlapping)
                {
                    foreach (Vector3 existingPos in positions)
                    {
                        if (Vector3.Distance(groundPosition, existingPos) < minDistanceBetweenObjects)
                        {
                            valid = false;
                            break;
                        }
                    }
                }

                if (valid)
                {
                    positions.Add(groundPosition);
                }
            }

            attempts++;
        }

        // Створюємо об'єкти
        foreach (Vector3 pos in positions)
        {
            GameObject prefab = SelectRandomPrefab(pos);
            if (prefab != null)
            {
                GameObject obj = CreateObject(prefab, pos);
                chunkData.objects.Add(obj);
                chunkData.positions.Add(pos);
                totalGeneratedObjects++;
            }
        }

        // Генерація трави
        if (generateGrass && grassSettings != null)
        {
            List<GrassData> chunkGrassData = new List<GrassData>();
            float grassStep = 1f / Mathf.Max(0.1f, grassDensity);

            for (float x = chunkStartX; x < chunkEndX; x += grassStep)
            {
                for (float z = chunkStartZ; z < chunkEndZ; z += grassStep)
                {
                    float noise = Mathf.PerlinNoise(x * grassNoiseScale + noiseOffset.x, z * grassNoiseScale + noiseOffset.y);

                    if (noise > grassNoiseThreshold)
                    {
                        // Перевірка на зони виключення
                        bool inExclusionZone = false;
                        foreach (Transform zone in exclusionZones)
                        {
                            if (zone != null)
                            {
                                float dist = Vector2.Distance(new Vector2(x, z), new Vector2(zone.position.x, zone.position.z));
                                if (dist < exclusionRadius)
                                {
                                    inExclusionZone = true;
                                    break;
                                }
                            }
                        }

                        if (inExclusionZone) continue;

                        if (TryGetGroundPositionAndNormal(x, z, out Vector3 pos, out Vector3 normal))
                        {
                            Color groundColor = ShaderColorCalculator.GetColorAtWorldPosition(pos.x, pos.z, time, speed, ringDensity);
                            Color finalColor = Color.Lerp(Color.white, groundColor, grassColorBlend);

                            float scale = Random.Range(grassMinScale, grassMaxScale);

                            GrassData gd = new GrassData();
                            gd.position = pos;
                            gd.normal = normal;
                            gd.length = new Vector2(scale, scale);
                            gd.color = new Vector3(finalColor.r, finalColor.g, finalColor.b); 
                            chunkGrassData.Add(gd);
                        }
                    }
                }
            }

            if (chunkGrassData.Count > 0)
            {
                GameObject grassObj = new GameObject($"GrassChunk_{chunkCoord.x}_{chunkCoord.y}");
                grassObj.layer = 10; // MinimapIgnore
                grassObj.transform.SetParent(parentObject);

                GrassComputeScript grassScript = grassObj.AddComponent<GrassComputeScript>();
                grassScript.currentPresets = grassSettings;
                grassScript.SetGrassPaintedDataList = chunkGrassData;
                grassScript.Reset(); // Ініціалізація

                chunkData.grassObjects.Add(grassObj);
            }
        }

        chunkData.isGenerated = true;
        chunks[chunkCoord] = chunkData;
    }

    bool TryGetGroundPositionAndNormal(float x, float z, out Vector3 position, out Vector3 normal)
    {
        Vector3 rayStart = new Vector3(x, 500f, z);
        RaycastHit hit;

        if (Physics.Raycast(rayStart, Vector3.down, out hit, 1000f, groundLayer))
        {
            position = hit.point;
            normal = hit.normal;
            return true;
        }

        position = Vector3.zero;
        normal = Vector3.up;
        return false;
    }

    Vector3 GetGroundPosition(float x, float z)
    {
        Vector3 rayStart = new Vector3(x, 500f, z);
        RaycastHit hit;

        if (Physics.Raycast(rayStart, Vector3.down, out hit, 1000f, groundLayer))
        {
            return hit.point;
        }

        return new Vector3(x, playerTransform != null ? playerTransform.position.y : 0, z);
    }

    GameObject CreateObject(GameObject prefab, Vector3 position)
    {
        Quaternion rotation = Quaternion.identity;
        if (useRandomRotation)
        {
            rotation = Quaternion.Euler(0, Random.Range(0f, 360f), 0);
        }

        GameObject instance = Instantiate(prefab, position, rotation);
        SetLayerRecursive(instance, 10); // MinimapIgnore

        if (useRandomScale)
        {
            float scale = Random.Range(minScale, maxScale);
            instance.transform.localScale = Vector3.one * scale;
        }

        instance.transform.SetParent(parentObject);

        return instance;
    }

    private void SetLayerRecursive(GameObject obj, int newLayer)
    {
        obj.layer = newLayer;
        foreach (Transform child in obj.transform)
        {
            SetLayerRecursive(child.gameObject, newLayer);
        }
    }

    GameObject SelectRandomPrefab(Vector3 position)
    {
        Color calculatedColor = ShaderColorCalculator.GetColorAtWorldPosition(
            position.x, position.z, time, speed, ringDensity
        );

        Color.RGBToHSV(calculatedColor, out float h, out float s, out float v);

        List<GameObject> selectedList = GetColorList(h);

        if (selectedList != null && selectedList.Count > 0)
        {
            float noise = Mathf.PerlinNoise(
                position.x * 0.05f + noiseOffset.x,
                position.z * 0.05f + noiseOffset.y
            );
            int index = Mathf.FloorToInt(noise * selectedList.Count);
            index = Mathf.Clamp(index, 0, selectedList.Count - 1);
            return selectedList[index];
        }

        return EnvironmentalObjects.Count > 0 ? EnvironmentalObjects[Random.Range(0, EnvironmentalObjects.Count)] : null;
    }

    List<GameObject> GetColorList(float h)
    {
        float redStart = 0.9166116f, redEnd = 0.057f;
        float yellowStart = 0.057f, yellowEnd = 0.1486082f;
        float orangeStart = 0.1486082f, orangeEnd = 0.2233598f;
        float greenStart = 0.2233598f, greenEnd = 0.3813293f;
        float lightBlueStart = 0.3813293f, lightBlueEnd = 0.6070789f;
        float blueStart = 0.6070789f, blueEnd = 0.7155106f;
        float purpleStart = 0.7155106f, purpleEnd = 0.9166116f;

        if ((h >= redStart && h <= 1f) || (h >= 0f && h < redEnd))
            return EnvironmentalObjectsRed;
        if (h >= yellowStart && h < yellowEnd)
            return EnvironmentalObjectsYellow;
        if (h >= orangeStart && h < orangeEnd)
            return EnvironmentalObjectsOrange;
        if (h >= greenStart && h < greenEnd)
            return EnvironmentalObjectsGreen;
        if (h >= lightBlueStart && h < lightBlueEnd)
            return EnvironmentalObjectsLightBlue;
        if (h >= blueStart && h < blueEnd)
            return EnvironmentalObjectsBlue;
        if (h >= purpleStart && h < purpleEnd)
            return EnvironmentalObjectsPurple;

        return EnvironmentalObjects;
    }



    void CleanupDistantChunks()
    {
        Vector2Int playerChunk = WorldToChunk(playerTransform.position);
        List<Vector2Int> toRemove = new List<Vector2Int>();
        bool changed = false;

        float cleanupDistance = generationRadius + chunkSize;

        foreach (var kvp in chunks)
        {
            float distance = Vector2.Distance(
                new Vector2(kvp.Key.x, kvp.Key.y),
                new Vector2(playerChunk.x, playerChunk.y)
            ) * chunkSize;

            if (distance > cleanupDistance)
            {
                toRemove.Add(kvp.Key);
            }
        }

        foreach (var chunkCoord in toRemove)
        {
            ChunkData chunk = chunks[chunkCoord];
            foreach (GameObject obj in chunk.objects)
            {
                if (obj != null)
                {
                    if (Application.isPlaying)
                        Destroy(obj);
                    else
                        DestroyImmediate(obj);
                }
            }

            foreach (GameObject grassObj in chunk.grassObjects)
            {
                if (grassObj != null)
                {
                    if (Application.isPlaying)
                        Destroy(grassObj);
                    else
                        DestroyImmediate(grassObj);
                }
            }

            chunks.Remove(chunkCoord);
            changed = true;
        }

        if (changed && generateGrass)
        {
            grassNeedsUpdate = true;
        }
    }

    Vector2Int WorldToChunk(Vector3 worldPosition)
    {
        return new Vector2Int(
            Mathf.FloorToInt(worldPosition.x / chunkSize),
            Mathf.FloorToInt(worldPosition.z / chunkSize)
        );
    }

    [ContextMenu("Очистити все")]
    public void ClearGeneratedObjects()
    {
        // 1. Очищуємо чанки
        foreach (var chunk in chunks.Values)
        {
            foreach (GameObject obj in chunk.objects)
            {
                if (obj != null)
                {
                    if (Application.isPlaying)
                        Destroy(obj);
                    else
                        DestroyImmediate(obj);
                }
            }

            foreach (GameObject grassObj in chunk.grassObjects)
            {
                if (grassObj != null)
                {
                    if (Application.isPlaying)
                        Destroy(grassObj);
                    else
                        DestroyImmediate(grassObj);
                }
            }
        }
        chunks.Clear();

        // 2. Очищуємо батьківський об'єкт від залишків (якщо вони є)
        if (parentObject != null)
        {
            List<GameObject> children = new List<GameObject>();
            foreach (Transform child in parentObject)
            {
                children.Add(child.gameObject);
            }

            foreach (GameObject child in children)
            {
                if (Application.isPlaying)
                    Destroy(child);
                else
                    DestroyImmediate(child);
            }
        }

        // 3. Більш широка чистка для Editor mode (клони без батьків)
        if (!Application.isPlaying)
        {
            GameObject[] allObjects = FindObjectsOfType<GameObject>();
            foreach (GameObject obj in allObjects)
            {
                if (obj != null && obj.name.Contains("(Clone)") && obj.transform.parent == null)
                {
                    DestroyImmediate(obj);
                }
            }
        }

        generationQueue.Clear();
        totalGeneratedObjects = 0;

        if (generateGrass && grassAddon != null)
        {
            UpdateGrassAddon();
        }

        Debug.Log("🗑️ Всі об'єкти видалено");
    }

    void GenerateGrassForChunk(ChunkData chunkData, float startX, float startZ, float endX, float endZ, Vector2Int chunkCoord)
    {
        // Детермінована генерація для кожного чанка
        System.Random prng = new System.Random(chunkCoord.GetHashCode());
        
        float area = chunkSize * chunkSize;
        int grassCount = Mathf.RoundToInt(area * grassDensity);

        for (int i = 0; i < grassCount; i++)
        {
            float x = (float)prng.NextDouble() * (endX - startX) + startX;
            float z = (float)prng.NextDouble() * (endZ - startZ) + startZ;

            if (useGrassNoise)
            {
                float noiseVal = Mathf.PerlinNoise(x * grassNoiseScale + noiseOffset.x, z * grassNoiseScale + noiseOffset.y);
                if (noiseVal < grassNoiseCutoff) continue;
            }

            Vector3 rayStart = new Vector3(x, 500f, z);
            RaycastHit hit;

            if (Physics.Raycast(rayStart, Vector3.down, out hit, 1000f, groundLayer))
            {
                Color color = ShaderColorCalculator.GetColorAtWorldPosition(x, z, time, speed, ringDensity);
                
                GrassData gd = new GrassData();
                gd.position = hit.point;
                gd.normal = hit.normal;
                gd.length = new Vector2(1f, 1f);
                gd.color = new Vector3(color.r, color.g, color.b);
                
                chunkData.grassPoints.Add(gd);
            }
        }
    }

    void UpdateGrassAddon()
    {
        if (grassAddon == null) return;

        masterGrassList.Clear();
        foreach (var chunk in chunks.Values)
        {
            masterGrassList.AddRange(chunk.grassPoints);
        }

        grassAddon.UpdateDataSmooth(masterGrassList);
        Debug.Log($"[Grass] Updated addon with {masterGrassList.Count} points across {chunks.Count} chunks.");
    }

    void OnDrawGizmosSelected()
    {
        if (playerTransform != null)
        {
            Gizmos.color = new Color(0, 1, 0, 0.2f);
            Gizmos.DrawWireSphere(playerTransform.position, generationRadius);
        }

        // Візуалізація зон виключення
        Gizmos.color = new Color(1, 0, 0, 0.3f);
        foreach (Transform zone in exclusionZones)
        {
            if (zone != null)
            {
                Gizmos.DrawSphere(zone.position, exclusionRadius);
            }
        }
    }
}