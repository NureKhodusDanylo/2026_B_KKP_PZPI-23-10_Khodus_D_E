using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MagicUniverse.World;

public class DungeonEnemySpawner : MonoBehaviour, IInitializable
{
    [Header("===== ENEMY PREFABS =====")]
    public List<GameObject> EnemyPrefabs = new List<GameObject>();

    [Header("===== SPAWN SETTINGS =====")]
    [Range(1, 30)] public int enemiesPerChunk = 2;
    [Range(5f, 120f)] public float respawnInterval = 20f;
    [Range(30f, 250f)] public float spawnRadius = 60f;
    [Range(20f, 80f)] public float chunkSize = 40f;
    public LayerMask groundLayer = ~0;

    [Header("===== LEVEL SCALING =====")]
    public float baseHP = 120f;
    public float baseDamage = 20f;

    [Header("===== REFS =====")]
    public Transform playerTransform;

    private class ChunkData
    {
        public List<GameObject> aliveEnemies = new List<GameObject>();
        public bool isGenerated = false;
        public float lastSpawnTime = 0f;
    }

    private Dictionary<Vector2Int, ChunkData> chunks = new Dictionary<Vector2Int, ChunkData>();
    private Transform parentObject;
    private Vector3 lastPlayerPosition;
    private int currentAliveCount = 0;
    private int maxAliveEnemies = 40;
    private bool initialized = false;

    public void Init()
    {
        if (initialized) return;

        if (playerTransform == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
                playerTransform = player.transform;
        }

        if (playerTransform == null)
        {
            Debug.LogError("❌ DungeonEnemySpawner: Player not found!");
            return;
        }

        // Dynamically copy enemy lists from the main spawner if empty
        if (EnemyPrefabs.Count == 0)
        {
            EnemySpawner mainSpawner = Object.FindObjectOfType<EnemySpawner>();
            if (mainSpawner != null)
            {
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabs);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsRed);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsOrange);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsYellow);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsGreen);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsLightBlue);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsBlue);
                EnemyPrefabs.AddRange(mainSpawner.EnemyPrefabsPurple);
                
                // Clean nulls
                EnemyPrefabs.RemoveAll(x => x == null);
            }
        }

        GameObject parent = GameObject.Find("Spawned Dungeon Enemies");
        if (parent == null)
            parent = new GameObject("Spawned Dungeon Enemies");
        parentObject = parent.transform;

        lastPlayerPosition = playerTransform.position;

        StartCoroutine(ContinuousSpawnLoop());
        initialized = true;
        Debug.Log("✅ DungeonEnemySpawner initialized successfully!");
    }

    private IEnumerator ContinuousSpawnLoop()
    {
        while (true)
        {
            // Only spawn if player is actually in the dungeon
            if (playerTransform != null && DayNightCycleController.IsInDungeon)
            {
                float distanceMoved = Vector3.Distance(playerTransform.position, lastPlayerPosition);

                if (distanceMoved > chunkSize * 0.3f)
                {
                    SpawnNewChunks();
                    CleanupDistantChunks();
                    lastPlayerPosition = playerTransform.position;
                }

                RespawnInExistingChunks();
            }

            yield return new WaitForSeconds(1.0f);
        }
    }

    private void SpawnNewChunks()
    {
        Vector2Int centerChunk = WorldToChunk(playerTransform.position);
        int radius = Mathf.CeilToInt(spawnRadius / chunkSize);

        for (int x = -radius; x <= radius; x++)
        {
            for (int z = -radius; z <= radius; z++)
            {
                Vector2Int chunkCoord = new Vector2Int(centerChunk.x + x, centerChunk.y + z);
                if (!chunks.ContainsKey(chunkCoord))
                {
                    SpawnChunk(chunkCoord);
                }
            }
        }
    }

    private void SpawnChunk(Vector2Int chunkCoord)
    {
        ChunkData chunkData = new ChunkData();

        float chunkStartX = chunkCoord.x * chunkSize;
        float chunkStartZ = chunkCoord.y * chunkSize;
        float chunkEndX = chunkStartX + chunkSize;
        float chunkEndZ = chunkStartZ + chunkSize;

        int spawned = 0;
        int attempts = 0;
        int maxAttempts = enemiesPerChunk * 5;

        while (spawned < enemiesPerChunk && attempts < maxAttempts)
        {
            if (currentAliveCount >= maxAliveEnemies)
                break;

            float randomX = Random.Range(chunkStartX, chunkEndX);
            float randomZ = Random.Range(chunkStartZ, chunkEndZ);

            Vector3 groundPos = GetGroundPosition(randomX, randomZ);

            // Ensure the position is actually underground in the dungeon
            if (groundPos != Vector3.zero && groundPos.y < -900f)
            {
                GameObject enemy = SpawnEnemy(groundPos);
                if (enemy != null)
                {
                    chunkData.aliveEnemies.Add(enemy);
                    spawned++;
                }
            }

            attempts++;
        }

        chunkData.isGenerated = true;
        chunkData.lastSpawnTime = Time.time;
        chunks[chunkCoord] = chunkData;
    }

    private GameObject SpawnEnemy(Vector3 position)
    {
        if (EnemyPrefabs.Count == 0) return null;

        GameObject prefab = EnemyPrefabs[Random.Range(0, EnemyPrefabs.Count)];
        if (prefab == null) return null;

        Quaternion rotation = Quaternion.Euler(0, Random.Range(0f, 360f), 0);

        GameObject instance = Instantiate(prefab, position, rotation);
        instance.transform.SetParent(parentObject);

        // Apply scaling
        EnemyLevelData levelData = instance.GetComponent<EnemyLevelData>();
        if (levelData == null)
            levelData = instance.AddComponent<EnemyLevelData>();
        
        levelData.SetLevel(1, baseHP, baseDamage);

        Enemy enemyComponent = instance.GetComponent<Enemy>();
        if (enemyComponent != null)
        {
            enemyComponent.Init();
        }

        currentAliveCount++;
        return instance;
    }

    private void RespawnInExistingChunks()
    {
        if (currentAliveCount >= maxAliveEnemies) return;

        Vector2Int playerChunk = WorldToChunk(playerTransform.position);
        float maxDist = spawnRadius / chunkSize;

        foreach (var kvp in chunks)
        {
            float chunkDist = Vector2.Distance(
                new Vector2(kvp.Key.x, kvp.Key.y),
                new Vector2(playerChunk.x, playerChunk.y)
            );
            if (chunkDist > maxDist) continue;

            ChunkData chunkData = kvp.Value;

            for (int i = chunkData.aliveEnemies.Count - 1; i >= 0; i--)
            {
                if (chunkData.aliveEnemies[i] == null)
                {
                    chunkData.aliveEnemies.RemoveAt(i);
                    currentAliveCount = Mathf.Max(0, currentAliveCount - 1);
                }
            }

            if (chunkData.aliveEnemies.Count < enemiesPerChunk)
            {
                float timeSinceLastSpawn = Time.time - chunkData.lastSpawnTime;
                if (timeSinceLastSpawn >= respawnInterval)
                {
                    Vector3 spawnPos = FindSpawnPosInChunk(kvp.Key);
                    if (spawnPos != Vector3.zero && spawnPos.y < -900f)
                    {
                        GameObject enemy = SpawnEnemy(spawnPos);
                        if (enemy != null)
                        {
                            chunkData.aliveEnemies.Add(enemy);
                            chunkData.lastSpawnTime = Time.time;
                        }
                    }
                }
            }
        }
    }

    private Vector3 FindSpawnPosInChunk(Vector2Int chunkCoord)
    {
        float chunkStartX = chunkCoord.x * chunkSize;
        float chunkStartZ = chunkCoord.y * chunkSize;
        float chunkEndX = chunkStartX + chunkSize;
        float chunkEndZ = chunkStartZ + chunkSize;

        for (int i = 0; i < 5; i++)
        {
            float x = Random.Range(chunkStartX, chunkEndX);
            float z = Random.Range(chunkStartZ, chunkEndZ);

            Vector3 pos = GetGroundPosition(x, z);
            if (pos != Vector3.zero) return pos;
        }
        return Vector3.zero;
    }

    private void CleanupDistantChunks()
    {
        Vector2Int playerChunk = WorldToChunk(playerTransform.position);
        List<Vector2Int> toRemove = new List<Vector2Int>();
        float cleanupDistance = spawnRadius + chunkSize;

        foreach (var kvp in chunks)
        {
            float distance = Vector2.Distance(
                new Vector2(kvp.Key.x, kvp.Key.y),
                new Vector2(playerChunk.x, playerChunk.y)
            ) * chunkSize;

            if (distance > cleanupDistance)
                toRemove.Add(kvp.Key);
        }

        foreach (var chunkCoord in toRemove)
        {
            ChunkData chunk = chunks[chunkCoord];
            foreach (GameObject obj in chunk.aliveEnemies)
            {
                if (obj != null)
                {
                    currentAliveCount = Mathf.Max(0, currentAliveCount - 1);
                    if (Application.isPlaying) Destroy(obj);
                    else DestroyImmediate(obj);
                }
            }
            chunks.Remove(chunkCoord);
        }
    }

    private Vector3 GetGroundPosition(float x, float z)
    {
        // Spawns raycast specifically targeting the underground dungeon Y range
        Vector3 rayStart = new Vector3(x, -900f, z);
        RaycastHit hit;
        if (Physics.Raycast(rayStart, Vector3.down, out hit, 200f, groundLayer))
            return hit.point;
        return Vector3.zero;
    }

    private Vector2Int WorldToChunk(Vector3 worldPosition)
    {
        return new Vector2Int(
            Mathf.FloorToInt(worldPosition.x / chunkSize),
            Mathf.FloorToInt(worldPosition.z / chunkSize)
        );
    }
}
