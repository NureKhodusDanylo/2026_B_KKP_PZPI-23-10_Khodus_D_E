using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SimpleDestroyer : MonoBehaviour
{
    private void OnCollisionEnter(Collision collision)
    {
        if(collision.gameObject.TryGetComponent<FrictionSensor>(out var component))
        {
            component.Destroy();
        }
        else
        {
            PoolManager.Instanse.ReturnObject(collision.gameObject);
        }
    }
}
